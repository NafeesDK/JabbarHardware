<?php
require_once 'access_control.php';
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$inactive = 300; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $inactive)) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}
$_SESSION['last_activity'] = time(); 

$message = ''; 
$message_type = ''; 
$action = $_GET['action'] ?? 'new';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($action === 'new') {
        $name = $_POST['name'] ?? '';
        $description = $_POST['description'] ?? '';
        $original_price = $_POST['original_price'] ?? 0;
        $discounted_price = $_POST['discounted_price'] ?? null;
        $category = $_POST['category'] ?? '';
        $stock_quantity = $_POST['stock_quantity'] ?? 0;
        $supplier_id = $_POST['supplier_id'] ?? '';

        $image_url = '';
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../Image/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            $file_extension = strtolower(pathinfo($_FILES['product_image']['name'], PATHINFO_EXTENSION));
            $new_filename = uniqid() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $upload_path)) {
                $image_url = "Image/" . $new_filename;
            }
        }

        if (empty($name) || empty($description) || empty($original_price) || empty($category) || $stock_quantity === null || empty($supplier_id)) {
            $message = 'All required fields must be filled.';
            $message_type = 'error';
        } else {
            if (!is_numeric($original_price) || $original_price < 0) {
                $message = 'Original price must be a non-negative number.';
                $message_type = 'error';
            } else if ($category === 'offer' && ($discounted_price === null || !is_numeric($discounted_price) || $discounted_price < 0)) {
                $message = 'Discounted price must be a non-negative number when the category is Offer.';
                $message_type = 'error';
            } else if ($category !== 'offer' && $discounted_price !== null && $discounted_price !== '') {
                 $message = 'Discounted price can only be set for Offer category.';
                 $message_type = 'error';
            } else if (!is_numeric($stock_quantity) || $stock_quantity < 0) {
                $message = 'Stock quantity must be a non-negative number.';
                $message_type = 'error';
            } else {
                try {
                    $conn->begin_transaction();

                    $insert_product_query = "INSERT INTO products (name, description, original_price, discounted_price, image_url, category, stock_quantity) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    $stmt_product = $conn->prepare($insert_product_query);
                    $stmt_product->bind_param("ssdsssi", $name, $description, $original_price, $discounted_price, $image_url, $category, $stock_quantity);

                    if ($stmt_product->execute()) {
                        $new_product_id = $conn->insert_id;

                        $insert_supplier_query = "INSERT INTO product_suppliers (product_id, supplier_id) VALUES (?, ?)";
                        $stmt_supplier = $conn->prepare($insert_supplier_query);
                        $stmt_supplier->bind_param("ii", $new_product_id, $supplier_id);
                        $stmt_supplier->execute();

                        $insert_history_query = "INSERT INTO stock_history (product_id, previous_quantity, new_quantity, change_type) VALUES (?, ?, ?, 'restock')";
                        $stmt_history = $conn->prepare($insert_history_query);
                        $previous_quantity = 0;
                        $stmt_history->bind_param("iii", $new_product_id, $previous_quantity, $stock_quantity);

                        if ($stmt_history->execute()) {
                            $conn->commit();
                            $message = 'New product added and stock history updated successfully!';
                            $message_type = 'success';
                        } else {
                            $conn->rollback();
                            $message = 'Error adding stock history: ' . $stmt_history->error;
                            $message_type = 'error';
                        }
                    } else {
                        $conn->rollback();
                        $message = 'Error adding new product: ' . $stmt_product->error;
                        $message_type = 'error';
                    }

                    $stmt_product->close();
                    $stmt_history->close();
                    $stmt_supplier->close();

                } catch (Exception $e) {
                    $conn->rollback();
                    $message = 'Database error: ' . $e->getMessage();
                    $message_type = 'error';
                }
            }
        }
    } else if ($action === 'restock') {
        $product_id = $_POST['product_id'] ?? '';
        $stock_quantity = $_POST['stock_quantity'] ?? 0;
        $supplier_id = $_POST['supplier_id'] ?? '';

        if (empty($product_id) || $stock_quantity === null || empty($supplier_id)) {
            $message = 'All required fields must be filled.';
            $message_type = 'error';
        } else if (!is_numeric($stock_quantity) || $stock_quantity < 0) {
            $message = 'Stock quantity must be a non-negative number.';
            $message_type = 'error';
        } else {
            try {
                $conn->begin_transaction();

                $current_stock_query = "SELECT stock_quantity FROM products WHERE id = ?";
                $stmt_current = $conn->prepare($current_stock_query);
                $stmt_current->bind_param("i", $product_id);
                $stmt_current->execute();
                $result = $stmt_current->get_result();
                $current_stock = $result->fetch_assoc()['stock_quantity'];

                $new_quantity = $current_stock + $stock_quantity;
                $update_stock_query = "UPDATE products SET stock_quantity = ? WHERE id = ?";
                $stmt_update = $conn->prepare($update_stock_query);
                $stmt_update->bind_param("ii", $new_quantity, $product_id);

                if ($stmt_update->execute()) {
                    $insert_history_query = "INSERT INTO stock_history (product_id, previous_quantity, new_quantity, change_type) VALUES (?, ?, ?, 'restock')";
                    $stmt_history = $conn->prepare($insert_history_query);
                    $stmt_history->bind_param("iii", $product_id, $current_stock, $new_quantity);

                    if ($stmt_history->execute()) {
                        $conn->commit();
                        $message = 'Product restocked successfully!';
                        $message_type = 'success';
                    } else {
                        $conn->rollback();
                        $message = 'Error adding stock history: ' . $stmt_history->error;
                        $message_type = 'error';
                    }
                } else {
                    $conn->rollback();
                    $message = 'Error updating stock: ' . $stmt_update->error;
                    $message_type = 'error';
                }

                $stmt_current->close();
                $stmt_update->close();
                $stmt_history->close();

            } catch (Exception $e) {
                $conn->rollback();
                $message = 'Database error: ' . $e->getMessage();
                $message_type = 'error';
            }
        }
    }
}

$products_query = "SELECT id, name, category FROM products ORDER BY name ASC";
$products_result = $conn->query($products_query);

$suppliers_query = "SELECT id, name FROM suppliers ORDER BY name ASC";
$suppliers_result = $conn->query($suppliers_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jabbar Admin Dashboard - New Stocks</title>
    <link rel="stylesheet" href="ccc.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        .new-stocks-form-container {
            padding: 20px;
            background: rgba(0, 0, 0, 0.9);
            border: 2px solid #009688;
            border-radius: 25px;
            max-width: 600px;
            margin: 20px auto;
            color: white;
        }

        .main-content {
            scrollbar-width: thin;
            scrollbar-color: rgba(0, 150, 136, 0.3) rgba(0, 150, 136, 0.1);
            overflow-y: auto;
        }

        .main-content::-webkit-scrollbar {
            width: 8px;
        }

        .main-content::-webkit-scrollbar-track {
            background: rgba(0, 150, 136, 0.1);
            border-radius: 4px;
        }

        .main-content::-webkit-scrollbar-thumb {
            background: rgba(0, 150, 136, 0.3);
            border-radius: 4px;
            transition: background 0.3s ease;
        }

        .main-content::-webkit-scrollbar-thumb:hover {
            background: rgba(0, 150, 136, 0.5);
        }

        .new-stocks-form-container h2 {
            color: #009688;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #009688;
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #009688;
            font-weight: bold;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group input[type="email"],
        .form-group input[type="url"],
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #009688;
            border-radius: 5px;
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            box-sizing: border-box; 
        }

        .form-group textarea {
            height: 60px;
            resize: vertical;
        }

        .form-group input[type="number"]::-webkit-outer-spin-button,
        .form-group input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .form-group input[type="number"] {
            -moz-appearance: textfield;
        }

        .form-group select option {
             background-color: rgba(0, 0, 0, 0.9);
             color: white;
        }

        .submit-btn {
            display: block;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #009688;
            color: white;
            font-size: 1.1em;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .submit-btn:hover {
            background-color: #00796b;
        }

        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: center;
        }

        .message.success {
            background-color: rgba(76, 175, 80, 0.2); 
            color: #4CAF50; 
            border: 1px solid #4CAF50;
        }

        .message.error {
            background-color: rgba(244, 67, 54, 0.2); 
            color: #F44336; 
            border: 1px solid #F44336;
        }

        .submenu-item {
            padding: 10px 20px 10px 40px;
            cursor: pointer;
            transition: all 0.3s ease;
            color: #888;
            display: none;
            align-items: center;
            height: 40px;
            opacity: 0;
            background-color: rgba(0, 0, 0, 0.3);
        }

        .submenu-item:hover {
            color: #009688;
            background-color: rgba(0, 150, 136, 0.1);
        }

        .submenu-item.active {
            color: #009688;
            background-color: rgba(0, 150, 136, 0.2);
            border-left: 4px solid #009688;
        }

        .submenu-item i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        .submenu-item.show {
            display: flex !important;
            opacity: 1;
        }

        .menu-item.has-submenu {
            position: relative;
        }

        .menu-item.has-submenu .submenu-arrow {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            transition: transform 0.3s ease;
        }

        .menu-item.has-submenu.active .submenu-arrow {
            transform: translateY(-50%) rotate(180deg);
        }

        .form-group select,
        .form-group textarea {
            scrollbar-width: thin;
            scrollbar-color: rgba(0, 150, 136, 0.3) rgba(0, 150, 136, 0.1);
        }

        .form-group select::-webkit-scrollbar,
        .form-group textarea::-webkit-scrollbar {
            width: 8px;
        }

        .form-group select::-webkit-scrollbar-track,
        .form-group textarea::-webkit-scrollbar-track {
            background: rgba(0, 150, 136, 0.1);
            border-radius: 4px;
        }

        .form-group select::-webkit-scrollbar-thumb,
        .form-group textarea::-webkit-scrollbar-thumb {
            background: rgba(0, 150, 136, 0.3);
            border-radius: 4px;
            transition: background 0.3s ease;
        }

        .form-group select::-webkit-scrollbar-thumb:hover,
        .form-group textarea::-webkit-scrollbar-thumb:hover {
            background: rgba(0, 150, 136, 0.5);
        }

        .analytics-section h2 {
            color: #009688;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(0, 150, 136, 0.3);
        }

        .stats-overview {
            margin-top: 15px;
        }

        .stats-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 0.95em;
        }

        .stats-item:last-child {
            border-bottom: none;
        }

        .stat-label {
            color: #ccc;
            font-weight: 500;
        }

        .stat-value {
            color: #009688;
            font-weight: bold;
        }

    </style>
</head>
<body>
    <div id="page1">
        <div class="container">
            <div class="sidebar">
                <div class="logo">
                    <span class="logo-letter">J</span>
                    <span class="logo-text">ABBAR</span>
                </div>
                
                <div class="menu">
                    <div class="menu-item" onclick="window.location.href='aaa.php'">
                        <i class="fas fa-home"></i>
                        <span>Home</span>
                    </div>
                    
                    <div class="menu-item has-submenu">
                        <i class="fas fa-box"></i>
                        <span>Products</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item <?php echo (!isset($_GET['type']) || $_GET['type'] === 'offers') ? 'active' : ''; ?>" onclick="window.location.href='products.php?type=offers'" style="display: none;">
                        <i class="fas fa-tag"></i>
                        <span>Offers</span>
                    </div>
                    <div class="submenu-item <?php echo (isset($_GET['type']) && $_GET['type'] === 'regular') ? 'active' : ''; ?>" onclick="window.location.href='products.php?type=regular'" style="display: none;">
                        <i class="fas fa-box-archive"></i>
                        <span>Regular</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='supplier.php'">
                        <i class="fas fa-truck"></i>
                        <span>Suppliers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='customer.php'">
                        <i class="fas fa-users"></i>
                        <span>View Customers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='inventory.php'">
                        <i class="fas fa-boxes"></i>
                        <span>Inventory Management</span>
                    </div>

                    <div class="menu-item has-submenu active">
                        <i class="fas fa-plus-circle"></i>
                        <span>New Stocks</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item <?php echo ($action === 'new') ? 'active' : ''; ?>" onclick="window.location.href='new_stocks.php?action=new'" style="display: none;">
                        <i class="fas fa-dolly"></i>
                        <span>New Product</span>
                    </div>
                    <div class="submenu-item <?php echo ($action === 'restock') ? 'active' : ''; ?>" onclick="window.location.href='new_stocks.php?action=restock'" style="display: none;">
                        <i class="fas fa-truck-ramp-box"></i>
                        <span>Restock</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='feedback.php'">
                        <i class="fas fa-comment"></i>
                        <span>Feedback Management</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='AandR.php'">
                        <i class="fas fa-chart-bar"></i>
                        <span>Analytics & Reports</span>
                    </div>
                </div>

                <div class="sidebar-bottom">
                    <div class="menu-item hold-button" onclick="toggleHold()">
                        <i class="fas fa-pause-circle"></i>
                        <span id="holdText">Hold</span>
                    </div>
                    
                    <div class="logout" onclick="logout()">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </div>
                </div>
            </div>
            
            <div class="main-content">
                <div class="header">
                    <div class="user-profile">
                        <div class="user-info">
                            <span class="user-name"><?php echo $_SESSION['admin_username']; ?></span>
                        </div>
                        <div class="avatar">
                            <?php if (!empty($_SESSION['admin_profile_image'])): ?>
                                <img src="./AdminPix/<?php echo $_SESSION['admin_profile_image']; ?>" alt="Admin Avatar">
                            <?php else: ?>
                                <img src="./AdminPix/image.webp" alt="Admin Avatar">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="new-stocks-form-container">
                    <h2><?php echo $action === 'new' ? 'Add New Product Stock' : 'Restock Existing Product'; ?></h2>

                    <?php if (!empty($message)): ?>
                        <div class="message <?php echo $message_type; ?>">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <form action="new_stocks.php?action=<?php echo $action; ?>" method="POST" enctype="multipart/form-data">
                        <?php if ($action === 'new'): ?>
                            <div class="form-group">
                                <label for="name">Product Name:</label>
                                <input type="text" id="name" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="description">Description:</label>
                                <textarea id="description" name="description" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="original_price">Original Price:</label>
                                <input type="number" id="original_price" name="original_price" step="0.01" required>
                            </div>
                            <div class="form-group">
                                <label for="category">Category:</label>
                                <select id="category" name="category" required onchange="toggleDiscountedPrice()">
                                    <option value="" disabled selected>Select Category</option>
                                    <option value="offer">Offer</option>
                                    <option value="regular">Regular</option>
                                </select>
                            </div>
                            <div class="form-group" id="discountedPriceGroup" style="display: none;">
                                <label for="discounted_price">Discounted Price:</label>
                                <input type="number" id="discounted_price" name="discounted_price" step="0.01">
                            </div>
                            <div class="form-group">
                                <label for="product_image">Product Image:</label>
                                <input type="file" id="product_image" name="product_image" accept="image/*" required>
                            </div>
                        <?php else: ?>
                            <div class="form-group">
                                <label for="product_id">Select Product:</label>
                                <select id="product_id" name="product_id" required>
                                    <option value="" disabled selected>Select Product</option>
                                    <?php while ($product = $products_result->fetch_assoc()): ?>
                                        <option value="<?php echo $product['id']; ?>" data-category="<?php echo $product['category']; ?>">
                                            <?php echo $product['name']; ?> (<?php echo ucfirst($product['category']); ?>)
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="supplier_id">Supplier:</label>
                            <select id="supplier_id" name="supplier_id" required>
                                <option value="" disabled selected>Select Supplier</option>
                                <?php while ($supplier = $suppliers_result->fetch_assoc()): ?>
                                    <option value="<?php echo $supplier['id']; ?>">
                                        <?php echo $supplier['name']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="stock_quantity"><?php echo $action === 'new' ? 'Initial' : 'Additional'; ?> Stock Quantity:</label>
                            <input type="number" id="stock_quantity" name="stock_quantity" required>
                        </div>

                        <button type="submit" class="submit-btn">
                            <?php echo $action === 'new' ? 'Add Product Stock' : 'Restock Product'; ?>
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="right-sidebar">
                <div class="feedback-section">
                    <h2>AI Inventory Suggestions</h2>
                    <div class="feedback-items">
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer feedback will appear here...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Another feedback sample text...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Yet another feedback example...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer comments and suggestions...</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="analytics-section">
                    <h2>Analytics & Reports Overview</h2>
                    <div class="stats-overview">
                        <div class="stat-item">
                            <span class="stat-label">Monthly Sales:</span>
                            <span class="stat-value" id="overviewMonthlySales">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Total Customers:</span>
                            <span class="stat-value" id="overviewTotalCustomers">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Underperforming Products:</span>
                            <span class="stat-value" id="overviewUnderperformingProducts">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Low Stock Alerts:</span>
                            <span class="stat-value" id="overviewLowStockAlerts">Loading...</span>
                        </div>
                         <div class="stat-item">
                            <span class="stat-label">High Stock Items:</span>
                            <span class="stat-value" id="overviewHighStockItems">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let inactivityTime = function() {
            let time;
            let isHeld = false;
            
            window.onload = resetTimer;
            document.onmousemove = resetTimer;
            document.onkeydown = resetTimer;
            document.onclick = resetTimer;
            document.onscroll = resetTimer;
            
            function resetTimer() {
                if (!isHeld) {
                    clearTimeout(time);
                    time = setTimeout(logout, 300000);
                }
            }
            
            window.toggleHold = function() {
                const holdButton = document.querySelector('.hold-button');
                const holdText = document.getElementById('holdText');
                isHeld = !isHeld;
                
                sessionStorage.setItem('isHeld', isHeld);

                if (isHeld) {
                    holdButton.classList.add('active');
                    holdText.textContent = 'Cancel';
                    clearTimeout(time); 
                } else {
                    holdButton.classList.remove('active');
                    holdText.textContent = 'Hold';
                    resetTimer(); 
                }
            };
        };
        
        let isHeld = sessionStorage.getItem('isHeld') === 'true'; 
        const holdButton = document.querySelector('.hold-button');
        const holdText = document.getElementById('holdText');

        if (isHeld) {
            holdButton.classList.add('active');
            holdText.textContent = 'Cancel';
        } else {
            holdButton.classList.remove('active');
            holdText.textContent = 'Hold';
        }

        inactivityTime(); 
        
        function logout() {
            window.location.href = "logout.php";
        }
        
        window.addEventListener('beforeunload', function(e) {
            if (!window.location.href.includes('/admin/')) {
                e.preventDefault();
                e.returnValue = '';
                fetch('logout.php');
            }
        });
        
        setInterval(function() {
            fetch('check_session.php')
                .then(response => response.json())
                .then(data => {
                    if (!data.valid) {
                        window.location.href = "login.php?timeout=1";
                    }
                });
        }, 60000);

        document.addEventListener('DOMContentLoaded', function() {
            // Products submenu
            const productsMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-box)');
            const productsSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-tag), .submenu-item:has(i.fa-box-archive)');
            
            productsMenuItem.addEventListener('click', function() {
                this.classList.toggle('active');
                
                productsSubmenuItems.forEach(item => {
                    if (this.classList.contains('active')) {
                        item.style.display = 'flex';
                        setTimeout(() => {
                            item.classList.add('show');
                        }, 10);
                    } else {
                        item.classList.remove('show');
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 300);
                    }
                });
            });

            if (productsMenuItem.classList.contains('active')) {
                productsSubmenuItems.forEach(item => {
                    item.style.display = 'flex'; 
                    setTimeout(() => {
                        item.classList.add('show');
                    }, 10);
                });
            }

            const newStocksMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-plus-circle)');
            const newStocksSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-truck-ramp-box), .submenu-item:has(i.fa-dolly)');

            if (newStocksMenuItem) {
                newStocksMenuItem.addEventListener('click', function() {
                    this.classList.toggle('active');

                    newStocksSubmenuItems.forEach(item => {
                        if (this.classList.contains('active')) {
                            item.style.display = 'flex';
                            setTimeout(() => {
                                item.classList.add('show');
                            }, 10);
                        } else {
                            item.classList.remove('show');
                            setTimeout(() => {
                                item.style.display = 'none';
                            }, 300);
                        }
                    });
                });

                // Keep submenu open if current page is a submenu item
                const urlParams = new URLSearchParams(window.location.search);
                const action = urlParams.get('action');
                
                if (action) {
                    newStocksMenuItem.classList.add('active');
                    newStocksSubmenuItems.forEach(item => {
                        item.style.display = 'flex';
                        setTimeout(() => {
                            item.classList.add('show');
                        }, 10);
                    });
                }
            }
        });

        function toggleDiscountedPrice() {
            const category = document.getElementById('category').value;
            const discountedPriceGroup = document.getElementById('discountedPriceGroup');
            const discountedPriceInput = document.getElementById('discounted_price');

            if (category === 'offer') {
                discountedPriceGroup.style.display = 'block';
                discountedPriceInput.required = true;
            } else {
                discountedPriceGroup.style.display = 'none';
                discountedPriceInput.required = false;
                discountedPriceInput.value = '';
            }
        }

        // Initialize the form based on the action
        document.addEventListener('DOMContentLoaded', function() {
            const action = '<?php echo $action; ?>';
            if (action === 'new') {
                toggleDiscountedPrice();
            }
        });

        // Function to fetch and display overview stats in right sidebar
        function fetchOverviewStats() {
            // Fetch Monthly Sales
            fetch('get_monthly_sales.php')
                .then(response => response.json())
                .then(data => {
                    const totalMonthlySales = data.values.reduce((sum, value) => sum + parseFloat(value), 0);
                    document.getElementById('overviewMonthlySales').textContent = `Rs. ${totalMonthlySales.toFixed(2)}`;
                }).catch(error => console.error('Error fetching monthly sales overview:', error));

            // Fetch Total Customers
            fetch('get_customer_stats.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewTotalCustomers').textContent = data.totalCustomers;
                }).catch(error => console.error('Error fetching customer stats overview:', error));

            // Fetch Product Performance (Underperforming)
            fetch('get_product_performance.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewUnderperformingProducts').textContent = data.underperforming.length;
                }).catch(error => console.error('Error fetching product performance overview:', error));

            // Fetch Inventory Health (Low Stock Alerts)
            fetch('get_inventory_health.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewLowStockAlerts').textContent = data.restockAlerts.length;
                     document.getElementById('overviewHighStockItems').textContent = data.stockLevels.length;
                }).catch(error => console.error('Error fetching inventory health overview:', error));
        }

        // Call the function to fetch and display overview stats on page load
        fetchOverviewStats();
    </script>

</body>
</html>