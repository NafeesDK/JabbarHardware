<?php
require_once 'access_control.php';
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$inactive = 300; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $inactive)) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}
$_SESSION['last_activity'] = time(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jabbar Admin Dashboard</title>
    <link rel="stylesheet" href="ccc.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
</head>
<body>
    <div id="page1">
        <div class="container">
            <div class="sidebar">
                <div class="logo">
                    <span class="logo-letter">J</span>
                    <span class="logo-text">ABBAR</span>
                </div>
                
                <div class="menu">
                    <div class="menu-item active">
                        <i class="fas fa-home"></i>
                        <span>Home</span>
                    </div>
                    
                    <div class="menu-item has-submenu">
                        <i class="fas fa-box"></i>
                        <span>Products</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='products.php?type=offers'" style="display: none;">
                        <i class="fas fa-tag"></i>
                        <span>Offers</span>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='products.php?type=regular'" style="display: none;">
                        <i class="fas fa-box-archive"></i>
                        <span>Regular</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='supplier.php'">
                        <i class="fas fa-truck"></i>
                        <span>Suppliers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='customer.php'">
                        <i class="fas fa-users"></i>
                        <span>View Customers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='inventory.php'">
                        <i class="fas fa-boxes"></i>
                        <span>Inventory Management</span>
                    </div>

                    <div class="menu-item has-submenu">
                        <i class="fas fa-plus-circle"></i>
                        <span>New Stocks</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='new_stocks.php?action=new'" style="display: none;">
                        <i class="fas fa-dolly"></i>
                        <span>New Product</span>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='new_stocks.php?action=restock'" style="display: none;">
                        <i class="fas fa-truck-ramp-box"></i>
                        <span>Restock</span>
                    </div>
                                        
                    <div class="menu-item" onclick="window.location.href='feedback.php'">
                        <i class="fas fa-comment"></i>
                        <span>Feedback Management</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='AandR.php'">
                        <i class="fas fa-chart-bar"></i>
                        <span>Analytics & Reports</span>
                    </div>
                </div>

                <div class="sidebar-bottom">
                    <div class="menu-item hold-button" onclick="toggleHold()">
                        <i class="fas fa-pause-circle"></i>
                        <span id="holdText">Hold</span>
                    </div>
                    
                    <div class="logout" onclick="logout()">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </div>
                </div>
            </div>
            
            <div class="main-content">
                <div class="header">
                    <div class="page-title">
                        <div class="date-selector">
                            <div class="date-input" id="date-input-wrapper">
                                <span id="current-date" class="date-display" onclick="openCalendar()"></span>
                                <i class="fas fa-calendar" onclick="openCalendar()"></i>
                            </div>
                        </div>
                    </div>
                    <div class="user-profile">
                        <div class="user-info">
                            <span class="user-name"><?php echo $_SESSION['admin_username']; ?></span>
                        </div>
                        <div class="avatar">
                            <?php if (!empty($_SESSION['admin_profile_image'])): ?>
                                <img src="./AdminPix/<?php echo $_SESSION['admin_profile_image']; ?>" alt="Admin Avatar">
                            <?php else: ?>
                                <img src="./AdminPix/image.webp" alt="Admin Avatar">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="stats-container">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: #FFD580;">
                            <i class="fas fa-box"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Total Products Sold</h3>
                            <div class="stat-value">
                                <?php
                                $result = $conn->query("SELECT COUNT(*) as total FROM order_tracking WHERE status = 'delivered'");
                                $row = $result->fetch_assoc();
                                echo $row['total'];
                                ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: #FF9B9B;">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Total Orders</h3>
                            <div class="stat-value">
                                <?php
                                $result = $conn->query("SELECT COUNT(*) as total FROM orders");
                                $row = $result->fetch_assoc();
                                echo $row['total'];
                                ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: #A2D9FF;">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <h3>Total Customers</h3>
                            <div class="stat-value">
                                <?php
                                $result = $conn->query("SELECT COUNT(*) as total FROM users");
                                $row = $result->fetch_assoc();
                                echo $row['total'];
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="recent-orders">
                    <h2>Recent Orders</h2>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th class='centered'>No</th>
                                    <th class='centered'>Payment</th>
                                    <th class='centered'>Status</th>
                                    <th class='centered'>More</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "
                                    SELECT o.id, p.name AS product_name, o.quantity, o.payment_method, ot.status, o.created_at, 
                                           u.fullname AS username, o.total_amount, 
                                           CONCAT(cld.address, ', ', cld.city) AS shipping_address, 
                                           cld.phone_no AS phone_number
                                    FROM orders o
                                    JOIN products p ON o.product_id = p.id
                                    JOIN order_tracking ot ON o.id = ot.order_id
                                    JOIN users u ON o.user_id = u.id
                                    JOIN `c.l.details` cld ON o.delivery_details_id = cld.id
                                    ORDER BY o.created_at DESC
                                    LIMIT 10"; 
                                
                                $result = $conn->query($query);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>
                                                <td style='text-align: left;'>{$row['product_name']}</td>
                                                <td class='centered'>{$row['quantity']}</td>
                                                <td class='centered'>{$row['payment_method']}</td>
                                                <td class='centered'>{$row['status']}</td>
                                                <td class='centered'><i class='fas fa-arrow-right' onclick='showOrderDetails({$row['id']})' style='cursor: pointer;'></i></td>
                                              </tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='5'>No recent orders found.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="right-sidebar">
                <div class="feedback-section">
                    <h2>AI Inventory Suggestions</h2>
                    <div class="feedback-items">
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer feedback will appear here...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Another feedback sample text...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Yet another feedback example...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer comments and suggestions...</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="analytics-section">
                    <h2>Analytics & Reports Overview</h2>
                    <div class="stats-overview">
                        <div class="stat-item">
                            <span class="stat-label">Monthly Sales:</span>
                            <span class="stat-value" id="overviewMonthlySales">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Total Customers:</span>
                            <span class="stat-value" id="overviewTotalCustomers">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Underperforming Products:</span>
                            <span class="stat-value" id="overviewUnderperformingProducts">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Low Stock Alerts:</span>
                            <span class="stat-value" id="overviewLowStockAlerts">Loading...</span>
                        </div>
                         <div class="stat-item">
                            <span class="stat-label">High Stock Items:</span>
                            <span class="stat-value" id="overviewHighStockItems">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div id="orderDetailsModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Order Details</h2>
            <div id="orderDetailsContent"></div>
        </div>
    </div>

    <style>
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
        backdrop-filter: blur(5px);
    }

    .modal-content {
        background-color: #1a1a1a;
        margin: 5% auto;
        padding: 25px;
        border: none;
        width: 80%;
        max-width: 600px;
        border-radius: 15px;
        position: relative;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    }

    .close {
        color: #888;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
        transition: color 0.3s ease;
    }

    .close:hover {
        color: #009688;
    }

    .modal-content h2 {
        color: #009688;
        margin-bottom: 20px;
        font-size: 24px;
        font-weight: 600;
        border-bottom: 2px solid rgba(0, 150, 136, 0.2);
        padding-bottom: 10px;
    }

    #orderDetailsContent {
        margin-top: 20px;
    }

    .order-detail-row {
        display: flex;
        justify-content: space-between;
        padding: 12px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        transition: background-color 0.3s ease;
    }

    .order-detail-row:hover {
        background-color: rgba(0, 150, 136, 0.1);
    }

    .order-detail-label {
        font-weight: 500;
        color: #888;
        font-size: 14px;
    }

    .order-detail-value {
        color: #fff;
        font-size: 14px;
        font-weight: 500;
    }

    .fa-arrow-right {
        color: #009688;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .fa-arrow-right:hover {
        color: #00796b;
        transform: translateX(3px);
    }

    .order-detail-value:contains('Order Placed') {
        color: #2196F3;
    }

    .order-detail-value:contains('Processing') {
        color: #FF9800;
    }

    .order-detail-value:contains('Shipped') {
        color: #9C27B0;
    }

    .order-detail-value:contains('Delivered') {
        color: #4CAF50;
    }

    .order-detail-value:contains('Cancelled') {
        color: #f44336;
    }

    .order-detail-value:contains('card') {
        color: #2196F3;
    }

    .order-detail-value:contains('cash') {
        color: #4CAF50;
    }

    .analytics-section h2 {
        color: #009688;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(0, 150, 136, 0.3);
    }

    .stats-overview {
        margin-top: 15px;
    }

    .stats-item {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-size: 0.95em;
    }

    .stats-item:last-child {
        border-bottom: none;
    }

    .stat-label {
        color: #ccc;
        font-weight: 500;
    }

    .stat-value {
        color: #009688;
        font-weight: bold;
    }

    .table-wrapper {
        border-radius: 25px;
        overflow: hidden;
        border-top-left-radius: 25px;
        border-top-right-radius: 25px;
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
        height: 400px; 
        overflow-y: auto; 
    }

    .table-wrapper::-webkit-scrollbar {
        width: 8px;
    }

    .table-wrapper::-webkit-scrollbar-track {
        background: rgba(0, 150, 136, 0.1);
        border-radius: 4px;
    }

    .table-wrapper::-webkit-scrollbar-thumb {
        background: rgba(0, 150, 136, 0.3);
        border-radius: 4px;
        transition: background 0.3s ease;
    }

    .table-wrapper::-webkit-scrollbar-thumb:hover {
        background: rgba(0, 150, 136, 0.5);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin: 0 auto;
        table-layout: fixed; 
    }

    thead {
        position: sticky; 
        top: 0;
        z-index: 1;
        background-color: rgba(0, 150, 136, 0.1);
        border-top-left-radius: 25px;
        border-top-right-radius: 25px;
        border-bottom: 1px solid #009688;
    }

    th {
        padding: 15px;
        text-align: left;
        font-size: 14px;
        font-weight: 600;
        color: #ffffff;
        border-bottom: 1px solid #009688;
        background-color: rgba(0, 150, 136, 0.1); 
    }

    th:nth-child(1), td:nth-child(1) { width: 30%; } /* Product Name */
    th:nth-child(2), td:nth-child(2) { width: 15%; } /* No */
    th:nth-child(3), td:nth-child(3) { width: 15%; } /* Payment */
    th:nth-child(4), td:nth-child(4) { width: 25%; } /* Status */
    th:nth-child(5), td:nth-child(5) { width: 15%; } /* More */

    td {
        padding: 15px;
        font-size: 14px;
        color: #e0e0e0;
        border-bottom: 1px solid #009688;
        white-space: nowrap; 
        overflow: hidden; 
        text-overflow: ellipsis;
    }
    </style>

    <script>
        let inactivityTime = function() {
            let time;
            let isHeld = false;
            
            window.onload = resetTimer;
            document.onmousemove = resetTimer;
            document.onkeydown = resetTimer;
            document.onclick = resetTimer;
            document.onscroll = resetTimer;
            
            function resetTimer() {
                if (!isHeld) {
                    clearTimeout(time);
                    time = setTimeout(logout, 300000);
                }
            }
            
            window.toggleHold = function() {
                const holdButton = document.querySelector('.hold-button');
                const holdText = document.getElementById('holdText');
                isHeld = !isHeld;
                
                sessionStorage.setItem('isHeld', isHeld);

                if (isHeld) {
                    holdButton.classList.add('active');
                    holdText.textContent = 'Cancel';
                    clearTimeout(time); 
                } else {
                    holdButton.classList.remove('active');
                    holdText.textContent = 'Hold';
                    resetTimer();
                }
            };
        };
        
        let isHeld = sessionStorage.getItem('isHeld') === 'true'; 
        const holdButton = document.querySelector('.hold-button');
        const holdText = document.getElementById('holdText');

        if (isHeld) {
            holdButton.classList.add('active');
            holdText.textContent = 'Cancel';
        } else {
            holdButton.classList.remove('active');
            holdText.textContent = 'Hold';
        }
        
        inactivityTime();
        
        function logout() {
            window.location.href = "logout.php";
        }
        
        window.addEventListener('beforeunload', function(e) {
            if (!window.location.href.includes('/admin/')) {
                e.preventDefault();
                e.returnValue = '';
                fetch('logout.php');
            }
        });
        
        setInterval(function() {
            fetch('check_session.php')
                .then(response => response.json())
                .then(data => {
                    if (!data.valid) {
                        window.location.href = "login.php?timeout=1";
                    }
                });
        }, 60000); 

        document.addEventListener('DOMContentLoaded', function() {
            const productsMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-box)');
            const productsSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-tag), .submenu-item:has(i.fa-box-archive)');
            
            productsMenuItem.addEventListener('click', function() {
                this.classList.toggle('active');
                
                productsSubmenuItems.forEach(item => {
                    if (this.classList.contains('active')) {
                        item.style.display = 'flex';
                        setTimeout(() => {
                            item.classList.add('show');
                        }, 10);
                    } else {
                        item.classList.remove('show');
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 300);
                    }
                });
            });

            if (productsMenuItem.classList.contains('active')) {
                productsSubmenuItems.forEach(item => {
                    item.style.display = 'flex'; 
                    setTimeout(() => {
                        item.classList.add('show');
                    }, 10);
                });
            }

            const newStocksMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-plus-circle)');
            const newStocksSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-dolly), .submenu-item:has(i.fa-truck-ramp-box)');

            if (newStocksMenuItem) {
                newStocksMenuItem.addEventListener('click', function() {
                    this.classList.toggle('active');

                    newStocksSubmenuItems.forEach(item => {
                        if (this.classList.contains('active')) {
                            item.style.display = 'flex';
                            setTimeout(() => {
                                item.classList.add('show');
                            }, 10);
                        } else {
                            item.classList.remove('show');
                            setTimeout(() => {
                                item.style.display = 'none';
                            }, 300);
                        }
                    });
                });
            }
        });

        function openCalendar() {
            flatpickr("#current-date", {
                dateFormat: "d/m/Y",
                onChange: function(selectedDates, dateStr, instance) {
                    document.getElementById("current-date").innerText = dateStr; 
                }
            }).open(); 
        }

        document.addEventListener("DOMContentLoaded", function() {
            const today = new Date();
            const options = { day: '2-digit', month: '2-digit', year: '2-digit' };
            document.getElementById("current-date").innerText = today.toLocaleDateString('en-GB', options);
        });

        function showOrderDetails(orderId) {
            fetch('get_order_details.php?id=' + orderId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const order = data.order;
                        const content = `
                            <div class="order-detail-row">
                                <span class="order-detail-label">Order ID:</span>
                                <span class="order-detail-value">#${order.id}</span>
                            </div>
                            <div class="order-detail-row">
                                <span class="order-detail-label">Customer:</span>
                                <span class="order-detail-value">${order.username}</span>
                            </div>
                            <div class="order-detail-row">
                                <span class="order-detail-label">Product:</span>
                                <span class="order-detail-value">${order.product_name}</span>
                            </div>
                            <div class="order-detail-row">
                                <span class="order-detail-label">Quantity:</span>
                                <span class="order-detail-value">${order.quantity}</span>
                            </div>
                            <div class="order-detail-row">
                                <span class="order-detail-label">Total Amount:</span>
                                <span class="order-detail-value">$${order.total_amount}</span>
                            </div>
                            <div class="order-detail-row">
                                <span class="order-detail-label">Payment Method:</span>
                                <span class="order-detail-value">${order.payment_method}</span>
                            </div>
                            <div class="order-detail-row">
                                <span class="order-detail-label">Status:</span>
                                <span class="order-detail-value">${order.status}</span>
                            </div>
                            <div class="order-detail-row">
                                <span class="order-detail-label">Shipping Address:</span>
                                <span class="order-detail-value">${order.shipping_address}</span>
                            </div>
                            <div class="order-detail-row">
                                <span class="order-detail-label">Phone Number:</span>
                                <span class="order-detail-value">${order.phone_number}</span>
                            </div>
                            <div class="order-detail-row">
                                <span class="order-detail-label">Order Date:</span>
                                <span class="order-detail-value">${new Date(order.created_at).toLocaleString()}</span>
                            </div>
                        `;
                        document.getElementById('orderDetailsContent').innerHTML = content;
                        document.getElementById('orderDetailsModal').style.display = 'block';
                    } else {
                        alert('Error fetching order details');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error fetching order details');
                });
        }

        document.querySelector('.close').onclick = function() {
            document.getElementById('orderDetailsModal').style.display = 'none';
        }

        window.onclick = function(event) {
            const modal = document.getElementById('orderDetailsModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }

        function fetchOverviewStats() {
            fetch('get_monthly_sales.php')
                .then(response => response.json())
                .then(data => {
                    const totalMonthlySales = data.values.reduce((sum, value) => sum + parseFloat(value), 0);
                    document.getElementById('overviewMonthlySales').textContent = `Rs. ${totalMonthlySales.toFixed(2)}`;
                }).catch(error => console.error('Error fetching monthly sales overview:', error));

            fetch('get_customer_stats.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewTotalCustomers').textContent = data.totalCustomers;
                }).catch(error => console.error('Error fetching customer stats overview:', error));

            fetch('get_product_performance.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewUnderperformingProducts').textContent = data.underperforming.length;
                }).catch(error => console.error('Error fetching product performance overview:', error));

            fetch('get_inventory_health.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewLowStockAlerts').textContent = data.restockAlerts.length;
                     document.getElementById('overviewHighStockItems').textContent = data.stockLevels.length;
                }).catch(error => console.error('Error fetching inventory health overview:', error));
        }

        fetchOverviewStats();
    </script>
</body>
</html>