<?php
session_start();
require_once 'conndb.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['tracking_number']) || !isset($_POST['new_status'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit();
}

$tracking_number = $_POST['tracking_number'];
$new_status = $_POST['new_status'];
$user_id = $_SESSION['user_id'];

$update_query = "UPDATE order_tracking ot 
                 JOIN orders o ON ot.order_id = o.id 
                 SET ot.status = ? 
                 WHERE ot.tracking_number = ? AND o.user_id = ?";

$stmt = $conn->prepare($update_query);
$stmt->bind_param("ssi", $new_status, $tracking_number, $user_id);
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Order status updated successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update order status.']);
}

$stmt->close();
$conn->close();
?>