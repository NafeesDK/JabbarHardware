<?php
session_start();
include '../conndb.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['id'] ?? null;

    if (!$product_id) {
        echo json_encode(['success' => false, 'message' => 'Product ID not provided']);
        exit();
    }

    $image_query = "SELECT image_url FROM products WHERE id = ?";
    $stmt_img = $conn->prepare($image_query);
    $stmt_img->bind_param("i", $product_id);
    $stmt_img->execute();
    $result_img = $stmt_img->get_result();
    $image_url = null;
    if ($row_img = $result_img->fetch_assoc()) {
        $image_url = $row_img['image_url'];
    }
    $stmt_img->close();

    $conn->begin_transaction();
    
    $delete_suppliers_query = "DELETE FROM product_suppliers WHERE product_id = ?";
    $stmt_delete_suppliers = $conn->prepare($delete_suppliers_query);
    $stmt_delete_suppliers->bind_param("i", $product_id);
    if (!$stmt_delete_suppliers->execute()) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Error deleting related suppliers: ' . $stmt_delete_suppliers->error]);
        exit();
    }
    $stmt_delete_suppliers->close();

    $delete_cart_query = "DELETE FROM cart WHERE product_id = ?";
    $stmt_delete_cart = $conn->prepare($delete_cart_query);
    $stmt_delete_cart->bind_param("i", $product_id);
    if (!$stmt_delete_cart->execute()) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Error deleting related cart items: ' . $stmt_delete_cart->error]);
        exit();
    }
    $stmt_delete_cart->close();

    $delete_query = "DELETE FROM products WHERE id = ?";
    $stmt_delete = $conn->prepare($delete_query);
    $stmt_delete->bind_param("i", $product_id);

    if ($stmt_delete->execute()) {
        $image_deleted_success = true;
        if ($image_url && strpos($image_url, 'Image/') === 0) {
            $file_path = __DIR__ . '/../' . $image_url;
            if (file_exists($file_path)) {
                if (!unlink($file_path)) {
                    error_log("Failed to delete product image file: " . $file_path);
                    $image_deleted_success = false;
                }
            } else {
                 error_log("Product image file not found for deletion: " . $file_path);
                 $image_deleted_success = false;
            }
        }

        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Product deleted successfully' . ($image_deleted_success ? '' : ' (Warning: Image file not deleted)')]);

    } else {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'deletin_product: ' . $stmt_delete->error]);
    }

    $stmt_delete->close();

} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?> 