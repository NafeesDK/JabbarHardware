<?php
session_start();
header('Content-Type: application/json');

$response = array(
    'valid' => isset($_SESSION['admin_id']) && 
              isset($_SESSION['last_activity']) && 
              (time() - $_SESSION['last_activity'] <= 300)
);

echo json_encode($response);
?>