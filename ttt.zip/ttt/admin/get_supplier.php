<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $supplier_id = intval($_GET['id']);
    
    $query = "SELECT id, name, address, contact_info, email FROM suppliers WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $supplier_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $supplier = $result->fetch_assoc();
        echo json_encode([
            'success' => true,
            'supplier' => $supplier
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Supplier not found'
        ]);
    }
    
    $stmt->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request'
    ]);
}
?> 