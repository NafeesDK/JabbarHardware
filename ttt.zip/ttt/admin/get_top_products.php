<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$query = "SELECT 
            p.name,
            SUM(o.quantity) as total_sales
          FROM orders o
          JOIN products p ON o.product_id = p.id
          WHERE o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
          GROUP BY p.id, p.name
          ORDER BY total_sales DESC
          LIMIT 3";

$result = $conn->query($query);
$products = [];

while ($row = $result->fetch_assoc()) {
    $products[] = [
        'name' => $row['name'],
        'sales' => intval($row['total_sales'])
    ];
}

header('Content-Type: application/json');
echo json_encode($products);
?> 