<?php
session_start();
include '../conndb.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if (empty($username) || empty($password)) {
        $error = "Username and password are required";
    } else {
        $query = "SELECT id, username, password, full_name, profile_image, role FROM admins WHERE username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['full_name'];
                $_SESSION['admin_profile_image'] = $admin['profile_image'];
                $_SESSION['admin_role'] = $admin['role'];
                $_SESSION['last_activity'] = time();
                
                header("Location: aaa.php");
                exit();
            } else {
                $error = "Invalid password";
            }
        } else {
            $error = "Invalid username";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Jabbar</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }
        
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(0, 0, 0, 0.80);
            background-image: url('../logoo.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        
        .login-modal {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(8px);
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .login-container {
            width: 400px;
            background-color: rgba(0, 0, 0, 0.75);
            border-radius: 25px;
            box-shadow: 0 0 20px rgba(0, 150, 136, 0.5);
            padding: 40px;
            color: #ffffff;
            border: 2px solid #009688;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            animation: slideIn 0.4s ease-out;
        }

        @keyframes slideIn {
            from { transform: translate(-50%, -60%); opacity: 0; }
            to { transform: translate(-50%, -50%); opacity: 1; }
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-header .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }
        
        .logo-letter {
            font-size: 36px;
            font-weight: 700;
            color: #ffffff;
        }
        
        .logo-text {
            font-size: 28px;
            font-weight: 700;
            color: #009688;
            margin-left: 5px;
        }
        
        h2 {
            color: #009688;
            font-size: 24px;
            font-weight: 600;
        }
        
        .login-form {
            display: flex;
            flex-direction: column;
        }
        
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #e0e0e0;
        }
        
        .form-group i {
            position: absolute;
            top: 40px;
            left: 15px;
            color: #009688;
        }
        
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid #009688;
            border-radius: 25px;
            background-color: rgba(0, 0, 0, 0.5);
            color: #ffffff;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            box-shadow: 0 0 8px rgba(0, 150, 136, 0.7);
        }
        
        .remember-me {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .remember-me input {
            margin-right: 10px;
        }
        
        button.login-btn {
            background-color: #009688;
            color: #ffffff;
            border: none;
            border-radius: 25px;
            padding: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        button.login-btn:hover {
            background-color: #00796b;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 150, 136, 0.4);
        }
        
        .error-message {
            background-color: rgba(255, 73, 73, 0.2);
            border-left: 3px solid #ff4949;
            padding: 10px;
            margin-bottom: 20px;
            color: #ff4949;
            border-radius: 3px;
        }
        
        .timeout-message {
            background-color: rgba(255, 152, 0, 0.2);
            border-left: 3px solid #ff9800;
            padding: 10px;
            margin-bottom: 20px;
            color: #ff9800;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <div class="login-modal">
        <div class="login-container">
            <div class="login-header">
                <div class="logo">
                    <span class="logo-letter">J</span>
                    <span class="logo-text">ABBAR</span>
                </div>
                <h2>Admin Login</h2>
            </div>
            
            <?php if (isset($error)): ?>
                <div class="error-message">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['timeout']) && $_GET['timeout'] == 1): ?>
                <div class="timeout-message">
                    Your session has expired due to inactivity. Please login again.
                </div>
            <?php endif; ?>
            
            <form class="login-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="username">Username</label>
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" name="username" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <div class="remember-me">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">Remember me</label>
                </div>
                
                <button type="submit" class="login-btn">Login</button>
            </form>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelector('.login-modal').style.display = 'block';
        });
    </script>
</body>
</html>