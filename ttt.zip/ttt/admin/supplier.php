<?php
require_once 'access_control.php';
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$inactive = 300; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $inactive)) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}
$_SESSION['last_activity'] = time(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jabbar Admin Dashboard</title>
    <link rel="stylesheet" href="ccc.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>
<body>
    <div id="page1">
        <div class="container">
            <div class="sidebar">
                <div class="logo">
                    <span class="logo-letter">J</span>
                    <span class="logo-text">ABBAR</span>
                </div>
                
                <div class="menu">
                    <div class="menu-item" onclick="window.location.href='aaa.php'">
                        <i class="fas fa-home"></i>
                        <span>Home</span>
                    </div>
                    
                    <div class="menu-item has-submenu">
                        <i class="fas fa-box"></i>
                        <span>Products</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='products.php?type=offers'" style="display: none;">
                        <i class="fas fa-tag"></i>
                        <span>Offers</span>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='products.php?type=regular'" style="display: none;">
                        <i class="fas fa-box-archive"></i>
                        <span>Regular</span>
                    </div>
                    
                    <div class="menu-item active">
                        <i class="fas fa-truck"></i>
                        <span>Suppliers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='customer.php'">
                        <i class="fas fa-users"></i>
                        <span>View Customers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='inventory.php'">
                        <i class="fas fa-boxes"></i>
                        <span>Inventory Management</span>
                    </div>

                    <div class="menu-item has-submenu">
                        <i class="fas fa-plus-circle"></i>
                        <span>New Stocks</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='new_stocks.php?action=new'" style="display: none;">
                        <i class="fas fa-dolly"></i>
                        <span>New Product</span>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='new_stocks.php?action=restock'" style="display: none;">
                        <i class="fas fa-truck-ramp-box"></i>
                        <span>Restock</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='feedback.php'">
                        <i class="fas fa-comment"></i>
                        <span>Feedback Management</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='AandR.php'">
                        <i class="fas fa-chart-bar"></i>
                        <span>Analytics & Reports</span>
                    </div>
                </div>

                <div class="sidebar-bottom">
                    <div class="menu-item hold-button" onclick="toggleHold()">
                        <i class="fas fa-pause-circle"></i>
                        <span id="holdText">Hold</span>
                    </div>
                    
                    <div class="logout" onclick="logout()">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </div>
                </div>
            </div>
            
            <div class="main-content">
                <div class="header">
                    <div class="user-profile">
                        <div class="user-info">
                            <span class="user-name"><?php echo $_SESSION['admin_username']; ?></span>
                        </div>
                        <div class="avatar">
                            <?php if (!empty($_SESSION['admin_profile_image'])): ?>
                                <img src="./AdminPix/<?php echo $_SESSION['admin_profile_image']; ?>" alt="Admin Avatar">
                            <?php else: ?>
                                <img src="./AdminPix/image.webp" alt="Admin Avatar">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="suppliers-list">
                    <h2>Suppliers Management</h2>
                    <div class="table-container">
                        <div class="table-header">
                            <table>
                                <thead>
                                    <tr>
                                        <th style='text-align: left;'>Supplier ID</th>
                                        <th>Supplier Name</th>
                                        <th>Address</th>
                                        <th>Contact Info</th>
                                        <th>Joined At</th>
                                        <th>Total Products</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                        <div class="table-body">
                            <table>
                                <tbody>
                                    <?php
                                    $query = "SELECT s.*, 
                                             GROUP_CONCAT(DISTINCT p.id) as product_ids,
                                             COUNT(DISTINCT p.id) as total_products 
                                             FROM suppliers s 
                                             LEFT JOIN product_suppliers ps ON s.id = ps.supplier_id 
                                             LEFT JOIN products p ON ps.product_id = p.id 
                                             GROUP BY s.id";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            echo "<tr data-supplier-id='{$row['id']}'>";
                                            echo "<td>{$row['id']}</td>";
                                            echo "<td style='text-align: center;'>{$row['name']}</td>";
                                            echo "<td style='text-align: center;'>{$row['address']}</td>";
                                            echo "<td style='text-align: center;'>{$row['contact_info']}<br><small style='color: #666; font-size: 16px;'>{$row['email']}</small></td>";
                                            echo "<td style='text-align: center;'>{$row['joined_at']}</td>";
                                            echo "<td style='text-align: center;'>{$row['total_products']}</td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='6' style='text-align: center;'>No suppliers found.</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="supplier-actions">
                            <button onclick="openAddModal()" class="action-btn add-btn"><i class="fas fa-plus"></i> Add Supplier</button>
                            <button onclick="openUpdateModal(selectedSupplierId)" class="action-btn edit-btn"><i class="fas fa-edit"></i> Edit</button>
                            <button onclick="openDeleteModal(selectedSupplierId)" class="action-btn delete-btn"><i class="fas fa-trash"></i> Delete</button>
                            <button onclick="openAssignModal(selectedSupplierId)" class="action-btn assign-btn"><i class="fas fa-link"></i> Assign Products</button>
                        </div>
                    </div>
                </div>

                <div id="addSupplierModal" class="modal">
                    <div class="modal-content">
                        <span class="close" onclick="closeModal('addSupplierModal')">&times;</span>
                        <h2>Add New Supplier</h2>
                        <form id="addSupplierForm" action="add_supplier.php" method="POST">
                            <div class="form-group">
                                <label for="supplierName">Supplier Name:</label>
                                <input type="text" id="supplierName" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="supplierAddress">Address:</label>
                                <textarea id="supplierAddress" name="address" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="supplierContact">Contact Info:</label>
                                <input type="text" id="supplierContact" name="contact_info" required>
                            </div>
                            <div class="form-group">
                                <label for="supplierEmail">Email:</label>
                                <input type="email" id="supplierEmail" name="email" required>
                            </div>
                            <button type="submit" class="submit-btn">Add Supplier</button>
                        </form>
                    </div>
                </div>

                <div id="updateSupplierModal" class="modal">
                    <div class="modal-content">
                        <span class="close" onclick="closeModal('updateSupplierModal')">&times;</span>
                        <h2>Update Supplier</h2>
                        <form id="updateSupplierForm" action="update_supplier.php" method="POST">
                            <input type="hidden" id="updateSupplierId" name="id">
                            <div class="form-group">
                                <label for="updateSupplierName">Supplier Name:</label>
                                <input type="text" id="updateSupplierName" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="updateSupplierAddress">Address:</label>
                                <textarea id="updateSupplierAddress" name="address" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="updateSupplierContact">Contact Info:</label>
                                <input type="text" id="updateSupplierContact" name="contact_info" required>
                            </div>
                            <div class="form-group">
                                <label for="updateSupplierEmail">Email:</label>
                                <input type="email" id="updateSupplierEmail" name="email" required>
                            </div>
                            <button type="submit" class="submit-btn">Update Supplier</button>
                        </form>
                    </div>
                </div>

                <div id="deleteSupplierModal" class="modal">
                    <div class="modal-content">
                        <span class="close" onclick="closeModal('deleteSupplierModal')">&times;</span>
                        <h2>Delete Supplier</h2>
                        <p>Are you sure you want to delete this supplier?</p>
                        <form id="deleteSupplierForm" action="delete_supplier.php" method="POST">
                            <input type="hidden" id="deleteSupplierId" name="id">
                            <div class="button-group">
                                <button type="submit" class="delete-btn">Delete</button>
                                <button type="button" class="cancel-btn" onclick="closeModal('deleteSupplierModal')">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div id="assignProductsModal" class="modal">
                    <div class="modal-content">
                        <span class="close" onclick="closeModal('assignProductsModal')">&times;</span>
                        <h2>Assign Low Stock Products</h2>
                        <p>Select products with stock quantity less than 5 to assign to this supplier:</p>
                        <form id="assignProductsForm" action="assign_products.php" method="POST">
                            <input type="hidden" id="assignSupplierId" name="supplier_id">
                            <input type="hidden" id="selectedProductIds" name="products">
                            <div class="form-group">
                                <label>Select Products:</label>
                                <div class="product-list">
                                    <?php
                                    $query = "SELECT p.id, p.name, p.stock_quantity, 
                                             GROUP_CONCAT(s.name) as current_suppliers
                                             FROM products p 
                                             LEFT JOIN product_suppliers ps ON p.id = ps.product_id 
                                             LEFT JOIN suppliers s ON ps.supplier_id = s.id 
                                             WHERE p.stock_quantity < 5 
                                             GROUP BY p.id";
                                    $result = $conn->query($query);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            echo "<div class='product-item selectable' data-product-id='{$row['id']}'>";
                                            echo "<label>{$row['name']} (Current Stock: {$row['stock_quantity']})";
                                            if ($row['current_suppliers']) {
                                                echo "<br><small>Current Suppliers: {$row['current_suppliers']}</small>";
                                            }
                                            echo "</label>";
                                            echo "</div>";
                                        }
                                    } else {
                                        echo "<p>No low stock products available for assignment.</p>";
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="button-group">
                                <button type="submit" class="submit-btn">Assign Products</button>
                                <button type="button" class="cancel-btn" onclick="closeModal('assignProductsModal')">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="right-sidebar">
                <div class="feedback-section">
                    <h2>AI Inventory Suggestions</h2>
                    <div class="feedback-items">
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer feedback will appear here...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Another feedback sample text...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Yet another feedback example...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer comments and suggestions...</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="analytics-section">
                    <h2>Analytics & Reports Overview</h2>
                    <div class="stats-overview">
                        <div class="stat-item">
                            <span class="stat-label">Monthly Sales:</span>
                            <span class="stat-value" id="overviewMonthlySales">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Total Customers:</span>
                            <span class="stat-value" id="overviewTotalCustomers">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Underperforming Products:</span>
                            <span class="stat-value" id="overviewUnderperformingProducts">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Low Stock Alerts:</span>
                            <span class="stat-value" id="overviewLowStockAlerts">Loading...</span>
                        </div>
                         <div class="stat-item">
                            <span class="stat-label">High Stock Items:</span>
                            <span class="stat-value" id="overviewHighStockItems">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let inactivityTime = function() {
            let time;
            let isHeld = false;
            
            window.onload = resetTimer;
            document.onmousemove = resetTimer;
            document.onkeydown = resetTimer;
            document.onclick = resetTimer;
            document.onscroll = resetTimer;
            
            function resetTimer() {
                if (!isHeld) {
                    clearTimeout(time);
                    time = setTimeout(logout, 300000);
                }
            }
            
            window.toggleHold = function() {
                const holdButton = document.querySelector('.hold-button');
                const holdText = document.getElementById('holdText');
                isHeld = !isHeld;
                
                sessionStorage.setItem('isHeld', isHeld);

                if (isHeld) {
                    holdButton.classList.add('active');
                    holdText.textContent = 'Cancel';
                    clearTimeout(time); 
                } else {
                    holdButton.classList.remove('active');
                    holdText.textContent = 'Hold';
                    resetTimer(); 
                }
            };
        };
        
        let isHeld = sessionStorage.getItem('isHeld') === 'true'; 
        const holdButton = document.querySelector('.hold-button');
        const holdText = document.getElementById('holdText');

        if (isHeld) {
            holdButton.classList.add('active');
            holdText.textContent = 'Cancel';
        } else {
            holdButton.classList.remove('active');
            holdText.textContent = 'Hold';
        }

        inactivityTime(); 
        
        function logout() {
            window.location.href = "logout.php";
        }
        
        window.addEventListener('beforeunload', function(e) {
            if (!window.location.href.includes('/admin/')) {
                e.preventDefault();
                e.returnValue = '';
                fetch('logout.php');
            }
        });
        
        setInterval(function() {
            fetch('check_session.php')
                .then(response => response.json())
                .then(data => {
                    if (!data.valid) {
                        window.location.href = "login.php?timeout=1";
                    }
                });
        }, 60000);

        document.addEventListener('DOMContentLoaded', function() {
            // Products submenu
            const productsMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-box)');
            const productsSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-tag), .submenu-item:has(i.fa-box-archive)');
            
            productsMenuItem.addEventListener('click', function() {
                this.classList.toggle('active');
                
                productsSubmenuItems.forEach(item => {
                    if (this.classList.contains('active')) {
                        item.style.display = 'flex';
                        setTimeout(() => {
                            item.classList.add('show');
                        }, 10);
                    } else {
                        item.classList.remove('show');
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 300);
                    }
                });
            });

            if (productsMenuItem.classList.contains('active')) {
                productsSubmenuItems.forEach(item => {
                    item.style.display = 'flex'; 
                    setTimeout(() => {
                        item.classList.add('show');
                    }, 10);
                });
            }

            // New Stocks submenu
            const newStocksMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-plus-circle)');
            const newStocksSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-dolly), .submenu-item:has(i.fa-truck-ramp-box)');

            if (newStocksMenuItem) {
                newStocksMenuItem.addEventListener('click', function() {
                    this.classList.toggle('active');

                    newStocksSubmenuItems.forEach(item => {
                        if (this.classList.contains('active')) {
                            item.style.display = 'flex';
                            setTimeout(() => {
                                item.classList.add('show');
                            }, 10);
                        } else {
                            item.classList.remove('show');
                            setTimeout(() => {
                                item.style.display = 'none';
                            }, 300);
                        }
                    });
                });
            }
        });

        let selectedSupplierId = null;

        document.addEventListener('DOMContentLoaded', function() {
            const supplierTable = document.querySelector('.table-body table tbody');
            const editBtn = document.querySelector('.edit-btn');
            const deleteBtn = document.querySelector('.delete-btn');
            const assignBtn = document.querySelector('.assign-btn');

            supplierTable.addEventListener('click', function(event) {
                const targetRow = event.target.closest('tr');
                if (!targetRow) return;

                const previouslySelected = supplierTable.querySelector('tr.selected');
                if (previouslySelected) {
                    previouslySelected.classList.remove('selected');
                }

                targetRow.classList.add('selected');
                selectedSupplierId = targetRow.dataset.supplierId;

                editBtn.disabled = false;
                deleteBtn.disabled = false;
                assignBtn.disabled = false;
            });

            editBtn.addEventListener('click', function() {
                if (selectedSupplierId) {
                    openUpdateModal(selectedSupplierId);
                }
            });

            deleteBtn.addEventListener('click', function() {
                if (selectedSupplierId) {
                    openDeleteModal(selectedSupplierId);
                }
            });

            assignBtn.addEventListener('click', function() {
                if (selectedSupplierId) {
                    openAssignModal(selectedSupplierId);
                }
            });

            editBtn.disabled = true;
            deleteBtn.disabled = true;
            assignBtn.disabled = true;
        });

        function openAddModal() {
            document.getElementById('addSupplierModal').style.display = 'block';
        }

        function openUpdateModal(supplierId) {
            if (!supplierId) {
                alert('Please select a supplier first');
                return;
            }
            
            fetch('get_supplier.php?id=' + supplierId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const supplier = data.supplier;
                        document.getElementById('updateSupplierId').value = supplier.id;
                        document.getElementById('updateSupplierName').value = supplier.name;
                        document.getElementById('updateSupplierAddress').value = supplier.address;
                        document.getElementById('updateSupplierContact').value = supplier.contact_info;
                        document.getElementById('updateSupplierEmail').value = supplier.email;
                        document.getElementById('updateSupplierModal').style.display = 'block';
                    } else {
                        alert(data.message || 'Error fetching supplier details');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error fetching supplier details');
                });
        }

        function openDeleteModal(supplierId) {
            document.getElementById('deleteSupplierId').value = supplierId;
            document.getElementById('deleteSupplierModal').style.display = 'block';
        }

        function openAssignModal(supplierId) {
            document.getElementById('assignSupplierId').value = supplierId;
            document.getElementById('assignProductsModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        document.getElementById('addSupplierForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('add_supplier.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeModal('addSupplierModal');
                    location.reload();
                } else {
                    alert(data.message || 'Error adding supplier');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error adding supplier');
            });
        });

        document.getElementById('updateSupplierForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('update_supplier.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeModal('updateSupplierModal');
                    location.reload();
                } else {
                    alert(data.message || 'Error updating supplier');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error updating supplier');
            });
        });

        document.getElementById('deleteSupplierForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('delete_supplier.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeModal('deleteSupplierModal');
                    location.reload();
                } else {
                    alert(data.message || 'Error deleting supplier');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error deleting supplier');
            });
        });

        document.getElementById('assignProductsForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('assign_products.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeModal('assignProductsModal');
                    location.reload();
                } else {
                    alert(data.message || 'Error assigning products');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error assigning products');
            });
        });

        document.addEventListener('DOMContentLoaded', function() {
            const productList = document.querySelector('.product-list');
            const selectedProductIdsInput = document.getElementById('selectedProductIds');
            let selectedProductIds = [];

            productList.addEventListener('click', function(event) {
                const productItem = event.target.closest('.product-item.selectable');
                if (!productItem) return;

                const productId = productItem.dataset.productId;
                const index = selectedProductIds.indexOf(productId);

                if (index === -1) {
                    selectedProductIds.push(productId);
                    productItem.classList.add('selected-product');
                } else {
                    selectedProductIds.splice(index, 1);
                    productItem.classList.remove('selected-product');
                }

                selectedProductIdsInput.value = selectedProductIds.join(',');
            });
        });

        // Function to fetch and display overview stats in right sidebar
        function fetchOverviewStats() {
            // Fetch Monthly Sales
            fetch('get_monthly_sales.php')
                .then(response => response.json())
                .then(data => {
                    const totalMonthlySales = data.values.reduce((sum, value) => sum + parseFloat(value), 0);
                    document.getElementById('overviewMonthlySales').textContent = `Rs. ${totalMonthlySales.toFixed(2)}`;
                }).catch(error => console.error('Error fetching monthly sales overview:', error));

            // Fetch Total Customers
            fetch('get_customer_stats.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewTotalCustomers').textContent = data.totalCustomers;
                }).catch(error => console.error('Error fetching customer stats overview:', error));

            // Fetch Product Performance (Underperforming)
            fetch('get_product_performance.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewUnderperformingProducts').textContent = data.underperforming.length;
                }).catch(error => console.error('Error fetching product performance overview:', error));

            // Fetch Inventory Health (Low Stock Alerts)
            fetch('get_inventory_health.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewLowStockAlerts').textContent = data.restockAlerts.length;
                     document.getElementById('overviewHighStockItems').textContent = data.stockLevels.length;
                }).catch(error => console.error('Error fetching inventory health overview:', error));
        }

        // Call the function to fetch and display overview stats on page load
        fetchOverviewStats();
    </script>

    <style>
    .table-container {
        position: relative;
        height: calc(100vh - 150px); 
        overflow: hidden;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-radius: 25px;
        display: flex;
        flex-direction: column;
    }

    .table-header {
        flex-shrink: 0;
        background-color: rgba(0, 150, 136, 0.1);
        border-top-left-radius: 25px;
        border-top-right-radius: 25px;
    }

    .table-header table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .table-header th {
        padding: 12px 15px;
        text-align: center;
        color: white;
        width: auto;
    }

    .table-header th:nth-child(1), .table-body td:nth-child(1) {
        width: 8%;
    }

    .table-header th:nth-child(2), .table-body td:nth-child(2) {
        width: 20%;
    }

    .table-header th:nth-child(3), .table-body td:nth-child(3) {
        width: 25%;
    }

    .table-header th:nth-child(4), .table-body td:nth-child(4) {
        width: 25%;
    }

    .table-header th:nth-child(5), .table-body td:nth-child(5) {
        width: 12%;
    }

    .table-header th:nth-child(6), .table-body td:nth-child(6) {
        width: 10%;
    }

    .table-body {
        flex-grow: 1;
        overflow-y: auto;
    }

    .table-body::-webkit-scrollbar {
        width: 8px;
    }

    .table-body::-webkit-scrollbar-track {
        background: rgba(0, 150, 136, 0.1);
        border-radius: 4px;
    }

    .table-body::-webkit-scrollbar-thumb {
        background: rgba(0, 150, 136, 0.3);
        border-radius: 4px;
        transition: background 0.3s ease;
    }

    .table-body::-webkit-scrollbar-thumb:hover {
        background: rgba(0, 150, 136, 0.5);
    }

    .table-body {
        scrollbar-width: thin;
        scrollbar-color: rgba(0, 150, 136, 0.3) rgba(0, 150, 136, 0.1);
    }

    .table-body table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .table-body td {
         padding: 12px 15px;
         text-align: left;
         white-space: normal;
    }

    .table-body td:nth-child(2),
    .table-body td:nth-child(3),
    .table-body td:nth-child(4),
    .table-body td:nth-child(5),
    .table-body td:nth-child(6) {
        text-align: center;
    }

    .supplier-actions {
        position: relative;
        flex-shrink: 0;
        background: rgba(0, 150, 136, 0.1);
        padding: 15px;
        display: flex;
        justify-content: center;
        gap: 15px;
        border-top: 1px solid #e0e0e0;
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        border-bottom-left-radius: 25px;
        border-bottom-right-radius: 25px;
    }

    .action-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background: #4CAF50;
        color: white;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .action-btn:hover {
        background: #45a049;
    }

    .action-btn:disabled {
        background: #cccccc;
        cursor: not-allowed;
        opacity: 0.7;
    }

    .action-btn:disabled:hover {
        background: #cccccc;
    }

    .action-btn i {
        font-size: 14px;
    }
    
    .action-btn.add-btn {
        background: #4CAF50;
    }

    .action-btn.add-btn:hover {
        background: #45a049;
    }

    .action-btn.edit-btn {
        background: #2196F3;
    }

    .action-btn.edit-btn:hover {
        background: #1976D2;
    }

    .action-btn.delete-btn {
        background: #f44336;
    }

    .action-btn.delete-btn:hover {
        background: #d32f2f;
    }

    .action-btn.assign-btn {
        background: #9C27B0;
    }

    .action-btn.assign-btn:hover {
        background: #7B1FA2;
    }

    .table-body tr {
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .table-body tr:hover {
        background-color: rgba(0, 150, 136, 0.1);
    }

    .table-body tr.selected {
        background-color: rgba(0, 150, 136, 0.2);
        border-left: 4px solid #009688;
    }

    .table-body tr.selected td {
        color: #009688;
    }

    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
    }

    .modal-content {
        background-color: rgba(0, 0, 0, 0.9);
        margin: 5% auto;
        padding: 20px;
        border: 2px solid #009688;
        border-radius: 25px;
        width: 80%;
        max-width: 600px;
        color: white;
        position: relative;
    }

    .close {
        color: #ff6b6b;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    .close:hover {
        transform: rotate(90deg);
        color: #ff4f4f;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        color: #009688;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #009688;
        border-radius: 5px;
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
    }

    .form-group textarea {
        height: 60px;
        resize: vertical;
        min-height: 60px;
        max-height: 120px;
    }

    .submit-btn,
    .delete-btn,
    .cancel-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    .submit-btn {
        background-color: #009688;
        color: white;
    }

    .submit-btn:hover {
        background-color: #00796b;
    }

    .delete-btn {
        background-color: #f44336;
        color: white;
    }

    .delete-btn:hover {
        background-color: #d32f2f;
    }

    .cancel-btn {
        background-color: #757575;
        color: white;
    }

    .cancel-btn:hover {
        background-color: #616161;
    }

    .button-group {
        display: flex;
        gap: 10px;
        justify-content: flex-end;
    }

    small {
        color: #757575;
        font-size: 12px;
    }

    .product-list {
        max-height: 300px;
        overflow-y: auto;
        border: 1px solid #ddd;
        padding: 10px;
        border-radius: 4px;
    }

    .product-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 5px 0;
        cursor: pointer;
        transition: background-color 0.2s ease;
    }

    .product-item:hover {
        background-color: rgba(0, 150, 136, 0.1);
    }

    .product-item.selected-product {
        background-color: rgba(0, 150, 136, 0.3);
        border-left: 3px solid #009688;
        padding-left: 7px;
    }

    .analytics-section h2 {
        color: #009688;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(0, 150, 136, 0.3);
    }

    .stats-overview {
        margin-top: 15px;
    }

    .stats-item {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-size: 0.95em;
    }

    .stats-item:last-child {
        border-bottom: none;
    }

    .stat-label {
        color: #ccc;
        font-weight: 500;
    }

    .stat-value {
        color: #009688;
        font-weight: bold;
    }
    </style>
</body>
</html>