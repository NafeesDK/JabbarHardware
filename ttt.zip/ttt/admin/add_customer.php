<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

if (!isset($_GET['id'])) {
    die(json_encode(['success' => false, 'message' => 'No customer ID provided']));
}

$id = intval($_GET['id']);
$query = "SELECT id, fullname, email FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode(['success' => true, 'customer' => $row]);
} else {
    echo json_encode(['success' => false, 'message' => 'Customer not found']);
}