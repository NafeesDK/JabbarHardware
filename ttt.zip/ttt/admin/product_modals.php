<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>

<div id="addProductModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Add New Product</h2>
        <form id="addProductForm" action="add_product.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="productName">Product Name:</label>
                <input type="text" id="productName" name="name" required>
            </div>
            <div class="form-group">
                <label for="productDescription">Description:</label>
                <textarea id="productDescription" name="description" required></textarea>
            </div>
            <div class="form-group">
                <label for="originalPrice">Original Price:</label>
                <input type="number" id="originalPrice" name="original_price" step="0.01" required>
            </div>
            <input type="hidden" id="productCategory" name="category" value="<?php echo (isset($_GET['type']) && $_GET['type'] === 'offers') ? 'offer' : 'regular'; ?>">
            <div class="form-group" id="discountedPriceGroup" style="display: <?php echo (isset($_GET['type']) && $_GET['type'] === 'offers') ? 'block' : 'none'; ?>;">
                <label for="discountedPrice">Discounted Price:</label>
                <input type="number" id="discountedPrice" name="discounted_price" step="0.01">
            </div>
            <div class="form-group">
                <label for="stockQuantity">Stock Quantity:</label>
                <input type="number" id="stockQuantity" name="stock_quantity" min="0" required>
            </div>
            <div class="form-group">
                <label for="productImage">Product Image:</label>
                <input type="file" id="productImage" name="image" accept="image/*" required>
            </div>
            <div class="form-group">
                <label for="supplier">Supplier:</label>
                <select id="supplier" name="supplier_id" required>
                    <?php
                    $suppliers_query = "SELECT id, name FROM suppliers";
                    $suppliers_result = $conn->query($suppliers_query);
                    while ($supplier = $suppliers_result->fetch_assoc()) {
                        echo "<option value='{$supplier['id']}'>{$supplier['name']}</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="submit-btn">Add Product</button>
        </form>
    </div>
</div>

<div id="updateProductModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Update Product</h2>
        <form id="updateProductForm" action="update_product.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" id="updateProductId" name="product_id">
            <div class="form-group">
                <label for="updateProductName">Product Name:</label>
                <input type="text" id="updateProductName" name="name" required>
            </div>
            <div class="form-group">
                <label for="updateProductDescription">Description:</label>
                <textarea id="updateProductDescription" name="description" required></textarea>
            </div>
            <div class="form-group">
                <label for="updateOriginalPrice">Original Price:</label>
                <input type="number" id="updateOriginalPrice" name="original_price" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="updateProductCategory">Category:</label>
                <select id="updateProductCategory" name="category" required>
                    <option value="regular">Regular</option>
                    <option value="offer">Offer</option>
                </select>
            </div>
            <div class="form-group" id="updateDiscountedPriceGroup">
                <label for="updateDiscountedPrice">Discounted Price:</label>
                <input type="number" id="updateDiscountedPrice" name="discounted_price" step="0.01">
            </div>
            <div class="form-group">
                <label for="updateProductImage">Product Image:</label>
                <input type="file" id="updateProductImage" name="image" accept="image/*">
                <small>Leave empty to keep current image</small>
            </div>
            <div class="form-group">
                <label for="updateSupplier">Supplier:</label>
                <select id="updateSupplier" name="supplier_id" required>
                    <?php
                    $suppliers_result->data_seek(0);
                    while ($supplier = $suppliers_result->fetch_assoc()) {
                        echo "<option value='{$supplier['id']}'>{$supplier['name']}</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="submit-btn">Update Product</button>
        </form>
    </div>
</div>

<div id="deleteProductModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Delete Product</h2>
        <p>Are you sure you want to delete this product?</p>
        <form id="deleteProductForm" action="delete_product.php" method="POST">
            <input type="hidden" id="deleteProductId" name="id">
            <div class="button-group">
                <button type="submit" class="delete-btn">Delete</button>
                <button type="button" class="cancel-btn" onclick="closeModal('deleteProductModal')">Cancel</button>
            </div>
        </form>
    </div>
</div>

<style>
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
}

.modal-content {
    background-color: rgba(0, 0, 0, 0.9);
    margin: 5% auto;
    padding: 20px;
    border: 2px solid #009688;
    border-radius: 25px;
    width: 80%;
    max-width: 600px;
    color: white;
    position: relative;
}

.close {
    color: #ff6b6b;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover {
        transform: rotate(90deg);
        color: #ff4f4f;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    color: #009688;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 8px;
    border: 1px solid #009688;
    border-radius: 5px;
    background-color: rgba(0, 0, 0, 0.5);
    color: white;
}

.form-group textarea {
    height: 60px;
    resize: vertical;
    min-height: 60px;
    max-height: 120px;
}

.submit-btn,
.delete-btn,
.cancel-btn {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.3s ease;
}

.submit-btn {
    background-color: #009688;
    color: white;
}

.submit-btn:hover {
    background-color: #00796b;
}

.delete-btn {
    background-color: #f44336;
    color: white;
}

.delete-btn:hover {
    background-color: #d32f2f;
}

.cancel-btn {
    background-color: #757575;
    color: white;
}

.cancel-btn:hover {
    background-color: #616161;
}

.button-group {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

small {
    color: #757575;
    font-size: 12px;
}
</style>

<script>
document.getElementById('updateProductCategory').addEventListener('change', function() {
    const updateDiscountedPriceGroup = document.getElementById('updateDiscountedPriceGroup');
    updateDiscountedPriceGroup.style.display = this.value === 'offer' ? 'block' : 'none';
    if (this.value === 'regular') {
        document.getElementById('updateDiscountedPrice').value = '';
    }
});

document.querySelectorAll('.close').forEach(function(closeBtn) {
    closeBtn.onclick = function() {
        this.closest('.modal').style.display = 'none';
    }
});

window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function openAddModal() {
    const urlParams = new URLSearchParams(window.location.search);
    const type = urlParams.get('type');
    const categoryInput = document.getElementById('productCategory');
    const discountedPriceGroup = document.getElementById('discountedPriceGroup');
    
    if (type === 'offers') {
        categoryInput.value = 'offer';
        discountedPriceGroup.style.display = 'block';
    } else {
        categoryInput.value = 'regular';
        discountedPriceGroup.style.display = 'none';
    }
    
    document.getElementById('addProductModal').style.display = 'block';
}

function openUpdateModal(productId) {
    fetch(`get_product.php?id=${productId}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('updateProductId').value = data.id;
            document.getElementById('updateProductName').value = data.name;
            document.getElementById('updateProductDescription').value = data.description;
            document.getElementById('updateOriginalPrice').value = data.original_price;
            document.getElementById('updateProductCategory').value = data.category;
            document.getElementById('updateDiscountedPrice').value = data.discounted_price || '';
            document.getElementById('updateSupplier').value = data.supplier_id;
            
            const updateDiscountedPriceGroup = document.getElementById('updateDiscountedPriceGroup');
            updateDiscountedPriceGroup.style.display = data.category === 'offer' ? 'block' : 'none';
            
            document.getElementById('updateProductModal').style.display = 'block';
        });
}

function openDeleteModal(productId) {
    document.getElementById('deleteProductId').value = productId;
    document.getElementById('deleteProductModal').style.display = 'block';
}
</script>