<?php
require_once 'access_control.php';
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$inactive = 300; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $inactive)) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}
$_SESSION['last_activity'] = time(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jabbar Admin Dashboard</title>
    <link rel="stylesheet" href="ccc.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>
<body>
    <div id="page1">
        <div class="container">
            <div class="sidebar">
                <div class="logo">
                    <span class="logo-letter">J</span>
                    <span class="logo-text">ABBAR</span>
                </div>
                
                <div class="menu">
                    <div class="menu-item" onclick="window.location.href='aaa.php'">
                        <i class="fas fa-home"></i>
                        <span>Home</span>
                    </div>
                    
                    <div class="menu-item has-submenu">
                        <i class="fas fa-box"></i>
                        <span>Products</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='products.php?type=offers'" style="display: none;">
                        <i class="fas fa-tag"></i>
                        <span>Offers</span>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='products.php?type=regular'" style="display: none;">
                        <i class="fas fa-box-archive"></i>
                        <span>Regular</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='supplier.php'">
                        <i class="fas fa-truck"></i>
                        <span>Suppliers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='customer.php'">
                        <i class="fas fa-users"></i>
                        <span>View Customers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='inventory.php'">
                        <i class="fas fa-boxes"></i>
                        <span>Inventory Management</span>
                    </div>

                    <div class="menu-item has-submenu">
                        <i class="fas fa-plus-circle"></i>
                        <span>New Stocks</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='new_stocks.php?action=new'" style="display: none;">
                        <i class="fas fa-dolly"></i>
                        <span>New Product</span>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='new_stocks.php?action=restock'" style="display: none;">
                        <i class="fas fa-truck-ramp-box"></i>
                        <span>Restock</span>
                    </div>
                    
                    <div class="menu-item active">
                        <i class="fas fa-comment"></i>
                        <span>Feedback Management</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='AandR.php'">
                        <i class="fas fa-chart-bar"></i>
                        <span>Analytics & Reports</span>
                    </div>
                </div>

                <div class="sidebar-bottom">
                    <div class="menu-item hold-button" onclick="toggleHold()">
                        <i class="fas fa-pause-circle"></i>
                        <span id="holdText">Hold</span>
                    </div>
                    
                    <div class="logout" onclick="logout()">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </div>
                </div>
            </div>
            
            <div class="main-content">
                <div class="header">
                    <div class="user-profile">
                        <div class="user-info">
                            <span class="user-name"><?php echo $_SESSION['admin_username']; ?></span>
                        </div>
                        <div class="avatar">
                            <?php if (!empty($_SESSION['admin_profile_image'])): ?>
                                <img src="./AdminPix/<?php echo $_SESSION['admin_profile_image']; ?>" alt="Admin Avatar">
                            <?php else: ?>
                                <img src="./AdminPix/image.webp" alt="Admin Avatar">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="inventory-dashboard">
                    <div class="dashboard-grid">
                        <div class="dashboard-box low-stock-alerts">
                            <h2>Customer Feedback</h2>
                            <div class="alerts-container">
                                <?php
                                $query = "SELECT * FROM feedback WHERE status = 'pending' OR status = 'read' ORDER BY created_at DESC LIMIT 10";
                                $result = $conn->query($query);
                                
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $statusClass = $row['status'] === 'pending' ? 'warning' : ($row['status'] === 'replied' ? 'success' : 'info');
                                        echo "<div class='alert-item {$statusClass}' data-subject=\"{$row['subject']}\" data-name=\"{$row['name']}\" data-email=\"{$row['email']}\" data-message=\"" . htmlspecialchars($row['message'], ENT_QUOTES) . "\" data-received=\"" . date('M d, Y H:i', strtotime($row['created_at'])) . "\" data-id=\"{$row['id']}\">";
                                        echo "<div class='alert-header'>";
                                        echo "<h3>{$row['subject']}</h3>";
                                        echo "<span class='status-badge'>{$row['status']}</span>";
                                        echo "</div>";
                                        echo "</div>";
                                    }
                                } else {
                                    echo "<p class='no-alerts'>No feedback received yet.</p>";
                                }
                                ?>
                            </div>
                        </div>

                        <div class="dashboard-box stock-history">
                            <h2>Replied Feedback</h2>
                            <div class="history-container">
                                <?php
                                $queryReplied = "SELECT * FROM feedback WHERE status = 'replied' ORDER BY created_at DESC LIMIT 10";
                                $resultReplied = $conn->query($queryReplied);

                                if ($resultReplied->num_rows > 0) {
                                    while ($rowReplied = $resultReplied->fetch_assoc()) {
                                        $statusClassReplied = 'success';
                                        echo "<div class='alert-item {$statusClassReplied}' data-subject=\"{$rowReplied['subject']}\" data-name=\"{$rowReplied['name']}\" data-email=\"{$rowReplied['email']}\" data-message=\"" . htmlspecialchars($rowReplied['message'], ENT_QUOTES) . "\" data-received=\"" . date('M d, Y H:i', strtotime($rowReplied['created_at'])) . "\" data-id=\"{$rowReplied['id']}\">";
                                        echo "<div class='alert-header'>";
                                        echo "<h3>{$rowReplied['subject']}</h3>";
                                        echo "<span class='status-badge'>{$rowReplied['status']}</span>";
                                        echo "</div>";
                                        echo "</div>";
                                    }
                                } else {
                                    echo "<p class='no-alerts'>No replied feedback yet.</p>";
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="right-sidebar">
                <div class="feedback-section">
                    <h2>AI Inventory Suggestions</h2>
                    <div class="feedback-items">
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer feedback will appear here...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Another feedback sample text...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Yet another feedback example...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer comments and suggestions...</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="analytics-section">
                    <h2>Analytics & Reports Overview</h2>
                    <div class="stats-overview">
                        <div class="stat-item">
                            <span class="stat-label">Monthly Sales:</span>
                            <span class="stat-value" id="overviewMonthlySales">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Total Customers:</span>
                            <span class="stat-value" id="overviewTotalCustomers">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Underperforming Products:</span>
                            <span class="stat-value" id="overviewUnderperformingProducts">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Low Stock Alerts:</span>
                            <span class="stat-value" id="overviewLowStockAlerts">Loading...</span>
                        </div>
                         <div class="stat-item">
                            <span class="stat-label">High Stock Items:</span>
                            <span class="stat-value" id="overviewHighStockItems">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById("feedbackModal");

            const feedbackItems = document.querySelectorAll(".alert-item");
            feedbackItems.forEach(item => {
                item.addEventListener("click", function() {
                    const modalSubject = document.getElementById("modalSubject");
                    const modalName = document.getElementById("modalName");
                    const modalEmail = document.getElementById("modalEmail");
                    const modalMessage = document.getElementById("modalMessage");
                    const modalReceived = document.getElementById("modalReceived");
                    modalSubject.textContent = this.getAttribute("data-subject");
                    modalName.textContent = this.getAttribute("data-name");
                    modalEmail.textContent = this.getAttribute("data-email");
                    modalMessage.textContent = this.getAttribute("data-message");
                    modalReceived.textContent = "Received: " + this.getAttribute("data-received");

                    const feedbackId = this.getAttribute("data-id");
                    modal.setAttribute('data-id', feedbackId);
                    modal.style.display = "block";

                    const statusBadge = this.querySelector('.status-badge');
                    const currentStatus = statusBadge.textContent.trim();

                    if (currentStatus === 'pending') {
                        fetch('update_feedback_status.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                feedback_id: feedbackId,
                                status: 'read'
                            }),
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                statusBadge.textContent = 'read';
                                statusBadge.classList.remove('warning');
                                statusBadge.classList.add('read-status');

                                const parentAlertItem = statusBadge.closest('.alert-item');
                                if (parentAlertItem) {
                                    parentAlertItem.classList.remove('warning');
                                    parentAlertItem.classList.add('info');
                                }
                            } else {
                                console.error('Failed to update feedback status:', data.message);
                            }
                        })
                        .catch((error) => {
                            console.error('Error:', error);
                        });
                    }
                });
            });

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }

            const markAsRepliedBtn = document.getElementById('markAsRepliedBtn');
            markAsRepliedBtn.addEventListener('click', function() {
                const feedbackId = modal.getAttribute('data-id');

                fetch('update_feedback_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        feedback_id: feedbackId,
                        status: 'replied'
                    }),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const originalItem = document.querySelector(`.alert-item[data-id="${feedbackId}"]`);
                        if (originalItem) {
                            originalItem.remove();
                        }

                        console.log('Feedback status updated to replied');
                        modal.style.display = "none";
                        window.location.reload();

                    } else {
                        console.error('Failed to update feedback status:', data.message);
                    }
                })
                .catch((error) => {
                    console.error('Error:', error);
                });
            });
        });

        let inactivityTime = function() {
            let time;
            let isHeld = false;
            
            window.onload = resetTimer;
            document.onmousemove = resetTimer;
            document.onkeydown = resetTimer;
            document.onclick = resetTimer;
            document.onscroll = resetTimer;
            
            function resetTimer() {
                if (!isHeld) {
                    clearTimeout(time);
                    time = setTimeout(logout, 300000);
                }
            }
            
            window.toggleHold = function() {
                const holdButton = document.querySelector('.hold-button');
                const holdText = document.getElementById('holdText');
                isHeld = !isHeld;
                
                sessionStorage.setItem('isHeld', isHeld);

                if (isHeld) {
                    holdButton.classList.add('active');
                    holdText.textContent = 'Cancel';
                    clearTimeout(time); 
                } else {
                    holdButton.classList.remove('active');
                    holdText.textContent = 'Hold';
                    resetTimer(); 
                }
            };
        };
        
        let isHeld = sessionStorage.getItem('isHeld') === 'true'; 
        const holdButton = document.querySelector('.hold-button');
        const holdText = document.getElementById('holdText');

        if (isHeld) {
            holdButton.classList.add('active');
            holdText.textContent = 'Cancel';
        } else {
            holdButton.classList.remove('active');
            holdText.textContent = 'Hold';
        }

        inactivityTime(); 
        
        function logout() {
            window.location.href = "logout.php";
        }
        
        window.addEventListener('beforeunload', function(e) {
            if (!window.location.href.includes('/admin/')) {
                e.preventDefault();
                e.returnValue = '';
                fetch('logout.php');
            }
        });
        
        setInterval(function() {
            fetch('check_session.php')
                .then(response => response.json())
                .then(data => {
                    if (!data.valid) {
                        window.location.href = "login.php?timeout=1";
                    }
                });
        }, 60000);

        document.addEventListener('DOMContentLoaded', function() {
            const productsMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-box)');
            const productsSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-tag), .submenu-item:has(i.fa-box-archive)');
            
            productsMenuItem.addEventListener('click', function() {
                this.classList.toggle('active');
                
                productsSubmenuItems.forEach(item => {
                    if (this.classList.contains('active')) {
                        item.style.display = 'flex';
                        setTimeout(() => {
                            item.classList.add('show');
                        }, 10);
                    } else {
                        item.classList.remove('show');
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 300);
                    }
                });
            });

            if (productsMenuItem.classList.contains('active')) {
                productsSubmenuItems.forEach(item => {
                    item.style.display = 'flex'; 
                    setTimeout(() => {
                        item.classList.add('show');
                    }, 10);
                });
            }

            const newStocksMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-plus-circle)');
            const newStocksSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-dolly), .submenu-item:has(i.fa-truck-ramp-box)');

            if (newStocksMenuItem) {
                newStocksMenuItem.addEventListener('click', function() {
                    this.classList.toggle('active');

                    newStocksSubmenuItems.forEach(item => {
                        if (this.classList.contains('active')) {
                            item.style.display = 'flex';
                            setTimeout(() => {
                                item.classList.add('show');
                            }, 10);
                        } else {
                            item.classList.remove('show');
                            setTimeout(() => {
                                item.style.display = 'none';
                            }, 300);
                        }
                    });
                });
            }
        });

        // Function to fetch and display overview stats in right sidebar
        function fetchOverviewStats() {
            // Fetch Monthly Sales
            fetch('get_monthly_sales.php')
                .then(response => response.json())
                .then(data => {
                    const totalMonthlySales = data.values.reduce((sum, value) => sum + parseFloat(value), 0);
                    document.getElementById('overviewMonthlySales').textContent = `Rs. ${totalMonthlySales.toFixed(2)}`;
                }).catch(error => console.error('Error fetching monthly sales overview:', error));

            // Fetch Total Customers
            fetch('get_customer_stats.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewTotalCustomers').textContent = data.totalCustomers;
                }).catch(error => console.error('Error fetching customer stats overview:', error));

            // Fetch Product Performance (Underperforming)
            fetch('get_product_performance.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewUnderperformingProducts').textContent = data.underperforming.length;
                }).catch(error => console.error('Error fetching product performance overview:', error));

            // Fetch Inventory Health (Low Stock Alerts)
            fetch('get_inventory_health.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewLowStockAlerts').textContent = data.restockAlerts.length;
                     document.getElementById('overviewHighStockItems').textContent = data.stockLevels.length;
                }).catch(error => console.error('Error fetching inventory health overview:', error));
        }

        // Call the function to fetch and display overview stats on page load
        fetchOverviewStats();
    </script>

    <div id="feedbackModal" class="modal">
        <div class="modal-content">
            
            <h2 id="modalSubject"></h2>
            <p><strong style="color: #009688;">From:</strong> <span id="modalName"></span> (<span id="modalEmail"></span>)</p>
            <p><strong style="color: #009688;">Message:</strong> <span id="modalMessage"></span></p>
            <p><small id="modalReceived"></small></p>
            <div class="button-group">
                 <button id="markAsRepliedBtn" class="action-btn success">Mark as Replied</button>
            </div>
        </div>
    </div>

    <style>
    .table-container {
        position: relative;
        height: calc(100vh - 150px); 
        overflow: hidden;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-radius: 25px;
        display: flex;
        flex-direction: column;
    }

    .table-header {
        flex-shrink: 0;
        background-color: rgba(0, 150, 136, 0.1);
        border-top-left-radius: 25px;
        border-top-right-radius: 25px;
    }

    .table-header table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .table-header th {
        padding: 12px 15px;
        text-align: center;
        color: white;
        width: auto;
    }

    .table-header th:nth-child(1), .table-body td:nth-child(1) {
        width: 8%;
    }

    .table-header th:nth-child(2), .table-body td:nth-child(2) {
        width: 20%;
    }

    .table-header th:nth-child(3), .table-body td:nth-child(3) {
        width: 25%;
    }

    .table-header th:nth-child(4), .table-body td:nth-child(4) {
        width: 25%;
    }

    .table-header th:nth-child(5), .table-body td:nth-child(5) {
        width: 12%;
    }

    .table-header th:nth-child(6), .table-body td:nth-child(6) {
        width: 10%;
    }

    .table-body {
        flex-grow: 1;
        overflow-y: auto;
    }

    .table-body::-webkit-scrollbar {
        width: 8px;
    }

    .table-body::-webkit-scrollbar-track {
        background: rgba(0, 150, 136, 0.1);
        border-radius: 4px;
    }

    .table-body::-webkit-scrollbar-thumb {
        background: rgba(0, 150, 136, 0.3);
        border-radius: 4px;
        transition: background 0.3s ease;
    }

    .table-body::-webkit-scrollbar-thumb:hover {
        background: rgba(0, 150, 136, 0.5);
    }

    .table-body {
        scrollbar-width: thin;
        scrollbar-color: rgba(0, 150, 136, 0.3) rgba(0, 150, 136, 0.1);
    }

    .table-body table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .table-body td {
         padding: 12px 15px;
         text-align: left;
         white-space: normal;
    }

    .table-body td:nth-child(2),
    .table-body td:nth-child(3),
    .table-body td:nth-child(4),
    .table-body td:nth-child(5),
    .table-body td:nth-child(6) {
        text-align: center;
    }

    .supplier-actions {
        position: relative;
        flex-shrink: 0;
        background: rgba(0, 150, 136, 0.1);
        padding: 15px;
        display: flex;
        justify-content: center;
        gap: 15px;
        border-top: 1px solid #e0e0e0;
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        border-bottom-left-radius: 25px;
        border-bottom-right-radius: 25px;
    }

    .action-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background: #4CAF50;
        color: white;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .action-btn:hover {
        background: #45a049;
    }

    .action-btn:disabled {
        background: #cccccc;
        cursor: not-allowed;
        opacity: 0.7;
    }

    .action-btn:disabled:hover {
        background: #cccccc;
    }

    .action-btn i {
        font-size: 14px;
    }
    
    .action-btn.add-btn {
        background: #4CAF50;
    }

    .action-btn.add-btn:hover {
        background: #45a049;
    }

    .action-btn.edit-btn {
        background: #2196F3;
    }

    .action-btn.edit-btn:hover {
        background: #1976D2;
    }

    .action-btn.delete-btn {
        background: #f44336;
    }

    .action-btn.delete-btn:hover {
        background: #d32f2f;
    }

    .action-btn.assign-btn {
        background: #9C27B0;
    }

    .action-btn.assign-btn:hover {
        background: #7B1FA2;
    }

    .table-body tr {
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .table-body tr:hover {
        background-color: rgba(0, 150, 136, 0.1);
    }

    .table-body tr.selected {
        background-color: rgba(0, 150, 136, 0.2);
        border-left: 4px solid #009688;
    }

    .table-body tr.selected td {
        color: #009688;
    }

    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
    }

    .modal-content {
        background-color: rgba(0, 0, 0, 0.9);
        margin: 5% auto;
        padding: 20px;
        border: 2px solid #009688;
        border-radius: 25px;
        width: 80%;
        max-width: 600px;
        color: white;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        padding-bottom: 40px;
    }

    .modal-content h2 {
        color: #009688;
        padding: 0 0 15px 0;
    }

    .modal-content p {
        margin-bottom: 10px;
        line-height: 1.5;
        display: flex;
        align-items: baseline;
    }

    .modal-content p strong {
        margin-right: 5px;
        flex-shrink: 0;
    }

    .modal-content small {
        color: #757575;
        font-size: 12px;
        position: absolute;
        bottom: 15px;
        right: 20px;
    }

    .close:hover {
        transform: rotate(90deg);
        color: #ff4f4f;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        color: #009688;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #009688;
        border-radius: 5px;
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
    }

    .form-group textarea {
        height: 60px;
        resize: vertical;
        min-height: 60px;
        max-height: 120px;
    }

    .submit-btn,
    .delete-btn,
    .cancel-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    .submit-btn {
        background-color: #009688;
        color: white;
    }

    .submit-btn:hover {
        background-color: #00796b;
    }

    .delete-btn {
        background-color: #f44336;
        color: white;
    }

    .delete-btn:hover {
        background-color: #d32f2f;
    }

    .cancel-btn {
        background-color: #757575;
        color: white;
    }

    .cancel-btn:hover {
        background-color: #616161;
    }

    .button-group {
        display: flex;
        gap: 10px;
        justify-content: center;
    }

    .product-list {
        max-height: 300px;
        overflow-y: auto;
        border: 1px solid #ddd;
        padding: 10px;
        border-radius: 4px;
    }

    .product-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 5px 0;
        cursor: pointer;
        transition: background-color 0.2s ease;
    }

    .product-item:hover {
        background-color: rgba(0, 150, 136, 0.1);
    }

    .product-item.selected-product {
        background-color: rgba(0, 150, 136, 0.3);
        border-left: 3px solid #009688;
        padding-left: 7px;
    }

    .inventory-dashboard {
        padding: 20px;
    }

    .dashboard-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        height: calc(100vh - 150px);
    }

    .dashboard-box {
        background: rgba(0, 0, 0, 0.9);
        border: 2px solid #009688;
        border-radius: 25px;
        padding: 20px;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        height: calc(100vh - 200px);
    }

    .dashboard-box h2 {
        color: #009688;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid #009688;
    }

    .alerts-container {
        overflow-y: auto;
        flex-grow: 1;
        scrollbar-width: thin;
        scrollbar-color: rgba(0, 150, 136, 0.3) rgba(0, 150, 136, 0.1);
    }

    .alerts-container::-webkit-scrollbar {
        width: 8px;
    }

    .alerts-container::-webkit-scrollbar-track {
        background: rgba(0, 150, 136, 0.1);
        border-radius: 4px;
    }

    .alerts-container::-webkit-scrollbar-thumb {
        background: rgba(0, 150, 136, 0.3);
        border-radius: 4px;
        transition: background 0.3s ease;
    }

    .alerts-container::-webkit-scrollbar-thumb:hover {
        background: rgba(0, 150, 136, 0.5);
    }

    .history-container {
        flex-grow: 1;
        position: relative;
        background: rgba(0, 0, 0, 0.5);
        border-radius: 15px;
        overflow-y: auto;
    }

    .history-container::-webkit-scrollbar {
        width: 8px;
    }

    .history-container::-webkit-scrollbar-track {
        background: rgba(0, 150, 136, 0.1);
        border-radius: 4px;
    }

    .history-container::-webkit-scrollbar-thumb {
        background: rgba(0, 150, 136, 0.3);
        border-radius: 4px;
    }

    .history-container::-webkit-scrollbar-thumb:hover {
        background: rgba(0, 150, 136, 0.5);
    }

    .history-container {
        scrollbar-width: thin;
        scrollbar-color: rgba(0, 150, 136, 0.3) rgba(0, 150, 136, 0.1);
    }

    .status-badge {
        font-size: 12px;
        padding: 4px 8px;
        border-radius: 12px;
        font-weight: 500;
        text-transform: capitalize;
    }

    .alert-item.warning .status-badge {
        background: rgba(255, 152, 0, 0.2);
        color: #ff9800;
    }

    .alert-item.success .status-badge {
        background: rgba(76, 175, 80, 0.2);
        color: #4CAF50;
    }

    .alert-item.info .status-badge {
        background: rgba(33, 150, 243, 0.2);
        color: #2196F3;
    }

    .alert-item.read-status .status-badge {
        background: rgba(33, 150, 243, 0.2);
        color: #2196F3;
    }

    .alert-item {
        background: rgba(0, 150, 136, 0.1);
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 15px;
        border-left: 4px solid;
    }

    .alert-item.warning {
        border-left-color: #ff9800;
    }

    .alert-item.success {
        border-left-color: #4CAF50;
    }

    .alert-item.info {
        border-left-color: #2196F3;
    }

    .alert-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }

    .alert-header h3 {
        color: #fff;
        margin: 0;
        font-size: 16px;
    }

    .alert-details {
        color: #ccc;
        margin: 0;
        font-size: 0.9em;
        line-height: 1.5;
    }

    .alert-details strong {
        color: #009688;
    }

    .alert-details small {
        display: block;
        margin-top: 8px;
        color: #888;
    }

    .no-alerts {
        color: #4CAF50;
        text-align: center;
        padding: 20px;
    }

    .alerts-container .alert-item,
    .history-container .alert-item {
        padding: 15px;
        margin-bottom: 15px;
    }

    .analytics-section h2 {
        color: #009688;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(0, 150, 136, 0.3);
    }

    .stats-overview {
        margin-top: 15px;
    }

    .stats-item {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-size: 0.95em;
    }

    .stats-item:last-child {
        border-bottom: none;
    }

    .stat-label {
        color: #ccc;
        font-weight: 500;
    }

    .stat-value {
        color: #009688;
        font-weight: bold;
    }
    </style>
</body>
</html>