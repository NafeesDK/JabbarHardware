<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$query = "SELECT 
            SUM(CASE WHEN payment_method = 'card' THEN 1 ELSE 0 END) as card,
            SUM(CASE WHEN payment_method = 'cash' THEN 1 ELSE 0 END) as cash
          FROM orders 
          WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";

$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

header('Content-Type: application/json');
echo json_encode($data);
?> 