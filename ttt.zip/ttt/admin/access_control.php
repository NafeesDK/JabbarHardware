<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

function isSuperAdmin() {
    return isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'super_admin';
}

function isGodownAdmin() {
    return isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'godown_admin';
}

function hasAccess($page) {
    if (isGodownAdmin()) {
        return $page === 'godown.php';
    }
    
    if (isSuperAdmin()) {
        return $page !== 'godown.php';
    }

    $allowedPages = [
        'aaa.php',           // Dashboard
        'products.php',      // Products
        'inventory.php',     // Inventory
        'customer.php',      // Customer
        'supplier.php',      // Supplier
        'new_stocks.php',    // New Stocks
        'feedback.php',      // Feedback
        'AandR.php'          // Add and Remove
    ];
    
    return in_array($page, $allowedPages);
}

$currentPage = basename($_SERVER['PHP_SELF']);

if (!hasAccess($currentPage)) {
    if (isGodownAdmin()) {
        header("Location: godown.php");
    } else {
        header("Location: aaa.php");
    }
    exit();
}
?> 