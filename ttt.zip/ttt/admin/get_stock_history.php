<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// Function to sync stock quantities
function syncStockQuantity($conn, $product_id, $new_quantity) {
    try {
        $conn->begin_transaction();

        // Get current stock quantity
        $get_current = $conn->prepare("SELECT stock_quantity FROM products WHERE id = ?");
        $get_current->bind_param("i", $product_id);
        $get_current->execute();
        $result = $get_current->get_result();
        $current = $result->fetch_assoc();

        // Update products table
        $update_product = $conn->prepare("UPDATE products SET stock_quantity = ? WHERE id = ?");
        $update_product->bind_param("ii", $new_quantity, $product_id);
        $update_product->execute();

        // Add new stock history entry
        $insert_history = $conn->prepare("INSERT INTO stock_history (product_id, previous_quantity, new_quantity, change_type) VALUES (?, ?, ?, 'adjustment')");
        $insert_history->bind_param("iii", $product_id, $current['stock_quantity'], $new_quantity);
        $insert_history->execute();

        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        return false;
    }
}

$query = "SELECT 
            p.name,
            DATE(sh.changed_at) as date,
            sh.new_quantity,
            sh.change_type,
            p.stock_quantity as current_stock,
            p.id as product_id
          FROM stock_history sh
          JOIN products p ON sh.product_id = p.id
          WHERE sh.changed_at >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
          AND sh.change_type IN ('sale', 'restock', 'adjustment')
          ORDER BY sh.changed_at ASC";

$result = $conn->query($query);

$data = [];
$dates = [];
$products = [];
$lastQuantities = [];

// First pass: collect all dates and get the last quantity for each product
while ($row = $result->fetch_assoc()) {
    if (!in_array($row['date'], $dates)) {
        $dates[] = $row['date'];
    }
    
    $product_id = $row['product_id'];
    if (!isset($lastQuantities[$product_id])) {
        $lastQuantities[$product_id] = [
            'quantity' => $row['new_quantity'],
            'current_stock' => $row['current_stock']
        ];
    } else {
        $lastQuantities[$product_id]['quantity'] = $row['new_quantity'];
    }
}

// Auto-sync stock quantities
foreach ($lastQuantities as $product_id => $quantities) {
    if ($quantities['quantity'] !== $quantities['current_stock']) {
        syncStockQuantity($conn, $product_id, $quantities['quantity']);
    }
}

// Reset result pointer
$result->data_seek(0);

// Second pass: collect product data
while ($row = $result->fetch_assoc()) {
    if (!isset($products[$row['name']])) {
        $products[$row['name']] = [
            'current_stock' => $row['current_stock'],
            'product_id' => $row['product_id']
        ];
    }
}

sort($dates);

$colors = [
    '#4CAF50', '#2196F3', '#9C27B0', '#FF9800', '#F44336',
    '#00BCD4', '#E91E63', '#3F51B5', '#FFC107', '#795548'
];
$colorIndex = 0;

$datasets = [];
foreach ($products as $productName => $productData) {
    $color = $colors[$colorIndex % count($colors)];
    $colorIndex++;
    
    $data = array_fill(0, count($dates), null);
    
    $result->data_seek(0);
    
    while ($row = $result->fetch_assoc()) {
        if ($row['name'] === $productName) {
            $dateIndex = array_search($row['date'], $dates);
            $data[$dateIndex] = $row['new_quantity'];
        }
    }
    
    $datasets[] = [
        'label' => $productName,
        'data' => $data,
        'color' => $color,
        'current_stock' => $productData['current_stock'],
        'product_id' => $productData['product_id']
    ];
}

$formattedDates = array_map(function($date) {
    return date('M d', strtotime($date));
}, $dates);

header('Content-Type: application/json');
echo json_encode([
    'labels' => $formattedDates,
    'datasets' => $datasets
]); 