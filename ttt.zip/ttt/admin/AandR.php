<?php
require_once 'access_control.php';
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$inactive = 300; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $inactive)) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}
$_SESSION['last_activity'] = time(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jabbar Admin Dashboard</title>
    <link rel="stylesheet" href="ccc.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div id="page1">
        <div class="container">
            <div class="sidebar">
                <div class="logo">
                    <span class="logo-letter">J</span>
                    <span class="logo-text">ABBAR</span>
                </div>
                
                <div class="menu">
                    <div class="menu-item" onclick="window.location.href='aaa.php'">
                        <i class="fas fa-home"></i>
                        <span>Home</span>
                    </div>
                    
                    <div class="menu-item has-submenu">
                        <i class="fas fa-box"></i>
                        <span>Products</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='products.php?type=offers'" style="display: none;">
                        <i class="fas fa-tag"></i>
                        <span>Offers</span>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='products.php?type=regular'" style="display: none;">
                        <i class="fas fa-box-archive"></i>
                        <span>Regular</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='supplier.php'">
                        <i class="fas fa-truck"></i>
                        <span>Suppliers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='customer.php'">
                        <i class="fas fa-users"></i>
                        <span>View Customers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='inventory.php'">
                        <i class="fas fa-boxes"></i>
                        <span>Inventory Management</span>
                    </div>

                    <div class="menu-item has-submenu">
                        <i class="fas fa-plus-circle"></i>
                        <span>New Stocks</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='new_stocks.php?action=new'" style="display: none;">
                        <i class="fas fa-dolly"></i>
                        <span>New Product</span>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='new_stocks.php?action=restock'" style="display: none;">
                        <i class="fas fa-truck-ramp-box"></i>
                        <span>Restock</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='feedback.php'">
                        <i class="fas fa-comment"></i>
                        <span>Feedback Management</span>
                    </div>
                    
                    <div class="menu-item active">
                        <i class="fas fa-chart-bar"></i>
                        <span>Analytics & Reports</span>
                    </div>
                </div>

                <div class="sidebar-bottom">
                    <div class="menu-item hold-button" onclick="toggleHold()">
                        <i class="fas fa-pause-circle"></i>
                        <span id="holdText">Hold</span>
                    </div>
                    
                    <div class="logout" onclick="logout()">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </div>
                </div>
            </div>
            
            <div class="main-content">
                <div class="header">
                    <div class="user-profile">
                        <div class="user-info">
                            <span class="user-name"><?php echo $_SESSION['admin_username']; ?></span>
                        </div>
                        <div class="avatar">
                            <?php if (!empty($_SESSION['admin_profile_image'])): ?>
                                <img src="./AdminPix/<?php echo $_SESSION['admin_profile_image']; ?>" alt="Admin Avatar">
                            <?php else: ?>
                                <img src="./AdminPix/image.webp" alt="Admin Avatar">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="analytics-dashboard">
                    <div class="dashboard-section sales-analytics">
                        <h2>Sales Analytics</h2>
                        <div class="analytics-grid">
                            <div class="analytics-card">
                                <h3>Monthly Sales</h3>
                                <canvas id="monthlySalesChart"></canvas>
                            </div>
                            <div class="analytics-card">
                                <h3>Top Selling Products</h3>
                                <div id="topProductsList"></div>
                            </div>
                            <div class="analytics-card">
                                <h3>Order Locations</h3>
                                <div id="orderLocationsList"></div>
                            </div>
                            <div class="analytics-card">
                                <h3>Payment Methods</h3>
                                <canvas id="paymentMethodsChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <div class="dashboard-section customer-insights">
                        <h2>Customer Insights</h2>
                        <div class="analytics-grid">
                            <div class="analytics-card">
                                <h3>Customer Overview</h3>
                                <div id="customerStats"></div>
                            </div>
                            <div class="analytics-card">
                                <h3>Top Customers</h3>
                                <div id="topCustomersList"></div>
                            </div>
                            </div>
                        </div>

                    <div class="dashboard-section product-performance">
                        <h2>Product Performance</h2>
                        <div class="analytics-grid">
                            <div class="analytics-card">
                                <h3>Best Performing Products</h3>
                                <div id="bestProductsList"></div>
                            </div>
                            <div class="analytics-card">
                                <h3>Underperforming Products</h3>
                                <div id="underperformingProductsList"></div>
                            </div>
                        </div>
                    </div>

                    <div class="dashboard-section inventory-health">
                        <h2>Inventory Health</h2>
                        <div class="analytics-grid">
                            <div class="analytics-card">
                                <h3>High Stock Levels</h3>
                                <div id="stockLevelsList"></div>
                            </div>
                            <div class="analytics-card">
                                <h3>Restock Alerts</h3>
                                <div id="restockAlertsList"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="right-sidebar">
                <div class="feedback-section">
                    <h2>AI Inventory Suggestions</h2>
                    <div class="feedback-items">
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer feedback will appear here...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Another feedback sample text...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Yet another feedback example...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer comments and suggestions...</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="analytics-section">
                    <h2>Analytics & Reports Overview</h2>
                    <div class="stats-overview">
                        <div class="stat-item">
                            <span class="stat-label">Monthly Sales:</span>
                            <span class="stat-value" id="overviewMonthlySales">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Total Customers:</span>
                            <span class="stat-value" id="overviewTotalCustomers">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Underperforming Products:</span>
                            <span class="stat-value" id="overviewUnderperformingProducts">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Low Stock Alerts:</span>
                            <span class="stat-value" id="overviewLowStockAlerts">Loading...</span>
                        </div>
                         <div class="stat-item">
                            <span class="stat-label">High Stock Items:</span>
                            <span class="stat-value" id="overviewHighStockItems">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let inactivityTime = function() {
            let time;
            let isHeld = false;
            
            window.onload = resetTimer;
            document.onmousemove = resetTimer;
            document.onkeydown = resetTimer;
            document.onclick = resetTimer;
            document.onscroll = resetTimer;
            
            function resetTimer() {
                if (!isHeld) {
                    clearTimeout(time);
                    time = setTimeout(logout, 300000);
                }
            }
            
            window.toggleHold = function() {
                const holdButton = document.querySelector('.hold-button');
                const holdText = document.getElementById('holdText');
                isHeld = !isHeld;
                
                sessionStorage.setItem('isHeld', isHeld);

                if (isHeld) {
                    holdButton.classList.add('active');
                    holdText.textContent = 'Cancel';
                    clearTimeout(time); 
                } else {
                    holdButton.classList.remove('active');
                    holdText.textContent = 'Hold';
                    resetTimer(); 
                }
            };
        };
        
        let isHeld = sessionStorage.getItem('isHeld') === 'true'; 
        const holdButton = document.querySelector('.hold-button');
        const holdText = document.getElementById('holdText');

        if (isHeld) {
            holdButton.classList.add('active');
            holdText.textContent = 'Cancel';
        } else {
            holdButton.classList.remove('active');
            holdText.textContent = 'Hold';
        }

        inactivityTime(); 
        
        function logout() {
            window.location.href = "logout.php";
        }
        
        window.addEventListener('beforeunload', function(e) {
            if (!window.location.href.includes('/admin/')) {
                e.preventDefault();
                e.returnValue = '';
                fetch('logout.php');
            }
        });
        
        setInterval(function() {
            fetch('check_session.php')
                .then(response => response.json())
                .then(data => {
                    if (!data.valid) {
                        window.location.href = "login.php?timeout=1";
                    }
                });
        }, 60000);

        document.addEventListener('DOMContentLoaded', function() {
            const productsMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-box)');
            const productsSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-tag), .submenu-item:has(i.fa-box-archive)');
            
            productsMenuItem.addEventListener('click', function() {
                this.classList.toggle('active');
                
                productsSubmenuItems.forEach(item => {
                    if (this.classList.contains('active')) {
                        item.style.display = 'flex';
                        setTimeout(() => {
                            item.classList.add('show');
                        }, 10);
                    } else {
                        item.classList.remove('show');
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 300);
                    }
                });
            });

            if (productsMenuItem.classList.contains('active')) {
                productsSubmenuItems.forEach(item => {
                    item.style.display = 'flex'; 
                    setTimeout(() => {
                        item.classList.add('show');
                    }, 10);
                });
            }

            const newStocksMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-plus-circle)');
            const newStocksSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-dolly), .submenu-item:has(i.fas.fa-truck-ramp-box)');

            if (newStocksMenuItem) {
                newStocksMenuItem.addEventListener('click', function() {
                    this.classList.toggle('active');

                    newStocksSubmenuItems.forEach(item => {
                        if (this.classList.contains('active')) {
                            item.style.display = 'flex';
                            setTimeout(() => {
                                item.classList.add('show');
                            }, 10);
                        } else {
                            item.classList.remove('show');
                            setTimeout(() => {
                                item.style.display = 'none';
                            }, 300);
                        }
                    });
                });
            }

            fetch('get_monthly_sales.php')
                .then(response => response.json())
                .then(data => {
                    new Chart(document.getElementById('monthlySalesChart'), {
                            type: 'line',
                            data: {
                            labels: data.labels,
                                datasets: [{
                                label: 'Monthly Sales',
                                data: data.values,
                                borderColor: '#009688',
                                backgroundColor: 'rgba(0, 150, 136, 0.1)',
                                    fill: true
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: {
                                        display: false
                                    }
                                },
                                scales: {
                                    y: {
                                    beginAtZero: true,
                                    grid: {
                                        color: 'rgba(255, 255, 255, 0.1)'
                                    },
                                    ticks: {
                                        color: '#fff'
                                    }
                                },
                                x: {
                                    grid: {
                                        color: 'rgba(255, 255, 255, 0.1)'
                                    },
                                    ticks: {
                                        color: '#fff'
                                    }
                                }
                            }
                        }
                    });
                });

            fetch('get_top_products.php')
                .then(response => response.json())
                .then(data => {
                    const topProductsList = document.getElementById('topProductsList');
                    data.forEach(product => {
                        const item = document.createElement('div');
                        item.className = 'list-item';
                        item.innerHTML = `
                            <span class="name">${product.name}</span>
                            <span class="value">${product.sales} units</span>
                        `;
                        topProductsList.appendChild(item);
                    });
                });

            fetch('get_order_locations.php')
                .then(response => response.json())
                .then(data => {
                    const orderLocationsList = document.getElementById('orderLocationsList');
                    data.forEach(location => {
                        const item = document.createElement('div');
                        item.className = 'list-item';
                        item.innerHTML = `
                            <span class="name">${location.city}</span>
                            <span class="value">${location.count} orders</span>
                        `;
                        orderLocationsList.appendChild(item);
                    });
                });

            fetch('get_payment_methods.php')
                .then(response => response.json())
                .then(data => {
                    new Chart(document.getElementById('paymentMethodsChart'), {
                        type: 'doughnut',
                                data: {
                            labels: ['Card', 'Cash'],
                                    datasets: [{
                                data: [data.card, data.cash],
                                backgroundColor: ['#009688', '#ff9800']
                                    }]
                                },
                                options: {
                                    responsive: true,
                                    maintainAspectRatio: false,
                                    plugins: {
                                        legend: {
                                    position: 'bottom',
                                    labels: {
                                        color: '#fff'
                                    }
                                        }
                                    }
                                }
                            });
                });

            fetch('get_customer_stats.php')
                .then(response => response.json())
                .then(data => {
                    const customerStats = document.getElementById('customerStats');
                    customerStats.innerHTML = `
                        <div class="stat-card">
                            <div class="label">Total Customers</div>
                            <div class="value">${data.totalCustomers}</div>
                        </div>
                        <div class="stat-card">
                            <div class="label">Repeat Customers</div>
                            <div class="value">${data.repeatCustomers}%</div>
                        </div>
                    `;
                });

            fetch('get_top_customers.php')
                .then(response => response.json())
                .then(data => {
                    const topCustomersList = document.getElementById('topCustomersList');
                    data.forEach(customer => {
                        const item = document.createElement('div');
                        item.className = 'list-item';
                        item.innerHTML = `
                            <span class="name">${customer.name}</span>
                            <span class="value">Rs. ${customer.total_spent}</span>
                        `;
                        topCustomersList.appendChild(item);
                });
        });

            fetch('get_product_performance.php')
            .then(response => response.json())
            .then(data => {
                    const bestProductsList = document.getElementById('bestProductsList');
                    data.best.forEach(product => {
                        const item = document.createElement('div');
                        item.className = 'list-item';
                        item.innerHTML = `
                            <span class="name">${product.name}</span>
                            <span class="value">${product.sales} units</span>
                        `;
                        bestProductsList.appendChild(item);
                    });

                    const underperformingProductsList = document.getElementById('underperformingProductsList');
                    data.underperforming.forEach(product => {
                        const item = document.createElement('div');
                        item.className = 'list-item';
                        item.innerHTML = `
                            <span class="name">${product.name}</span>
                            <span class="value">${product.sales} units</span>
                        `;
                        underperformingProductsList.appendChild(item);
                    });
                });

            fetch('get_inventory_health.php')
                .then(response => response.json())
                .then(data => {
                    const stockLevelsList = document.getElementById('stockLevelsList');
                    data.stockLevels.forEach(product => {
                        const item = document.createElement('div');
                        item.className = 'list-item';
                        item.innerHTML = `
                            <span class="name">${product.name}</span>
                            <span class="value">${product.quantity} units</span>
                        `;
                        stockLevelsList.appendChild(item);
                    });

                    const restockAlertsList = document.getElementById('restockAlertsList');
                    data.restockAlerts.forEach(product => {
                        const item = document.createElement('div');
                        item.className = `alert-item ${product.quantity === 0 ? 'critical' : 'warning'}`;
                        item.innerHTML = `
                            <div class="name">${product.name}</div>
                            <div class="value">${product.quantity} units remaining</div>
                        `;
                        restockAlertsList.appendChild(item);
                    });
                });

            function fetchOverviewStats() {
                fetch('get_monthly_sales.php')
                    .then(response => response.json())
                    .then(data => {
                        const totalMonthlySales = data.values.reduce((sum, value) => sum + parseFloat(value), 0);
                        document.getElementById('overviewMonthlySales').textContent = `Rs. ${totalMonthlySales.toFixed(2)}`;
                    }).catch(error => console.error('Error fetching monthly sales overview:', error));

                fetch('get_customer_stats.php')
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('overviewTotalCustomers').textContent = data.totalCustomers;
                    }).catch(error => console.error('Error fetching customer stats overview:', error));

                fetch('get_product_performance.php')
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('overviewUnderperformingProducts').textContent = data.underperforming.length;
                    }).catch(error => console.error('Error fetching product performance overview:', error));

                fetch('get_inventory_health.php')
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('overviewLowStockAlerts').textContent = data.restockAlerts.length;
                         document.getElementById('overviewHighStockItems').textContent = data.stockLevels.length;
                    }).catch(error => console.error('Error fetching inventory health overview:', error));
            }

            fetchOverviewStats();
        });
    </script>

    <style>
    .table-container {
        position: relative;
        height: calc(100vh - 150px); 
        overflow: hidden;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-radius: 25px;
        display: flex;
        flex-direction: column;
    }

    .table-header {
        flex-shrink: 0;
        background-color: rgba(0, 150, 136, 0.1);
        border-top-left-radius: 25px;
        border-top-right-radius: 25px;
    }

    .table-header table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .table-header th {
        padding: 12px 15px;
        text-align: center;
        color: white;
        width: auto;
    }

    .table-header th:nth-child(1), .table-body td:nth-child(1) {
        width: 8%;
    }

    .table-header th:nth-child(2), .table-body td:nth-child(2) {
        width: 20%;
    }

    .table-header th:nth-child(3), .table-body td:nth-child(3) {
        width: 25%;
    }

    .table-header th:nth-child(4), .table-body td:nth-child(4) {
        width: 25%;
    }

    .table-header th:nth-child(5), .table-body td:nth-child(5) {
        width: 12%;
    }

    .table-header th:nth-child(6), .table-body td:nth-child(6) {
        width: 10%;
    }

    .table-body {
        flex-grow: 1;
        overflow-y: auto;
    }

    .table-body::-webkit-scrollbar {
        width: 8px;
    }

    .table-body::-webkit-scrollbar-track {
        background: rgba(0, 150, 136, 0.1);
        border-radius: 4px;
    }

    .table-body::-webkit-scrollbar-thumb {
        background: rgba(0, 150, 136, 0.4); 
        border-radius: 4px;
        transition: background 0.3s ease;
    }

    .table-body::-webkit-scrollbar-thumb:hover {
        background: rgba(0, 150, 136, 0.6); 
    }

    .table-body {
        scrollbar-width: thin;
        scrollbar-color: rgba(0, 150, 136, 0.4) rgba(0, 150, 136, 0.1); 
    }

    .table-body table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .table-body td {
         padding: 12px 15px;
         text-align: left;
         white-space: normal;
    }

    .table-body td:nth-child(2),
    .table-body td:nth-child(3),
    .table-body td:nth-child(4),
    .table-body td:nth-child(5),
    .table-body td:nth-child(6) {
        text-align: center;
    }

    .supplier-actions {
        position: relative;
        flex-shrink: 0;
        background: rgba(0, 150, 136, 0.1);
        padding: 15px;
        display: flex;
        justify-content: center;
        gap: 15px;
        border-top: 1px solid #e0e0e0;
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        border-bottom-left-radius: 25px;
        border-bottom-right-radius: 25px;
    }

    .action-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background: #4CAF50;
        color: white;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .action-btn:hover {
        background: #45a049;
    }

    .action-btn:disabled {
        background: #cccccc;
        cursor: not-allowed;
        opacity: 0.7;
    }

    .action-btn:disabled:hover {
        background: #cccccc;
    }

    .action-btn i {
        font-size: 14px;
    }
    
    .action-btn.add-btn {
        background: #4CAF50;
    }

    .action-btn.add-btn:hover {
        background: #45a049;
    }

    .action-btn.edit-btn {
        background: #2196F3;
    }

    .action-btn.edit-btn:hover {
        background: #1976D2;
    }

    .action-btn.delete-btn {
        background: #f44336;
    }

    .action-btn.delete-btn:hover {
        background: #d32f2f;
    }

    .action-btn.assign-btn {
        background: #9C27B0;
    }

    .action-btn.assign-btn:hover {
        background: #7B1FA2;
    }

    .table-body tr {
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .table-body tr:hover {
        background-color: rgba(0, 150, 136, 0.1);
    }

    .table-body tr.selected {
        background-color: rgba(0, 150, 136, 0.2);
        border-left: 4px solid #009688;
    }

    .table-body tr.selected td {
        color: #009688;
    }

    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
    }

    .modal-content {
        background-color: rgba(0, 0, 0, 0.9);
        margin: 5% auto;
        padding: 20px;
        border: 2px solid #009688;
        border-radius: 25px;
        width: 80%;
        max-width: 600px;
        color: white;
        position: relative;
    }

    .close {
        color: #ff6b6b;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    .close:hover {
        transform: rotate(90deg);
        color: #ff4f4f;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        color: #009688;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #009688;
        border-radius: 5px;
        background-color: rgba(0, 0, 0, 0.5);
        color: white;
    }

    .form-group textarea {
        height: 60px;
        resize: vertical;
        min-height: 60px;
        max-height: 120px;
    }

    .submit-btn,
    .delete-btn,
    .cancel-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    .submit-btn {
        background-color: #009688;
        color: white;
    }

    .submit-btn:hover {
        background-color: #00796b;
    }

    .delete-btn {
        background-color: #f44336;
        color: white;
    }

    .delete-btn:hover {
        background-color: #d32f2f;
    }

    .cancel-btn {
        background-color: #757575;
        color: white;
    }

    .cancel-btn:hover {
        background-color: #616161;
    }

    .button-group {
        display: flex;
        gap: 10px;
        justify-content: flex-end;
    }

    small {
        color: #757575;
        font-size: 12px;
    }

    .product-list {
        max-height: 300px;
        overflow-y: auto;
        border: 1px solid #ddd;
        padding: 10px;
        border-radius: 4px;
    }

    .product-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 5px 0;
        cursor: pointer;
        transition: background-color 0.2s ease;
    }

    .product-item:hover {
        background-color: rgba(0, 150, 136, 0.1);
    }

    .product-item.selected-product {
        background-color: rgba(0, 150, 136, 0.3);
        border-left: 3px solid #009688;
        padding-left: 7px;
    }

    .analytics-dashboard {
        padding: 20px;
        background: rgba(0, 0, 0, 0.9);
        border-radius: 25px;
        margin: 20px;
    }

    .dashboard-section {
        margin-bottom: 30px;
        background: rgba(0, 150, 136, 0.1);
        border-radius: 15px;
        padding: 20px;
        border: 1px solid #009688;
    }

    .dashboard-section h2 {
        color: #009688;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid #009688;
    }

    .analytics-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
        margin-top: 20px;
    }

    .analytics-card {
        background: rgba(0, 0, 0, 0.5);
        border-radius: 10px;
        padding: 15px;
        border: 1px solid #009688;
    }

    .analytics-card h3 {
        color: #009688;
        margin-bottom: 15px;
        font-size: 1.1em;
    }

    .analytics-card canvas {
        width: 100% !important;
        height: 200px !important;
    }

    #topProductsList,
    #orderLocationsList,
    #customerStats,
    #topCustomersList,
    #bestProductsList,
    #underperformingProductsList,
    #stockLevelsList,
    #restockAlertsList {
        color: #fff;
        font-size: 0.9em;
    }

    .list-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px;
        border-bottom: 1px solid rgba(0, 150, 136, 0.2);
    }

    .list-item:last-child {
        border-bottom: none;
    }

    .list-item .name {
        color: #fff;
    }

    .list-item .value {
        color: #009688;
        font-weight: bold;
    }

    .alert-item {
        background: rgba(244, 67, 54, 0.1);
        border-left: 3px solid #f44336;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 0 5px 5px 0;
    }

    .alert-item.warning {
        background: rgba(255, 152, 0, 0.1);
        border-left-color: #ff9800;
    }

    .stat-card {
        background: rgba(0, 150, 136, 0.1);
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 10px;
    }

    .stat-card .label {
        color: #ccc;
        font-size: 0.9em;
    }

    .stat-card .value {
        color: #009688;
        font-size: 1.2em;
        font-weight: bold;
        margin-top: 5px;
    }

    @media (max-width: 768px) {
        .analytics-grid {
            grid-template-columns: 1fr;
        }
    }

    .main-content {
        flex-grow: 1;
        padding: 20px;
        overflow-y: auto; 
        background-color: #1a1a1a;
        color: #fff;
    }

    .main-content::-webkit-scrollbar {
        width: 8px;
    }

    .main-content::-webkit-scrollbar-track {
        background: rgba(0, 150, 136, 0.1);
        border-radius: 4px;
    }

    .main-content::-webkit-scrollbar-thumb {
        background: rgba(0, 150, 136, 0.4);
        border-radius: 4px;
        transition: background 0.3s ease;
    }

    .main-content::-webkit-scrollbar-thumb:hover {
        background: rgba(0, 150, 136, 0.6);
    }

    .main-content {
        scrollbar-width: thin;
        scrollbar-color: rgba(0, 150, 136, 0.4) rgba(0, 150, 136, 0.1);
    }

    .analytics-section h2 {
        color: #009688;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(0, 150, 136, 0.3);
    }

    .stats-overview {
        margin-top: 15px;
    }

    .stats-item {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-size: 0.95em;
    }

    .stats-item:last-child {
        border-bottom: none;
    }

    .stat-label {
        color: #ccc; 
        font-weight: 500;
    }

    .stat-value {
        color: #009688;
        font-weight: bold;
    }

    @media (max-width: 768px) {
        .analytics-grid {
            grid-template-columns: 1fr;
        }
    }
    </style>
</body>
</html>