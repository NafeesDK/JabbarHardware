<?php
require_once 'access_control.php';
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$inactive = 300; 
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $inactive)) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}
$_SESSION['last_activity'] = time(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jabbar Admin Dashboard</title>
    <link rel="stylesheet" href="ccc.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>
<body>
    <div id="page1">
        <div class="container">
            <div class="sidebar">
                <div class="logo">
                    <span class="logo-letter">J</span>
                    <span class="logo-text">ABBAR</span>
                </div>
                
                <div class="menu">
                    <div class="menu-item" onclick="window.location.href='aaa.php'">
                        <i class="fas fa-home"></i>
                        <span>Home</span>
                    </div>
                    
                    <div class="menu-item has-submenu active">
                        <i class="fas fa-box"></i>
                        <span>Products</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item <?php echo (!isset($_GET['type']) || $_GET['type'] === 'offers') ? 'active' : ''; ?>" onclick="window.location.href='products.php?type=offers'" style="display: flex;">
                        <i class="fas fa-tag"></i>
                        <span>Offers</span>
                    </div>
                    <div class="submenu-item <?php echo (isset($_GET['type']) && $_GET['type'] === 'regular') ? 'active' : ''; ?>" onclick="window.location.href='products.php?type=regular'" style="display: flex;">
                        <i class="fas fa-box-archive"></i>
                        <span>Regular</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='supplier.php'">
                        <i class="fas fa-truck"></i>
                        <span>Suppliers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='customer.php'">
                        <i class="fas fa-users"></i>
                        <span>View Customers</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='inventory.php'">
                        <i class="fas fa-boxes"></i>
                        <span>Inventory Management</span>
                    </div>

                    <div class="menu-item has-submenu">
                        <i class="fas fa-plus-circle"></i>
                        <span>New Stocks</span>
                        <i class="fas fa-chevron-down submenu-arrow"></i>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='new_stocks.php?action=new'" style="display: none;">
                        <i class="fas fa-dolly"></i>
                        <span>New Product</span>
                    </div>
                    <div class="submenu-item" onclick="window.location.href='new_stocks.php?action=restock'" style="display: none;">
                        <i class="fas fa-truck-ramp-box"></i>
                        <span>Restock</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='feedback.php'">
                        <i class="fas fa-comment"></i>
                        <span>Feedback Management</span>
                    </div>
                    
                    <div class="menu-item" onclick="window.location.href='AandR.php'">
                        <i class="fas fa-chart-bar"></i>
                        <span>Analytics & Reports</span>
                    </div>
                </div>

                <div class="sidebar-bottom">
                    <div class="menu-item hold-button" onclick="toggleHold()">
                        <i class="fas fa-pause-circle"></i>
                        <span id="holdText">Hold</span>
                    </div>
                    
                    <div class="logout" onclick="logout()">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </div>
                </div>
            </div>
            
            <div class="main-content">
                <div class="header">
                    <div class="user-profile">
                        <div class="user-info">
                            <span class="user-name"><?php echo $_SESSION['admin_username']; ?></span>
                        </div>
                        <div class="avatar">
                            <?php if (!empty($_SESSION['admin_profile_image'])): ?>
                                <img src="./AdminPix/<?php echo $_SESSION['admin_profile_image']; ?>" alt="Admin Avatar">
                            <?php else: ?>
                                <img src="./AdminPix/image.webp" alt="Admin Avatar">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="products-list">
                    <h2>Products - <?php echo isset($_GET['type']) && $_GET['type'] === 'regular' ? 'Regular' : 'Offers'; ?></h2>
                    <div class="table-container">
                        <div class="table-header">
                            <table>
                                <thead>
                                    <tr>
                                        <th style='text-align: left;'>Product Name</th>
                                        <th>Description</th>
                                        <th>Original Price</th>
                                        <?php if (!isset($_GET['type']) || $_GET['type'] === 'offers'): ?>
                                        <th>Discounted Price</th>
                                        <?php endif; ?>
                                        <th>Quantity</th>
                                        <th>Suppliers</th>
                                        <th>Image</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                        <div class="table-body">
                            <table>
                                <tbody>
                                    <?php
                                    $category = isset($_GET['type']) && $_GET['type'] === 'regular' ? 'regular' : 'offer';
                                    $query = "SELECT p.id, p.name, p.description, p.original_price, p.discounted_price, 
                                             p.stock_quantity, GROUP_CONCAT(s.name) as supplier_names, p.image_url 
                                             FROM products p 
                                             LEFT JOIN product_suppliers ps ON p.id = ps.product_id 
                                             LEFT JOIN suppliers s ON ps.supplier_id = s.id 
                                             WHERE p.category = '$category'
                                             GROUP BY p.id";
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $display_image_url = $row['image_url'];
                                            if ($display_image_url && strpos($display_image_url, 'http') !== 0 && strpos($display_image_url, 'https') !== 0) {
                                                $display_image_url = '../' . $display_image_url;
                                            }
                                            echo "<tr data-product-id='{$row['id']}'>";
                                            echo "<td>{$row['name']}</td>";
                                            echo "<td style='text-align: center;'>{$row['description']}</td>";
                                            echo "<td style='text-align: center;'>{$row['original_price']}</td>";
                                            if (!isset($_GET['type']) || $_GET['type'] === 'offers') {
                                                echo "<td style='text-align: center;'>{$row['discounted_price']}</td>";
                                            }
                                            echo "<td class='stock-quantity' style='text-align: center;'>{$row['stock_quantity']}</td>";
                                            echo "<td style='text-align: center;'>" . ($row['supplier_names'] ? $row['supplier_names'] : 'No supplier') . "</td>";
                                            echo "<td style='text-align: center;'><img src='{$display_image_url}' alt='Product Image' style='width: 50px; height: auto;'></td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='7' style='text-align: center;'>No " . ($category === 'regular' ? 'regular' : 'offer') . " products found.</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="product-actions">
                            <button onclick="openUpdateModal(selectedProductId)" class="action-btn edit-btn"><i class="fas fa-edit"></i> Edit</button>
                            <button onclick="openDeleteModal(selectedProductId)" class="action-btn delete-btn"><i class="fas fa-trash"></i> Delete</button>
                        </div>
                    </div>
                </div>

                <?php include 'product_modals.php'; ?>

            </div>
            
            <div class="right-sidebar">
                <div class="feedback-section">
                    <h2>AI Inventory Suggestions</h2>
                    <div class="feedback-items">
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer feedback will appear here...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Another feedback sample text...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Yet another feedback example...</p>
                            </div>
                        </div>
                        <div class="feedback-item">
                            <div class="feedback-text">
                                <p>Customer comments and suggestions...</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="analytics-section">
                    <h2>Analytics & Reports Overview</h2>
                    <div class="stats-overview">
                        <div class="stat-item">
                            <span class="stat-label">Monthly Sales:</span>
                            <span class="stat-value" id="overviewMonthlySales">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Total Customers:</span>
                            <span class="stat-value" id="overviewTotalCustomers">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Underperforming Products:</span>
                            <span class="stat-value" id="overviewUnderperformingProducts">Loading...</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-label">Low Stock Alerts:</span>
                            <span class="stat-value" id="overviewLowStockAlerts">Loading...</span>
                        </div>
                         <div class="stat-item">
                            <span class="stat-label">High Stock Items:</span>
                            <span class="stat-value" id="overviewHighStockItems">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let inactivityTime = function() {
            let time;
            let isHeld = false;
            
            window.onload = resetTimer;
            document.onmousemove = resetTimer;
            document.onkeydown = resetTimer;
            document.onclick = resetTimer;
            document.onscroll = resetTimer;
            
            function resetTimer() {
                if (!isHeld) {
                    clearTimeout(time);
                    time = setTimeout(logout, 300000);
                }
            }
            
            window.toggleHold = function() {
                const holdButton = document.querySelector('.hold-button');
                const holdText = document.getElementById('holdText');
                isHeld = !isHeld;
                
                sessionStorage.setItem('isHeld', isHeld);

                if (isHeld) {
                    holdButton.classList.add('active');
                    holdText.textContent = 'Cancel';
                    clearTimeout(time); 
                } else {
                    holdButton.classList.remove('active');
                    holdText.textContent = 'Hold';
                    resetTimer(); 
                }
            };
        };
        
        let isHeld = sessionStorage.getItem('isHeld') === 'true'; 
        const holdButton = document.querySelector('.hold-button');
        const holdText = document.getElementById('holdText');

        if (isHeld) {
            holdButton.classList.add('active');
            holdText.textContent = 'Cancel';
        } else {
            holdButton.classList.remove('active');
            holdText.textContent = 'Hold';
        }

        inactivityTime(); 
        
        function logout() {
            window.location.href = "logout.php";
        }
        
        window.addEventListener('beforeunload', function(e) {
            if (!window.location.href.includes('/admin/')) {
                e.preventDefault();
                e.returnValue = '';
                fetch('logout.php');
            }
        });
        
        setInterval(function() {
            fetch('check_session.php')
                .then(response => response.json())
                .then(data => {
                    if (!data.valid) {
                        window.location.href = "login.php?timeout=1";
                    }
                });
        }, 60000);

        document.addEventListener('DOMContentLoaded', function() {
            const productsMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-box)');
            const productsSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-tag), .submenu-item:has(i.fa-box-archive)');
            
            productsMenuItem.addEventListener('click', function() {
                this.classList.toggle('active');
                
                productsSubmenuItems.forEach(item => {
                    if (this.classList.contains('active')) {
                        item.style.display = 'flex';
                        setTimeout(() => {
                            item.classList.add('show');
                        }, 10);
                    } else {
                        item.classList.remove('show');
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 300);
                    }
                });
            });

            if (productsMenuItem.classList.contains('active')) {
                productsSubmenuItems.forEach(item => {
                    item.style.display = 'flex'; 
                    setTimeout(() => {
                        item.classList.add('show');
                    }, 10);
                });
            }

            const newStocksMenuItem = document.querySelector('.menu-item.has-submenu:has(i.fa-plus-circle)');
            const newStocksSubmenuItems = document.querySelectorAll('.submenu-item:has(i.fa-dolly), .submenu-item:has(i.fa-truck-ramp-box)');

            if (newStocksMenuItem) {
                newStocksMenuItem.addEventListener('click', function() {
                    this.classList.toggle('active');

                    newStocksSubmenuItems.forEach(item => {
                        if (this.classList.contains('active')) {
                            item.style.display = 'flex';
                            setTimeout(() => {
                                item.classList.add('show');
                            }, 10);
                        } else {
                            item.classList.remove('show');
                            setTimeout(() => {
                                item.style.display = 'none';
                            }, 300);
                        }
                    });
                });
            }
        });

        let selectedProductId = null;

        document.addEventListener('DOMContentLoaded', function() {
            const productTable = document.querySelector('.table-body table tbody');
            const productActionsDiv = document.querySelector('.product-actions');

            if (productActionsDiv) {
                const editBtn = productActionsDiv.querySelector('.edit-btn');
                const deleteBtn = productActionsDiv.querySelector('.delete-btn');
                if (editBtn) editBtn.disabled = true;
                if (deleteBtn) deleteBtn.disabled = true;
            }

            if (productTable) {
                productTable.addEventListener('click', function(event) {
                    const targetRow = event.target.closest('tr');
                    if (!targetRow) return;

                    const previouslySelected = productTable.querySelector('tr.selected');

                    if (previouslySelected && previouslySelected === targetRow) {
                         targetRow.classList.remove('selected');
                         selectedProductId = null;
                         if (productActionsDiv) {
                            const editBtn = productActionsDiv.querySelector('.edit-btn');
                            const deleteBtn = productActionsDiv.querySelector('.delete-btn');
                            if (editBtn) editBtn.disabled = true;
                            if (deleteBtn) deleteBtn.disabled = true;
                         }
                         return;
                    }

                    if (previouslySelected) {
                        previouslySelected.classList.remove('selected');
                    }

                    targetRow.classList.add('selected');
                    selectedProductId = targetRow.dataset.productId;

                    if (productActionsDiv) {
                        const editBtn = productActionsDiv.querySelector('.edit-btn');
                        const deleteBtn = productActionsDiv.querySelector('.delete-btn');
                         if (editBtn) editBtn.disabled = false;
                         if (deleteBtn) deleteBtn.disabled = false;
                    }
                });
            }

            if (productActionsDiv) {
                productActionsDiv.addEventListener('click', function(event) {
                    const editBtn = event.target.closest('.edit-btn');
                    const deleteBtn = event.target.closest('.delete-btn');

                    if (editBtn && !editBtn.disabled) {
                         if (selectedProductId) {
                             openUpdateModal(selectedProductId);
                         } else {
                             alert('Please select a product to edit.');
                         }
                    } else if (deleteBtn && !deleteBtn.disabled) {
                         if (selectedProductId) {
                             openDeleteModal(selectedProductId);
                         } else {
                             alert('Please select a product to delete.');
                         }
                    }
                });
            }
        });

        function openUpdateModal(productId) {
            if (!productId) {
                alert('Please select a product first');
                return;
            }
            
            fetch('get_product.php?id=' + productId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const product = data.product;
                        
                        const editForm = document.getElementById('updateProductForm');
                        if (!editForm) {
                            console.error('Update form not found');
                            return;
                        }

                        const fields = {
                            'updateProductId': product.id,
                            'updateProductName': product.name,
                            'updateProductDescription': product.description,
                            'updateOriginalPrice': product.original_price,
                            'updateSupplier': product.supplier_id,
                            'updateProductCategory': product.category
                        };

                        Object.entries(fields).forEach(([id, value]) => {
                            const element = document.getElementById(id);
                            if (element) {
                                element.value = value;
                            } else {
                                console.warn(`Field ${id} not found`);
                            }
                        });
                        
                        const discountedPriceField = document.getElementById('updateDiscountedPrice');
                        if (discountedPriceField) {
                            if (product.category === 'offer') {
                                discountedPriceField.value = product.discounted_price;
                                discountedPriceField.parentElement.style.display = 'block';
                            } else {
                                discountedPriceField.parentElement.style.display = 'none';
                            }
                        }
                        
                        const currentImageContainer = document.getElementById('currentProductImageContainer');
                        const updateProductImageInput = document.getElementById('updateProductImage');
                        let existingImagePathInput = document.getElementById('existingProductImagePath');

                        if (!existingImagePathInput) {
                            existingImagePathInput = document.createElement('input');
                            existingImagePathInput.type = 'hidden';
                            existingImagePathInput.id = 'existingProductImagePath';
                            existingImagePathInput.name = 'existing_image_path';
                            editForm.appendChild(existingImagePathInput);
                        }
                        
                        existingImagePathInput.value = product.image_url;

                        if (currentImageContainer) {
                            currentImageContainer.innerHTML = ''; 
                        }

                        const modal = document.getElementById('updateProductModal');
                        if (modal) {
                            modal.style.display = 'block';
                        } else {
                            console.error('Update modal not found');
                        }
                    } else {
                        alert('Error fetching product details');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error fetching product details');
                });
        }

        function openDeleteModal(productId) {
            document.getElementById('deleteProductId').value = productId;
            document.getElementById('deleteProductModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        document.getElementById('updateProductForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('update_product.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeModal('updateProductModal');
                    location.reload();
                } else {
                    alert('Error updating product');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error updating product');
            });
        });

        document.getElementById('deleteProductForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('delete_product.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    closeModal('deleteProductModal');
                    location.reload();
                } else {
                    alert('Error deleting product: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An unexpected error occurred during deletion.');
            });
        });

        // Function to fetch and display overview stats in right sidebar
        function fetchOverviewStats() {
            // Fetch Monthly Sales
            fetch('get_monthly_sales.php')
                .then(response => response.json())
                .then(data => {
                    const totalMonthlySales = data.values.reduce((sum, value) => sum + parseFloat(value), 0);
                    document.getElementById('overviewMonthlySales').textContent = `Rs. ${totalMonthlySales.toFixed(2)}`;
                }).catch(error => console.error('Error fetching monthly sales overview:', error));

            // Fetch Total Customers
            fetch('get_customer_stats.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewTotalCustomers').textContent = data.totalCustomers;
                }).catch(error => console.error('Error fetching customer stats overview:', error));

            // Fetch Product Performance (Underperforming)
            fetch('get_product_performance.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewUnderperformingProducts').textContent = data.underperforming.length;
                }).catch(error => console.error('Error fetching product performance overview:', error));

            // Fetch Inventory Health (Low Stock Alerts)
            fetch('get_inventory_health.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('overviewLowStockAlerts').textContent = data.restockAlerts.length;
                     document.getElementById('overviewHighStockItems').textContent = data.stockLevels.length;
                }).catch(error => console.error('Error fetching inventory health overview:', error));
        }

        // Call the function to fetch and display overview stats on page load
        fetchOverviewStats();
    </script>

    <style>
    .table-container {
        position: relative;
        height: calc(100vh - 150px); 
        overflow: hidden;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        border-radius: 25px;
        display: flex;
        flex-direction: column;
    }

    .table-header {
        flex-shrink: 0;
        background-color: rgba(0, 150, 136, 0.1);
        border-top-left-radius: 25px;
        border-top-right-radius: 25px;
    }

    .table-header table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .table-header th {
        padding: 12px 15px;
        text-align: center;
        color: white;
        width: auto;
    }

    .table-header th:nth-child(1), .table-body td:nth-child(1) {
        width: 20%;
    }

    .table-header th:nth-child(2), .table-body td:nth-child(2) {
        width: 20%;
        white-space: normal;
        overflow-x: visible;
    }

    .table-header th:nth-child(3), .table-body td:nth-child(3) {
        width: 10%;
    }

    .table-header th:nth-child(4), .table-body td:nth-child(4) {
        width: 10%;
    }

    .table-header th:nth-child(5), .table-body td:nth-child(5) {
        width: 10%;
    }

    .table-header th:nth-child(6), .table-body td:nth-child(6) {
        width: 10%;
    }

    .table-header th:nth-child(7), .table-body td:nth-child(7) {
        width: 11%;
        text-align: center;
    }

    .table-body {
        flex-grow: 1;
        overflow-y: auto;
    }

    .table-body::-webkit-scrollbar {
        width: 8px;
    }

    .table-body::-webkit-scrollbar-track {
        background: rgba(0, 150, 136, 0.1);
        border-radius: 4px;
    }

    .table-body::-webkit-scrollbar-thumb {
        background: rgba(0, 150, 136, 0.3);
        border-radius: 4px;
        transition: background 0.3s ease;
    }

    .table-body::-webkit-scrollbar-thumb:hover {
        background: rgba(0, 150, 136, 0.5);
    }

    .table-body {
        scrollbar-width: thin;
        scrollbar-color: rgba(0, 150, 136, 0.3) rgba(0, 150, 136, 0.1);
    }

    .table-body table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
    }

    .table-body td {
         padding: 12px 15px;
         text-align: left;
         white-space: normal;
    }

    .table-body td:nth-child(3),
    .table-body td:nth-child(4),
    .table-body td:nth-child(5),
    .table-body td:nth-child(6),
    .table-body td:nth-child(7) {
        text-align: center;
    }

    .product-actions {
        position: relative;
        flex-shrink: 0;
        background: rgba(0, 150, 136, 0.1);
        padding: 15px;
        display: flex;
        justify-content: center;
        gap: 15px;
        border-top: 1px solid #e0e0e0;
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
        border-bottom-left-radius: 25px;
        border-bottom-right-radius: 25px;
    }

    .action-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background: #4CAF50;
        color: white;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .action-btn:hover {
        background: #45a049;
    }

    .action-btn:disabled {
        background: #cccccc;
        cursor: not-allowed;
        opacity: 0.7;
    }

    .action-btn:disabled:hover {
        background: #cccccc;
    }

    .action-btn i {
        font-size: 14px;
    }
    
    .action-btn.edit-btn {
        background: #2196F3;
        margin-right: 10px;
    }

    .action-btn.edit-btn:hover {
        background: #1976D2;
    }

    .action-btn.delete-btn {
        background: #f44336;
    }

    .action-btn.delete-btn:hover {
        background: #d32f2f;
    }

    .table-body tr {
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .table-body tr:hover {
        background-color: rgba(0, 150, 136, 0.1);
    }

    .table-body tr.selected {
        background-color: rgba(0, 150, 136, 0.2);
        border-left: 4px solid #009688;
    }

    .table-body tr.selected td {
        color: #009688;
    }

    .analytics-section h2 {
        color: #009688;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(0, 150, 136, 0.3);
    }

    .stats-overview {
        margin-top: 15px;
    }

    .stats-item {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        font-size: 0.95em;
    }

    .stats-item:last-child {
        border-bottom: none;
    }

    .stat-label {
        color: #ccc;
        font-weight: 500;
    }

    .stat-value {
        color: #009688;
        font-weight: bold;
    }
    </style>
</body>
</html>