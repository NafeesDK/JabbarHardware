<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}
$query = "SELECT 
            DATE_FORMAT(calendar.month, '%Y-%m') as month,
            COALESCE(SUM(o.total_amount), 0) as total_sales
          FROM (
              SELECT LAST_DAY(DATE_SUB(CURDATE(), INTERVAL n MONTH)) + INTERVAL 1 DAY - INTERVAL 1 DAY as month
              FROM (
                  SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3
                  UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7
                  UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL SELECT 10 UNION ALL SELECT 11
              ) AS months
          ) AS calendar
          LEFT JOIN orders o ON DATE_FORMAT(o.created_at, '%Y-%m') = DATE_FORMAT(calendar.month, '%Y-%m')
          GROUP BY month
          ORDER BY month";

$result = mysqli_query($conn, $query);

$labels = [];
$values = [];

while ($row = mysqli_fetch_assoc($result)) {
    $month_name = date('M', strtotime($row['month']));
    $labels[] = $month_name;
    $values[] = $row['total_sales'];
}

header('Content-Type: application/json');
echo json_encode([
    'labels' => $labels,
    'values' => $values
]);
?> 