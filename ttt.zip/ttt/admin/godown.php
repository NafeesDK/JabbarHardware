<?php
require_once 'access_control.php';
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$is_godown_admin = isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'godown_admin';

$inactive = 300; 
if (!$is_godown_admin && isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $inactive)) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

if (!$is_godown_admin) {
    $_SESSION['last_activity'] = time();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warehouse Management - Jabbar</title>
    <link rel="stylesheet" href="ccc.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div id="page1">
        <div class="container">
            <div class="header">
                <div class="logo">
                    <span class="logo-letter">J</span>
                    <span class="logo-text">ABBAR</span>
                </div>
                <div class="user-profile">
                    <div class="user-info">
                        <span class="user-name"><?php echo $_SESSION['admin_username']; ?></span>
                    </div>
                    <div class="avatar">
                        <?php if (!empty($_SESSION['admin_profile_image'])): ?>
                            <img src="./AdminPix/<?php echo $_SESSION['admin_profile_image']; ?>" alt="Admin Avatar">
                        <?php else: ?>
                            <img src="./AdminPix/image.webp" alt="Admin Avatar">
                        <?php endif; ?>
                    </div>
                    <div class="logout" onclick="logout()">
                        <i class="fas fa-sign-out-alt"></i>
                    </div>
                </div>
            </div>
            
            <div class="godown-content">
                <h2>Warehouse Management</h2>
                <div class="godown-table">
                    <div class="table-header">
                        <table>
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Payment Method</th>
                                    <th>Customer Name</th>
                                    <th>Address</th>
                                    <th>Phone No.</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div class="table-body">
                        <table>
                            <tbody>
                                <?php
                                $query = "SELECT o.id, o.quantity, o.payment_method, o.tracking_number,
                                         p.name as product_name,
                                         u.fullname as customer_name,
                                         cld.address, cld.city, cld.phone_no,
                                         ot.status
                                         FROM orders o
                                         JOIN products p ON o.product_id = p.id
                                         JOIN users u ON o.user_id = u.id
                                         JOIN `c.l.details` cld ON o.delivery_details_id = cld.id
                                         JOIN order_tracking ot ON o.tracking_number = ot.tracking_number
                                         WHERE ot.status = 'Order Placed' OR ot.status = 'Out for delivery' OR ot.status = 'Pickup'
                                         ORDER BY o.created_at ASC";
                                
                                $result = $conn->query($query);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>
                                                <td>{$row['id']}</td>
                                                <td>{$row['product_name']}</td>
                                                <td>{$row['quantity']}</td>
                                                <td>{$row['payment_method']}</td>
                                                <td>{$row['customer_name']}</td>
                                                <td>{$row['address']}, {$row['city']}</td>
                                                <td>{$row['phone_no']}</td>
                                                <td>
                                                    <select class='status-dropdown' data-tracking-number='{$row['tracking_number']}'>
                                                        <option value='Order Placed' " . ($row['status'] == 'Order Placed' ? 'selected' : '') . ">Order Placed</option>
                                                        <option value='Pickup' " . ($row['status'] == 'Pickup' ? 'selected' : '') . ">Pickup</option>
                                                        <option value='Out for delivery' " . ($row['status'] == 'Out for delivery' ? 'selected' : '') . ">Out for delivery</option>
                                                        <option value='Delivered' " . ($row['status'] == 'Delivered' ? 'selected' : '') . ">Delivered</option>
                                                    </select>
                                                </td>
                                              </tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='8'>No pending orders</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
    .container {
        padding: 20px;
        height: 100vh;
        display: flex;
        flex-direction: column;
    }

    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 20px;
        background: rgba(0, 0, 0, 0.2);
        border-radius: 10px;
        margin-bottom: 20px;
    }

    .logo {
        order: 1;
    }

    .user-profile {
        display: flex;
        align-items: center;
        gap: 15px;
        order: 2;
    }

    .user-info {
        text-align: right;
    }

    .user-name {
        color: #fff;
        font-weight: 500;
    }

    .avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        overflow: hidden;
    }

    .avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .logout {
        color: #fff;
        cursor: pointer;
        font-size: 1.2em;
        padding: 5px;
        transition: color 0.3s ease;
    }

    .logout:hover {
        color: #ff4444;
    }

    .godown-content {
        padding: 0 20px 20px 20px;
        flex: 1;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    .godown-content h2 {
        margin-top: 0;
        margin-bottom: 10px;
    }

    .godown-table {
        flex: 1;
        background: rgba(0, 0, 0, 0.2);
        border-radius: 15px;
        padding-bottom: 20px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    .godown-table h3 {
        display: none;
    }

    .table-header {
        width: 100%;
    }

    .table-header table {
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        table-layout: fixed;
    }

    .table-body {
        flex: 1;
        overflow-y: auto;
        border-top: none;
    }

    .table-body::-webkit-scrollbar {
        width: 8px;
    }

    .table-body::-webkit-scrollbar-track {
        background: rgba(0, 0, 0, 0.1);
        border-radius: 4px;
    }

    .table-body::-webkit-scrollbar-thumb {
        background: rgba(0, 150, 136, 0.5);
        border-radius: 4px;
    }

    .table-body::-webkit-scrollbar-thumb:hover {
        background: rgba(0, 150, 136, 0.7);
    }

    .table-body {
        scrollbar-width: thin;
        scrollbar-color: rgba(0, 150, 136, 0.5) rgba(0, 0, 0, 0.1);
    }

    .table-body table {
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        table-layout: fixed;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
    }

    th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        white-space: nowrap;
    }

    th {
        background-color: rgba(0, 150, 136, 0.1);
        color: #009688;
    }

    .table-header th:nth-child(1),
    .table-body td:nth-child(1) {
        width: 8%; /* Order ID */
    }

    .table-header th:nth-child(2),
    .table-body td:nth-child(2) {
        width: 15%; /* Product */
    }

    .table-header th:nth-child(3),
    .table-body td:nth-child(3) {
        width: 8%; /* Quantity */
    }
    
    .table-header th:nth-child(4),
    .table-body td:nth-child(4) {
        width: 12%; /* Payment Method */
    }
    
    .table-header th:nth-child(5),
    .table-body td:nth-child(5) {
        width: 15%; /* Customer Name */
    }

    .table-header th:nth-child(6),
    .table-body td:nth-child(6) {
        width: 20%; /* Address */
    }
    
    .table-header th:nth-child(7),
    .table-body td:nth-child(7) {
        width: 12%; /* Phone No. */
    }

    .table-header th:nth-child(8),
    .table-body td:nth-child(8) {
        width: 10%; /* Status Dropdown */
    }

    .action-btn {
        background: #009688;
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 5px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .action-btn:hover {
        background: #00796b;
    }

    .status-dropdown {
        padding: 5px;
        border-radius: 5px;
        border: 1px solid #009688;
        background-color: rgba(0, 150, 136, 0.2);
        color: #fff;
        cursor: pointer;
    }

    .status-dropdown option {
        background-color: #333;
        color: #fff;
    }

    </style>

    <script>
        function logout() {
            window.location.href = "logout.php";
        }
        
        const isGodownAdmin = <?php echo json_encode($is_godown_admin); ?>;

        document.querySelector('.table-body tbody').addEventListener('change', function(event) {
            const target = event.target;
            if (target.classList.contains('status-dropdown')) {
                const trackingNumber = target.dataset.trackingNumber;
                const newStatus = target.value;
                
                updateOrderStatus(trackingNumber, newStatus);
            }
        });

        function updateOrderStatus(trackingNumber, newStatus) {
            console.log(`Updating order ${trackingNumber} to status ${newStatus}`);
            
            const formData = new FormData();
            formData.append('tracking_number', trackingNumber);
            formData.append('status', newStatus);

            fetch('godown_order_status_update.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Status updated successfully:', data.message);
                } else {
                    console.error('Error updating status:', data.message);
                }
            })
            .catch((error) => {
                console.error('Fetch error:', error);
            });
        }

        if (!isGodownAdmin) {
            let inactivityTime = function() {
                let time;
                
                window.onload = resetTimer;
                document.onmousemove = resetTimer;
                document.onkeydown = resetTimer;
                document.onclick = resetTimer;
                document.onscroll = resetTimer;
                
                function resetTimer() {
                    clearTimeout(time);
                    time = setTimeout(logout, 300000);
                }
            };
            inactivityTime(); 
        }

        window.addEventListener('load', function() {
            const headerTable = document.querySelector('.table-header table');
            const bodyTable = document.querySelector('.table-body table');
            
            if (headerTable && bodyTable) {
                const scrollWidth = bodyTable.offsetWidth - bodyTable.clientWidth;
                if (scrollWidth > 0) {
                    headerTable.style.width = `calc(100% - ${scrollWidth}px)`;
                }
            }
        });
    </script>
</body>
</html>