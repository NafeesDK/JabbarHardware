<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$best_query = "SELECT 
                p.name,
                p.stock_quantity,
                COUNT(o.id) as order_count,
                SUM(o.quantity) as total_sold
              FROM products p
              LEFT JOIN orders o ON p.id = o.product_id
              WHERE o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
              GROUP BY p.id
              ORDER BY total_sold DESC
              LIMIT 3";

$best_result = mysqli_query($conn, $best_query);
$best_products = [];

while ($row = mysqli_fetch_assoc($best_result)) {
    $best_products[] = [
        'name' => $row['name'],
        'sales' => $row['total_sold'] ?? 0
    ];
}

$under_query = "SELECT 
                p.name,
                p.stock_quantity,
                COALESCE(SUM(o.quantity), 0) as total_sold
              FROM products p
              LEFT JOIN orders o ON p.id = o.product_id 
                AND o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
              GROUP BY p.id
              HAVING total_sold <= 1
              ORDER BY total_sold ASC, p.stock_quantity ASC
              LIMIT 3";

$under_result = mysqli_query($conn, $under_query);
$under_products = [];

while ($row = mysqli_fetch_assoc($under_result)) {
    $under_products[] = [
        'name' => $row['name'],
        'sales' => $row['total_sold']
    ];
}

$data = [
    'best' => $best_products,
    'underperforming' => $under_products
];

header('Content-Type: application/json');
echo json_encode($data);
?> 