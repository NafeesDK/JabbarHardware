<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $supplier_id = intval($_POST['id']);

    $check_query = "SELECT COUNT(*) as product_count FROM products WHERE supplier_id = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("i", $supplier_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row['product_count'] > 0) {
        echo json_encode([
            'success' => false, 
            'message' => 'Cannot delete supplier: There are products associated with this supplier. Please reassign or delete these products first.'
        ]);
        exit();
    }

    $query = "DELETE FROM suppliers WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $supplier_id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Supplier deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error deleting supplier: ' . $conn->error]);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?> 