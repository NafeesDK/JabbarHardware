<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $original_price = $_POST['original_price'];
    $category = $_POST['category'];
    $supplier_id = $_POST['supplier_id'];
    $discounted_price = ($category === 'offer') ? $_POST['discounted_price'] : null;

    $image_url = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $target_dir = "../Image/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
        $new_filename = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $new_filename;
        
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_url = "Image/" . $new_filename;
        }
    } else if (isset($_POST['existing_image_path'])) {
        $image_url = $_POST['existing_image_path'];
    }

    try {
        $conn->begin_transaction();

        if (empty($image_url)) {
            $query = "UPDATE products SET name = ?, description = ?, original_price = ?, discounted_price = ?, category = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssdssi", $name, $description, $original_price, $discounted_price, $category, $product_id);
        } else {
            $query = "UPDATE products SET name = ?, description = ?, original_price = ?, discounted_price = ?, image_url = ?, category = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssdsssi", $name, $description, $original_price, $discounted_price, $image_url, $category, $product_id);
        }
        
        if (!$stmt->execute()) {
            throw new Exception("Error updating product: " . $stmt->error);
        }

        if ($supplier_id) {
            $delete_query = "DELETE FROM product_suppliers WHERE product_id = ?";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->bind_param("i", $product_id);
            
            if (!$delete_stmt->execute()) {
                throw new Exception("Error removing existing supplier relationships: " . $delete_stmt->error);
            }

            $supplier_query = "INSERT INTO product_suppliers (product_id, supplier_id) VALUES (?, ?)";
            $supplier_stmt = $conn->prepare($supplier_query);
            $supplier_stmt->bind_param("ii", $product_id, $supplier_id);
            
            if (!$supplier_stmt->execute()) {
                throw new Exception("Error assigning supplier: " . $supplier_stmt->error);
            }
        }

        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Product updated successfully']);

    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}

echo json_encode(['success' => false, 'message' => 'Invalid request method']);
?> 