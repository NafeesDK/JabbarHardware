<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $supplier_id = $_POST['supplier_id'] ?? null;
    $products_str = $_POST['products'] ?? '';
    
    if (!$supplier_id || empty($products_str)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit();
    }

    $products = array_filter(explode(',', $products_str));

    try {
        $conn->begin_transaction();

        foreach ($products as $product_id) {
            $check_query = "SELECT 1 FROM product_suppliers WHERE product_id = ? AND supplier_id = ?";
            $check_stmt = $conn->prepare($check_query);
            $check_stmt->bind_param("ii", $product_id, $supplier_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();

            if ($check_result->num_rows === 0) {
                $insert_query = "INSERT INTO product_suppliers (product_id, supplier_id) VALUES (?, ?)";
                $insert_stmt = $conn->prepare($insert_query);
                $insert_stmt->bind_param("ii", $product_id, $supplier_id);
                $insert_stmt->execute();
            }
        }

        $conn->commit();
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Products assigned successfully']);
    } catch (Exception $e) {
        $conn->rollback();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Error assigning products: ' . $e->getMessage()]);
    }
} else {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?> 