<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$query = "SELECT 
            u.fullname as name,
            COUNT(o.id) as order_count,
            SUM(o.total_amount) as total_spent
          FROM orders o
          JOIN users u ON o.user_id = u.id
          WHERE o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
          GROUP BY o.user_id
          ORDER BY total_spent DESC
          LIMIT 3";

$result = mysqli_query($conn, $query);
$customers = [];

while ($row = mysqli_fetch_assoc($result)) {
    $customers[] = [
        'name' => $row['name'],
        'total_spent' => number_format($row['total_spent'], 2)
    ];
}

header('Content-Type: application/json');
echo json_encode($customers);
?> 