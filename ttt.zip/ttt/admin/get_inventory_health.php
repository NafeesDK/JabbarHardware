<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$stock_query = "SELECT 
                name,
                stock_quantity as quantity
              FROM products
              ORDER BY stock_quantity DESC
              LIMIT 5";

$stock_result = mysqli_query($conn, $stock_query);
$stock_levels = [];

while ($row = mysqli_fetch_assoc($stock_result)) {
    $stock_levels[] = [
        'name' => $row['name'],
        'quantity' => $row['quantity']
    ];
}

$alert_query = "SELECT 
                name,
                stock_quantity as quantity
              FROM products
              WHERE stock_quantity <= 5
              ORDER BY stock_quantity ASC";

$alert_result = mysqli_query($conn, $alert_query);
$restock_alerts = [];

while ($row = mysqli_fetch_assoc($alert_result)) {
    $restock_alerts[] = [
        'name' => $row['name'],
        'quantity' => $row['quantity']
    ];
}

$data = [
    'stockLevels' => $stock_levels,
    'restockAlerts' => $restock_alerts
];

header('Content-Type: application/json');
echo json_encode($data);
?> 