<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$total_query = "SELECT COUNT(*) as total FROM users";
$total_result = mysqli_query($conn, $total_query);
$total_customers = mysqli_fetch_assoc($total_result)['total'];

$frequent_query = "SELECT COUNT(*) as frequent_count 
                 FROM (
                     SELECT user_id 
                     FROM orders 
                     GROUP BY user_id 
                     HAVING COUNT(*) > 2
                 ) as frequent_customers";
$frequent_result = mysqli_query($conn, $frequent_query);
$frequent_customers = mysqli_fetch_assoc($frequent_result)['frequent_count'];

$frequent_percentage = $total_customers > 0 ? round(($frequent_customers / $total_customers) * 100) : 0;

$data = [
    'totalCustomers' => $total_customers,
    'repeatCustomers' => $frequent_percentage
];

header('Content-Type: application/json');
echo json_encode($data);
?> 