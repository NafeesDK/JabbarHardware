<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if (!isset($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'Order ID not provided']);
    exit();
}

$orderId = $_GET['id'];

$query = "SELECT o.*, p.name AS product_name, u.fullname AS username, ot.status,
                 CONCAT(cld.address, ', ', cld.city) AS shipping_address, 
                 cld.phone_no AS phone_number
          FROM orders o 
          JOIN products p ON o.product_id = p.id 
          JOIN users u ON o.user_id = u.id 
          JOIN order_tracking ot ON o.id = ot.order_id 
          JOIN `c.l.details` cld ON o.delivery_details_id = cld.id
          WHERE o.id = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $orderId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $order = $result->fetch_assoc();
    echo json_encode(['success' => true, 'order' => $order]);
} else {
    echo json_encode(['success' => false, 'message' => 'Order not found']);
}

$stmt->close();
$conn->close();
?> 