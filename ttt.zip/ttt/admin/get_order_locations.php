<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$query = "SELECT c.city, COUNT(o.id) as count 
          FROM orders o 
          JOIN `c.l.details` c ON o.delivery_details_id = c.id 
          WHERE o.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
          GROUP BY c.city 
          ORDER BY count DESC 
          LIMIT 5";

$result = mysqli_query($conn, $query);
$locations = [];

while ($row = mysqli_fetch_assoc($result)) {
    $locations[] = [
        'city' => $row['city'],
        'count' => $row['count']
    ];
}

header('Content-Type: application/json');
echo json_encode($locations);
?> 