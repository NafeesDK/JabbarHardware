<?php
session_start();
include '../conndb.php';

if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$product_id = $data['product_id'] ?? null;
$new_quantity = $data['new_quantity'] ?? null;

if (!$product_id || $new_quantity === null) {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit();
}

try {
    // Start transaction
    $conn->begin_transaction();

    // Update products table
    $update_product = $conn->prepare("UPDATE products SET stock_quantity = ? WHERE id = ?");
    $update_product->bind_param("ii", $new_quantity, $product_id);
    $update_product->execute();

    // Get current stock quantity
    $get_current = $conn->prepare("SELECT stock_quantity FROM products WHERE id = ?");
    $get_current->bind_param("i", $product_id);
    $get_current->execute();
    $result = $get_current->get_result();
    $current = $result->fetch_assoc();

    // Add new stock history entry
    $insert_history = $conn->prepare("INSERT INTO stock_history (product_id, previous_quantity, new_quantity, change_type) VALUES (?, ?, ?, 'adjustment')");
    $insert_history->bind_param("iii", $product_id, $current['stock_quantity'], $new_quantity);
    $insert_history->execute();

    // Commit transaction
    $conn->commit();

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?> 