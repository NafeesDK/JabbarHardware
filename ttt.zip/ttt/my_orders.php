<?php
session_start();
require_once 'conndb.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ttt.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$order_query = "
    SELECT ot.tracking_number, p.name AS product_name, o.created_at 
    FROM order_tracking ot 
    JOIN orders o ON ot.order_id = o.id 
    JOIN products p ON o.product_id = p.id 
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC";
$stmt = $conn->prepare($order_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jabbar Hardware Stores</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            overflow-x: hidden !important;
            margin: 0;
            height: 100vh;
            overflow-y: scroll;
            background-image: url('logoo.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #e0e0e0;
        }
        
        #page1 {
            background-color: rgba(0, 0, 0, 0.80);
            height: 100vh;
        }

        #container {
            background-color: rgba(0, 0, 0, 0.80);
            padding: 20px;
            border-radius: 15px;
            margin: 0 20px;
        }
        
        .menu-icon {
            font-size: 1.9rem;
            cursor: pointer;
            color: #e0e0e0;text-decoration: none; 
            transition: color 0.3s ease; 
        }

        .menu-icon:hover {
            color: #009688; 
        }

        .header {
            background-color: rgba(0, 0, 0, 0.85);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .header h1 {
            color: #009688;
            margin: 0;
            font-size: 2rem;
        }

        .order-list {
            margin-top: 20px;
        }

        .order-item {
            background: rgba(0, 0, 0, 0.85);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
            border: 1px solid rgba(0, 150, 136, 0.3);
        }

        .order-item h3 {
            color: #009688;
        }

        .order-item p {
            margin: 5px 0;
            color: #e0e0e0;
        }
    </style>
</head>
<body>
<div id="page1">
    <div id="container">
        <div class="header">
            <a href="ttt.php" class="menu-icon">&#8592;</a>
            <h1>Tracking No.</h1>
        </div>

        <div class="order-list">
            <?php if ($result->num_rows > 0): ?>
                <?php $count = 1; ?>
                <?php while ($order = $result->fetch_assoc()): ?>
                    <div class="order-item">
                        <h3>Order #<?php echo $count++; ?></h3>
                        <p>Tracking Number: <?php echo $order['tracking_number']; ?></p>
                        <p>Product Name: <?php echo $order['product_name']; ?></p>
                        <p>Date Ordered: <?php echo date("F j, Y", strtotime($order['created_at'])); ?></p>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No orders found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>