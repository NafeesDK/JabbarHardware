<?php
session_start();
require_once 'conndb.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$userId = $_SESSION['user_id'];
$response = ['success' => false, 'cards' => []];

error_log("Fetching cards for user ID: " . $userId);

$stmt = $conn->prepare("SELECT id, cardholderName, cardNumber, expiryDate 
                       FROM carddetails 
                       WHERE user_id = ?
                       ORDER BY created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($card = $result->fetch_assoc()) {
        $card['displayNumber'] = '•••• •••• •••• ' . substr($card['cardNumber'], -4);
        $response['cards'][] = $card;
    }
    $response['success'] = true;
} else {
    $response['message'] = 'No saved cards found';
}

error_log("Response: " . json_encode($response));

$stmt->close();
echo json_encode($response);
?>