<?php
session_start();
require_once 'conndb.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link rel="stylesheet" href="Viwcart.css">
    <link rel="stylesheet" href="ordrnow.css">
    <link rel="stylesheet" href="OrderDetails.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body data-logged-in="<?php echo isset($_SESSION['user_id']) ? 'true' : 'false'; ?>" data-user-id="<?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : ''; ?>">
    <header>
        <h1>Your Cart</h1>
        <button class="back-to-home" onclick="window.history.back();">Back to Home
            <span class="cover"></span>
        </button>
    </header>
    <main>
        <div class="cart-container">
            <div class="cart-grid" id="cartItems">
            </div>
        </div>
    </main>

    <div class="cd-popup" id="confirmation-popup">
        <div class="cd-popup-container">
            <p id="confirmation-message">Are you sure you want to delete this item from your cart?</p>
            <label for="delete-quantity">How many to delete:</label>
            <input type="number" id="delete-quantity" min="1" value="1" />
            <ul class="cd-buttons">
                <li><a id="confirm-delete" class="card-btn confirm">Confirm</a></li>
                <li><a id="cancel-delete" class="card-btn cancel">Cancel</a></li>
            </ul>
        </div>
    </div>


    <div class="popup-container" id="orderNowPopup">
        <div class="popup">
            <span class="close-btn" onclick="closeOrderNowPopup()">&times;</span>
            <input type="hidden" id="selectedCardId" value="">
            <div class="product-details">
                <div class="product-image-quantity">
                    <img id="popupProductImg" src="" alt="Product Image" class="popup-image">
                    <div class="quantity-selector">
                        <button onclick="changeQuantity(-1)">&#8722;</button>
                        <span id="quantityValue">1</span>
                        <button onclick="changeQuantity(1)">&#43;</button>
                    </div>
                    <div class="vertical-line1"></div>
                    <div class="color-options-container">
                        <span class="color-fam-label">Color Family:</span>
                        <div class="color-options" id="colorOptions"></div>
                    </div>
                </div>
                <h3 id="popupProductName"></h3>
                <div class="price-container">
                    <span class="delivery-fee" title="Delivery fee only applies for locations outside Sainthamaruthu - Maruthamunai">
                        LKR. 400 +
                    </span>
                    <!-- <span class="tooltip">Delivery fee only applies for locations outside Sainthamaruthu - Maruthamunai</span> -->
                    <span class="order-price" id="popupOrderPrice"></span>
                </div>
                <div class="confirm-order-details" onclick="confirmOrderDetails()" onmouseover="showDeliveryDetails()" onmouseout="hideDeliveryDetails()"> 
                    <span>Confirm </span>delivery details
                    <div class="delivery-details-notification" id="delivery-details-notification">
                    </div>
                </div>
                <div class="payment-details" onclick="showPaymentDetails()" 
                    onmouseover="showPaymentDetailsNotification()" 
                    onmouseout="hidePaymentDetailsNotification()">
                    Payment Details - <span>Please fill</span>
                    <div class="payment-details-notification" id="payment-details-notification"></div>
                </div>
                <div class="button-container">
                    <button class="order-now-btn" onclick="placeOrder(currentProductId, currentQuantity)">Place Order</button>
                </div>
            </div>
        </div>
    </div>

    <div class="popup-container" id="confirmOrderDetailsPopup">
        <div class="popup">
            <span class="close-btn" onclick="closeConfirmOrderDetailsPopup()">&times;</span>
            <form id="confirmOrderDetailsForm">
                <div class="form-group">
                    <label for="fullName">Full Name:</label> 
                    <input type="text" id="fullName" name="fullName" required>
                </div>
                <div class="form-group">
                    <label for="address">Address:</label>
                    <input type="text" id="address" name="address" required>
                </div>
                <div class="form-group">
                    <label for="city">City:</label>
                    <input type="text" id="city" name="city" required>
                </div>
                <div class="form-group">
                    <label for="phoneNo">Phone No:</label>
                    <input type="text" id="phoneNo" name="phoneNo" required>
                </div>
                <div class="button-container">
                    <button type="button" class="confirm-btn" onclick="confirmOrderDetailsFormSubmit()">Confirm</button>
                </div>
            </form>
        </div>
    </div>

    <div class="popup-container" id="paymentOptionsPopup">
        <div class="popup">
            <span class="close-btn" onclick="closePaymentOptionsPopup()">&times;</span>
            <h2>Select Payment Method</h2>
            <div class="button-container">
                <button class="option-btn" onclick="payWithCash()">Cash on Delivery</button>
                <button class="option-btn" onclick="payWithCard()">Pay via Card</button>
            </div>
        </div>
    </div>

    <div id="payment-popup" class="payment-modal">
        <div class="payment-modal-content">
        </div>
    </div>

    <script>
        let currentProductId = null;
        let currentQuantity = 1;
        let productIdToDelete = null;
        let productQuantityToDelete = 1;

        document.addEventListener('DOMContentLoaded', () => {
            fetchProducts();

            document.getElementById('confirm-delete').addEventListener('click', () => {
                if (productIdToDelete) {
                    deleteProduct(productIdToDelete); 
                    document.getElementById('confirmation-popup').style.display = 'none';
                }
            });

            document.getElementById('cancel-delete').addEventListener('click', () => {
                document.getElementById('confirmation-popup').style.display = 'none';
            });
        });

        function fetchProducts() {
            fetch('fetchCart.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayProducts(data.data);
                    } else {
                        console.error('Failed to fetch products');
                    }
                })
                .catch(error => {
                    console.error('Error fetching products:', error);
                });
        }

        function displayProducts(products) {
            const cartItemsContainer = document.getElementById('cartItems');
            cartItemsContainer.innerHTML = '';

            if (products.length === 0) {
                cartItemsContainer.innerHTML = '<p class="empty-cart">No products available</p>';
                return;
            }

            products.forEach(product => {
                const productCard = document.createElement('div');
                productCard.className = 'card';

                const hasDiscount = product.discounted_price && parseFloat(product.discounted_price) > 0;

                productCard.innerHTML = `
                    <div class="imgBx">
                        <img src="${product.image_url}" alt="${product.name}">
                        <span class="close-btn" onclick="showConfirmationPopup(${product.id}, '${product.name}')">&times;</span>
                    </div>
                    <div class="content">
                        <div class="contentBx">
                            <h3>${product.name}</h3>
                            <p>${product.description}</p>
                            <div class="price-container">
                                <span class="original-price ${hasDiscount ? '' : 'no-discount'}">
                                    LKR. ${parseFloat(product.original_price).toFixed(2)}
                                </span>
                                ${hasDiscount ? `<span class="discounted-price">LKR. ${parseFloat(product.discounted_price).toFixed(2)}</span>` : ''}
                            </div>
                            <p class="quantity">Quantity: ${product.quantity}</p>
                            <button class="order-now" onclick="orderNow(${product.id})">Order Now</button>
                        </div>
                    </div>
                `;
                cartItemsContainer.appendChild(productCard);
            });
        }

        function orderNow(productId) {
            fetch('fetchProductDetails.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `product_id=${productId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const product = data.product;
                    orderNowPopup({
                        id: product.id,
                        image_url: product.image_url,
                        name: product.name,
                        original_price: product.discounted_price || product.original_price,
                        colors: product.colors || []
                    });
                } else {
                    showNotification("Error fetching product details");
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification("An error occurred. Please try again.");
            });
        }

        function orderNowPopup(product) {
            currentProductId = product.id;
            document.getElementById('popupProductImg').src = product.image_url;
            document.getElementById('popupProductName').textContent = product.name;

            const productPrice = parseFloat(product.original_price.replace(/,/g, ''));
            const deliveryFee = 400;
            const totalPrice = productPrice + deliveryFee;

            document.getElementById('popupOrderPrice').textContent =
                "LKR. " + productPrice.toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + 
                "  = LKR. " + totalPrice.toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

            document.getElementById('colorOptions').innerHTML = generateColorOptions(product.colors);

            document.getElementById('quantityValue').textContent = 1;

            document.getElementById('orderNowPopup').style.display = 'flex';
        }

        function closeOrderNowPopup() {
            document.getElementById('orderNowPopup').style.display = 'none';
            currentQuantity = 1;
        }

        function changeQuantity(amount) {
            currentQuantity = Math.max(1, currentQuantity + amount);
            document.getElementById('quantityValue').textContent = currentQuantity;
            updateOrderPrice(currentProductId, currentQuantity);
        }

        function updateOrderPrice(productId, quantity) {
            const productCards = document.querySelectorAll('.card');
            let productPrice = 0;

            productCards.forEach(card => {
                const addToCartBtn = card.querySelector('.add-to-cart');
                if (addToCartBtn && addToCartBtn.onclick.toString().includes(productId)) {
                    const priceElement = card.querySelector('.price-container .original-price') ||
                                    card.querySelector('.price-container .discounted-price') ||
                                    card.querySelector('.price-container .final-price');
                    if (priceElement) {
                        const priceText = priceElement.textContent.replace('LKR. ', '').replace(',', '');
                        productPrice = parseFloat(priceText);
                    }
                }
            });

            const deliveryFee = 400;
            const totalPrice = (productPrice * quantity) + deliveryFee;

            if (!isNaN(totalPrice)) {
                document.getElementById('popupOrderPrice').textContent = "LKR. " + totalPrice.toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            }
        }

        function generateColorOptions(colors) {
            if (!colors || colors.length === 0) {
                return '<span>N/A</span>';
            }
            return colors.map(color => `<div class="color-option" style="background-color: ${color};"></div>`).join('');
        }

        function showDeliveryDetails() {
            const deliveryDetailsDiv = document.getElementById('delivery-details-notification');
            const userId = <?php echo $_SESSION['user_id']; ?>; 

            fetch('fetchDeliveryDetails.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `user_id=${userId}`,
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const deliveryDetails = data.deliveryDetails;
                    deliveryDetailsDiv.setAttribute('data-delivery-id', deliveryDetails.id);
                    console.log("Delivery Details ID:", deliveryDetails.id); 
                    const html = `
                        <p>Name: ${deliveryDetails.full_name}</p>
                        <p>Location: ${deliveryDetails.address}, ${deliveryDetails.city}</p>
                        <p>Phone Number: ${deliveryDetails.phone_no}</p>
                    `;
                    deliveryDetailsDiv.innerHTML = html;
                    deliveryDetailsDiv.style.display = 'block'; 
                } else {
                    deliveryDetailsDiv.innerHTML = 'No delivery details found.';
                    deliveryDetailsDiv.style.display = 'block'; 
                }
            })
            .catch(error => {
                console.error('Error:', error);
                deliveryDetailsDiv.innerHTML = 'Error fetching delivery details.';
                deliveryDetailsDiv.style.display = 'block'; 
            });
        }

        function hideDeliveryDetails() {
            const deliveryDetailsDiv = document.getElementById('delivery-details-notification');
            deliveryDetailsDiv.style.display = 'none';
        }

        function showPaymentDetails() {
            document.getElementById('paymentOptionsPopup').style.display = 'flex';
        }

        function closePaymentOptionsPopup() {
            document.getElementById('paymentOptionsPopup').style.display = 'none';
        }

        let paymentNotificationTimeout = null;

        function showPaymentDetailsNotification() {
            const notification = document.getElementById('payment-details-notification');
            if (!notification) return;

            const userId = document.body.getAttribute('data-user-id');
            if (!userId) {
                notification.innerHTML = '<p>Please log in to view saved cards</p>';
                notification.style.display = 'block';
                return;
            }

            if (notification.style.display === 'block') {
                return;
            }

            clearTimeout(paymentNotificationTimeout);

            const formData = new FormData();
            formData.append('user_id', userId);

            fetch('fetchPaymentDetails.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                let html = '';
                if (data.success && data.cards && data.cards.length > 0) {
                    html = '<div class="notification-overlay"></div>';
                    html += '<div class="saved-cards-dropdown">';
                    html += '<select class="card-selector" onclick="event.stopPropagation()">';
                    html += '<option value="">Select a card</option>';
                    
                    data.cards.forEach(card => {
                        html += `<option value="${card.id}" data-number="${card.cardNumber}">
                            ${card.cardholderName} - ${card.displayNumber} (${card.expiryDate})
                        </option>`;
                    });
                    
                    html += '</select>';
                    html += '<button class="use-card-btn" onclick="event.stopPropagation(); useSelectedCard()">Use Selected</button>';
                    html += '</div>';
                } else {
                    html = '<p>No saved cards found</p>';
                }
                notification.innerHTML = html;
                notification.style.display = 'block';
            })
            .catch(error => {
                console.error('Error fetching cards:', error);
                notification.innerHTML = '<p>Error loading saved cards</p>';
                notification.style.display = 'block';
            });
        }

        function hidePaymentDetailsNotification() {
            paymentNotificationTimeout = setTimeout(() => {
                const notification = document.getElementById('payment-details-notification');
                if (notification) {
                    notification.style.display = 'none';
                }
            }, 5000);
        }

        function useSelectedCard() {
            const select = document.querySelector('.card-selector');
            if (!select || select.value === '') {
                showNotification('Please select a card first');
                return;
            }

            const selectedOption = select.options[select.selectedIndex];
            const cardNumber = selectedOption.getAttribute('data-number');
            const cardholderName = selectedOption.textContent.split(' - ')[0];

            document.getElementById('selectedCardId').value = select.value;

            const paymentDetailsSpan = document.querySelector('.payment-details span');
            if (paymentDetailsSpan) {
                paymentDetailsSpan.textContent = cardholderName;
            }

            const notification = document.getElementById('payment-details-notification');
            if (notification) {
                notification.style.display = 'none';
            }

            const paymentOptionsPopup = document.getElementById('paymentOptionsPopup');
            if (paymentOptionsPopup) {
                paymentOptionsPopup.style.display = 'none';
            }

            fetch('setSelectedCard.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `card_id=${select.value}`
            })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    showNotification('Error saving card selection');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('An error occurred while saving card selection');
            });
        }

        function payWithCash() {
            fetch('storePaymentMethod.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'payment_method=cash'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification('Payment method set to Cash on Delivery');
                    document.querySelector('.payment-details span').textContent = 'Cash on Delivery';
                    closePaymentOptionsPopup();
                } else {
                    showNotification('Error setting payment method');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('An error occurred. Please try again.');
            });
        }

        function payWithCard() {
            fetch('storePaymentMethod.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'payment_method=card'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const modal = document.getElementById('payment-popup');
                    fetch('payment_form.php')
                        .then(response => response.text())
                        .then(data => {
                            document.querySelector('.payment-modal-content').innerHTML = data;
                            modal.style.display = 'flex';
                            initPaymentForm();
                        })
                        .catch(error => {
                            console.error('Error loading payment form:', error);
                            showNotification('Error loading payment form');
                        });
                } else {
                    showNotification('Error setting payment method');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('An error occurred. Please try again.');
            });
        }

        function placeOrder(productId, quantity) {
            const isLoggedIn = document.body.getAttribute('data-logged-in') === 'true';
            
            if (!isLoggedIn) {
                showNotification("Please log in to place an order.");
                document.getElementById('loginPopup').style.display = 'flex';
                closeOrderNowPopup();
                return;
            }

            const paymentDetails = document.querySelector('.payment-details span').textContent;
            const isCardPayment = paymentDetails !== 'Cash on Delivery';
            const cardId = isCardPayment ? document.getElementById('selectedCardId').value : null;

            const deliveryDetailsId = document.querySelector('.delivery-details-notification')?.getAttribute('data-delivery-id');
            
            if (!deliveryDetailsId) {
                showNotification("Please confirm your delivery details first, If set already then just hover over it once.");
                return;
            }

            if (isCardPayment && !cardId) {
                showNotification("Please select a payment card first.");
                return;
            }
            
            const trackingNumber = generateTrackingNumber();
            const formData = new FormData();
            formData.append('order_now', '1');
            formData.append('product_id', productId);
            formData.append('quantity', quantity);
            formData.append('tracking_number', trackingNumber);
            formData.append('payment_method', isCardPayment ? 'card' : 'cash');
            if (isCardPayment) {
                formData.append('card_id', cardId);
            }
            formData.append('delivery_details_id', deliveryDetailsId);
            
            fetch('orderNow.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showOrderSuccessPopup(data.tracking_number);
                    closeOrderNowPopup();
                } else {
                    if (data.redirect === "login") {
                        showNotification(data.message);
                        document.getElementById('loginPopup').style.display = 'flex';
                        closeOrderNowPopup();
                    } else {
                        showNotification(data.message);
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification("An error occurred. Please try again.");
            });
        }

        function showNotification(message) {
            const existingNotification = document.querySelector('.notification');
            if (existingNotification) {
                existingNotification.remove();
            }

            const notification = document.createElement('div');
            notification.className = 'notification';
            notification.textContent = message;
            document.body.appendChild(notification);

            setTimeout(() => notification.classList.add('show'), 100);

            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => notification.remove(), 300);
            }, 5000);
        }

        function generateTrackingNumber() {
            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let tracking = '';
            for (let i = 0; i < 10; i++) {
                tracking += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            return tracking;
        }

        function showOrderSuccessPopup(trackingNumber) {
            const popup = document.createElement('div');
            popup.className = 'order-success-popup';
            popup.innerHTML = `
                <h3 style="color: #009688; margin-bottom: 20px;">Order Placed Successfully!</h3>
                <p>Your order has been confirmed. You can track your order using this tracking number:</p>
                <div class="tracking-number-container">
                    <div class="tracking-number" id="trackingNumber">${trackingNumber}</div>
                    <button class="copy-button" onclick="copyTrackingNumber()">Copy Tracking Number</button>
                    <div class="copy-success" id="copySuccess">Tracking number copied!</div>
                </div>
                <button class="option-btn" onclick="closeOrderSuccessPopup()">Close</button>
            `;
            document.body.appendChild(popup);
            popup.style.display = 'block';
        }

        function copyTrackingNumber() {
            const trackingNumber = document.getElementById('trackingNumber').textContent;
            navigator.clipboard.writeText(trackingNumber).then(() => {
                const copySuccess = document.getElementById('copySuccess');
                copySuccess.classList.add('show');
                setTimeout(() => {
                    copySuccess.classList.remove('show');
                }, 2000);
            });
        }

        function closeOrderSuccessPopup() {
            const popup = document.querySelector('.order-success-popup');
            if (popup) {
                popup.remove();
            }
        }

        function showConfirmationPopup(productId, productName) {
            const productCard = document.querySelector(`.card [onclick*="showConfirmationPopup(${productId}"]`).closest('.card');
            const quantityText = productCard.querySelector('.quantity').textContent;
            const currentQuantity = parseInt(quantityText.replace('Quantity: ', ''));
            
            const popup = document.getElementById('confirmation-popup');
            if (popup) {
                popup.style.display = 'flex';
                productIdToDelete = productId;

                document.getElementById('confirmation-message').innerText = 
                    `Are you sure you want to delete ${productName} from your cart?`;

                const quantityInput = document.getElementById('delete-quantity');
                quantityInput.max = currentQuantity;
                quantityInput.value = 1;
            }
        }

        function deleteProduct(productId, quantity) {
            fetch('cartDelete.php', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `id=${productId}&quantity=${quantity}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Product deleted successfully');
                    location.reload();
                } else {
                    console.error('Error deleting product:', data.message);
                }
            })
            .catch(error => {
                console.error('Error deleting product:', error);
            });
        }
    </script>
</body>
</html> 