<?php
session_start();
require_once 'conndb.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if (!isset($_SESSION['user_id'])) {
    $response['message'] = 'Please log in to place an order';
    $response['redirect'] = 'login';
    echo json_encode($response);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_now'])) {
    $user_id = $_SESSION['user_id'];
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    $tracking_number = $_POST['tracking_number'];
    $payment_method = $_POST['payment_method'];
    $card_id = isset($_POST['card_id']) ? intval($_POST['card_id']) : null;
    $delivery_details_id = intval($_POST['delivery_details_id']);

    $stmt = $conn->prepare("SELECT original_price, discounted_price FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    
    if (!$product) {
        $response['message'] = 'Product not found';
        echo json_encode($response);
        exit();
    }

    $product_price = $product['discounted_price'] ?? $product['original_price'];
    $delivery_fee = 400; 
    $total_amount = ($product_price * $quantity) + $delivery_fee;

    error_log("Tracking number before insert: " . $tracking_number);

    $stmt = $conn->prepare("INSERT INTO orders (user_id, product_id, quantity, payment_method, card_id, delivery_details_id, tracking_number, total_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiisiisd", $user_id, $product_id, $quantity, $payment_method, $card_id, $delivery_details_id, $tracking_number, $total_amount);

    if ($stmt->execute()) {
        $order_id = $conn->insert_id;

        error_log("Order ID after insert: " . $order_id);
        
        $tracking_stmt = $conn->prepare("INSERT INTO order_tracking (order_id, tracking_number, status) VALUES (?, ?, 'Order Placed')");
        $tracking_stmt->bind_param("is", $order_id, $tracking_number);
        
        if ($tracking_stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Order placed successfully!';
            $response['tracking_number'] = $tracking_number;
        } else {
            $response['success'] = false;
            $response['message'] = 'Order placed but tracking information could not be saved.';
            error_log("Tracking information error: " . $tracking_stmt->error);
        }
        $tracking_stmt->close();
    } else {
        $response['message'] = 'Failed to place order. Please try again.';
        error_log("Order placement error: " . $stmt->error);
    }

    $stmt->close();
} else {
    $response['message'] = 'Invalid request';
}

echo json_encode($response);
?>