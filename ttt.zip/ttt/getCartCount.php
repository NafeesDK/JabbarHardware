<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'conndb.php';

ini_set("log_errors", 1);
ini_set("error_log", "C:\\xampp\\htdocs\\ttt\\php-error.log");
error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$response = ['success' => false, 'count' => 0];

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    try {
        $stmt = $conn->prepare("SELECT SUM(quantity) AS total FROM cart WHERE user_id = ?");
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param("i", $user_id);
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }
        
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            $count = $row['total'] ? intval($row['total']) : 0;
            $response = ['success' => true, 'count' => $count];
        }
        
        $stmt->close();
    } catch (Exception $e) {
        $response['success'] = false;
        $response['message'] = "Error fetching cart count: " . $e->getMessage();
        error_log("Cart count error for user $user_id: " . $e->getMessage());
    }
} else {
    $response['message'] = "User not logged in";
}

error_log("getCartCount response: " . json_encode($response));
echo json_encode($response);
exit();
?>