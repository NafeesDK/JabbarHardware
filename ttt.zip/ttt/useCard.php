<?php
session_start();
require_once 'conndb.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

if (!isset($_POST['card_id']) || empty($_POST['card_id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid card ID']);
    exit;
}

$cardId = intval($_POST['card_id']);
$userId = $_SESSION['user_id'];

// Get full card details
$stmt = $conn->prepare("SELECT cardholderName, cardNumber, expiryDate 
                       FROM carddetails 
                       WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $cardId, $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $card = $result->fetch_assoc();
    $_SESSION['payment_method'] = 'card';
    $_SESSION['card_details'] = $card;
    
    echo json_encode([
        'success' => true,
        'cardNumber' => $card['cardNumber'],
        'message' => 'Card selected'
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Card not found']);
}

$stmt->close();
?>