<?php
session_start();
require_once 'conndb.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['tracking'])) {
    header("Location: track_order.php");
    exit();
}

$tracking_number = $_GET['tracking'];
$user_id = $_SESSION['user_id'];

$tracking_query = "SELECT ot.*, o.*, p.name as product_name, p.image_url 
                  FROM order_tracking ot 
                  JOIN orders o ON ot.order_id = o.id 
                  JOIN products p ON o.product_id = p.id 
                  WHERE ot.tracking_number = ? AND o.user_id = ?";
$stmt = $conn->prepare($tracking_query);
$stmt->bind_param("si", $tracking_number, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$order_data = $result->fetch_assoc();

if (!$order_data) {
    header("Location: track_order.php");
    exit();
}

$order_id = $order_data['id']; 

$order_details_query = "
    SELECT o.*, p.name AS product_name, p.image_url, p.original_price, p.discounted_price, d.address, d.city, o.total_amount 
    FROM orders o 
    JOIN products p ON o.product_id = p.id 
    JOIN `c.l.details` d ON o.delivery_details_id = d.id 
    WHERE o.id = ?";
$order_details_stmt = $conn->prepare($order_details_query);
$order_details_stmt->bind_param("i", $order_id);
$order_details_stmt->execute();
$order_details_result = $order_details_stmt->get_result();
$order_details = $order_details_result->fetch_assoc();

$discounted_price = $order_details['discounted_price']; 
$original_price = $order_details['original_price']; 
$quantity = $order_details['quantity']; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Tracking - Jabbar Hardware Stores</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            overflow-x: hidden !important;
            margin: 0;
            height: 90vh;
            overflow-y: scroll;
            scroll-snap-type: y mandatory;
            background-image: url('logoo.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #e0e0e0;
        }

        #page1 {
            background-color: rgba(0, 0, 0, 0.80);
            height: 100vh;
        }

        .header {
            background-color: rgba(0, 0, 0, 0.85);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .header h1 {
            color: #009688;
            margin: 0;
        }

        .menu-icon {
            font-size: 1.9rem;
            cursor: pointer;
            color: #e0e0e0;text-decoration: none; 
            transition: color 0.3s ease; 
        }

        .menu-icon:hover {
            color: #009688; 
        }

        .tracking-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .progress-container {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            margin: 2rem 0;
            background: rgba(0, 0, 0, 0.85);
            padding: 2rem;
            border-radius: 15px;
            border: 1px solid rgba(0, 150, 136, 0.3);
            box-shadow: 0 5px 30px rgba(0, 150, 136, 0.2);
        }

        .progress-step {
            display: flex;
            align-items: center;
            gap: 1rem;
            color: #e0e0e0;
        }

        .progress-step i {
            color: #009688;
            font-size: 1.9rem;
        }

        .progress-step div:first-child {
            color: #fff;
            font-weight: 500;
        }

        .progress-step div:last-child {
            color: #888;
            font-size: 0.9rem;
        }

        .order-summary {
            background: rgba(0, 0, 0, 0.85);
            padding: 2rem;
            border-radius: 15px;
            margin-top: 2rem;
            border: 1px solid rgba(0, 150, 136, 0.3);
            box-shadow: 0 5px 30px rgba(0, 150, 136, 0.2);
        }

        .order-summary h3 {
            color: #009688;
            margin-bottom: 1rem;
        }

        .order-summary p {
            margin: 0.5rem 0;
            color: #e0e0e0;
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }

        .action-button {
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .view-details {
            background: #009688;
            color: white;
        }

        .view-details:hover {
            background: #00796b;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 121, 107, 0.3);
        }

        .track-another {
            background: transparent;
            border: 2px solid #009688;
            color: #e0e0e0;
            position: relative;
            overflow: hidden;
            z-index: 2;
        }

        .track-another:hover {
            color: white;
        }

        .cover {
        background: #009688;
        height: 100%;
        width: 0%;
        border-radius: 25px;
        position: absolute;
        left: 0;
        bottom: 0;
        z-index: -1;
        transition: width 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        }

        .track-another:hover .cover {
            width: 100%;
        }

        .track-another:hover::before {
            width: 100%;
        }

        .progress-step i.far.fa-check-circle {
            color: #009688;
        }

        #orderDetailsModal {
            display: none; 
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            display: flex;
            background: rgba(0, 0, 0, 0.85);
            padding: 2rem;
            border-radius: 15px;
            max-width: 600px; 
            width: 90%; 
            box-shadow: 0 5px 30px rgba(0, 150, 136, 0.2);
            position: relative;
        }

        .imgBx {
            width: 200px; 
            height: 300px; 
            overflow: hidden; 
            border-radius: 10px; 
            margin-right: 20px; 
            box-shadow: -3px 5px 30px rgb(0, 150, 135);
        }

        .imgBx img {
            width: 100%; 
            height: 100%; 
            object-fit: cover; 
            display: block; 
        }

        .modal-details {
            display: flex;
            flex-direction: column; 
            justify-content: center; 
        }

        .close-btn {
            position: absolute;
            right: 15px;
            top: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #ff6b6b;
            transition: transform 0.3s ease;
        }

        .close-btn:hover {
            transform: rotate(90deg);
            color: #ff4f4f;
        }

        .modal-details-content {
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
        }

        .product-name {
            color: #009688;
            margin-top: -60px;
            padding: 20px 0 15px 0;
            font-size: 1.6rem;
        }

        .detail {
            color: white;
            margin: 4px 0;
        }
        .h-line {
            border: none;
            height: 2px;
            background-color: #009688;
            margin: 10px 0;
        }
    </style>
</head>
    <body>
    <div id="page1">
        <div class="header">
            <a href="ttt.php" class="menu-icon">&#8592;</a>
            <h1>Track Order</h1>
        </div>

        <div class="tracking-container">
            <div class="progress-container">
                <?php
                $statuses = [
                    'Order placed' => "Order received on " . date("F j, Y, g:i a", strtotime($order_data['created_at'])),
                    'Pickup' => in_array($order_data['status'], ['Pickup', 'Out for delivery', 'Delivered']) ? 'Your order is packed, waiting for pickup' : 'Pending',
                    'Out for delivery' => in_array($order_data['status'], ['Out for delivery', 'Delivered']) ? 'Picked up carefully and on the way to your home' : 'Pending',
                    'Delivered' => $order_data['status'] === 'Delivered' ? 'Thank you for choosing Jabbar Hardware Stores, please give us a feedback' : 'Pending'
                ];

                foreach ($statuses as $status => $date) {
                    $isCompleted = $date !== 'Pending';
                    echo "<div class='progress-step'>";
                    echo "<i class='" . ($isCompleted ? "far fa-check-circle" : "far fa-circle-xmark") . "'></i>";
                    echo "<div>";
                    echo "<div>$status</div>";
                    echo "<div>" . ($isCompleted ? $date : 'Pending') . "</div>";
                    echo "</div>";
                    echo "</div>";
                }
                ?>
            </div>

            <div class="order-summary">
                <h3>Order Summary</h3>
                <p>Order No: <?php echo $order_data['tracking_number']; ?></p>
                <p>Date: <?php echo $order_data['created_at']; ?></p>
                <p>Order total: LKR <?php echo number_format($order_data['total_amount'], 2); ?></p>
                <p>Payment method: <?php echo ucfirst($order_data['payment_method']); ?></p>
            </div>

            <div class="action-buttons">
                <button class="action-button view-details" onclick="showOrderDetails()">View order detail</button>
                <button class="action-button track-another" onclick="window.location.href='track_order.php'">Track another order <span class="cover"></span></button>
            </div>
        </div>

        <div id="orderDetailsModal">
            <div class="modal-content">
                <span class="close-btn" onclick="closeModal()">&times;</span>
                <div class="imgBx">
                    <img src="" alt="" id="modalImage">
                </div>
                <div class="modal-details" id="modalDetails">
                </div>
            </div>
        </div>
    </div>
    <script>
        function showOrderDetails() {
            const orderDetails = <?php echo json_encode($order_details); ?>; 

            document.getElementById('modalImage').src = orderDetails.image_url;
            document.getElementById('modalImage').alt = orderDetails.product_name;

            const discountedPrice = parseFloat(orderDetails.discounted_price);
            const originalPrice = parseFloat(orderDetails.original_price);
            const quantity = parseInt(orderDetails.quantity, 10);

            const pricePerItem = !isNaN(discountedPrice) && discountedPrice !== null 
                ? discountedPrice 
                : (!isNaN(originalPrice) && originalPrice !== null 
                    ? originalPrice 
                    : 0);

            const totalPrice = parseFloat(orderDetails.total_amount);


            const modalDetails = `
                <div class="modal-details-content">
                    <h3 class="product-name">${orderDetails.product_name}</h3>
                    <p class="detail">Quantity: ${quantity}</p>
                    <p class="detail">Price per item: LKR ${pricePerItem.toFixed(2)}</p>
                    <p class="detail">Total price + delivery fee: LKR ${totalPrice.toFixed(2)}</p>
                    <hr class="h-line">
                    <p class="detail">Order No: ${orderDetails.id}</p>
                    <p class="detail">Ordered Date: ${orderDetails.created_at}</p>
                    <p class="detail">Delivery Details: ${orderDetails.address}, ${orderDetails.city}</p>
                </div>
            `;

            document.getElementById('modalDetails').innerHTML = modalDetails;
            document.getElementById('orderDetailsModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('orderDetailsModal').style.display = 'none';
        }
    </script>
</body>
</html>