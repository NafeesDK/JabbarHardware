-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2025 at 11:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jabbar_stores`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL,
  `session_timeout` int(11) DEFAULT 300
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `email`, `full_name`, `profile_image`, `role`, `created_at`, `last_login`, `session_timeout`) VALUES
(2, 'Hajith', '$2y$10$KCwwnAU/Do2w9x7wZk2Z3.iPezI69qeJX8j8K.cXuDJwSLLTaxGj6', 'jabbar@gmail.com', 'Hajith Nafees', 'image3.webp', 'super_admin', '2025-05-18 18:46:15', NULL, 300),
(4, 'Steve', '$2y$10$FlsVZE2iakXsiCS9ehs3Re/78QzQaAvMUcjOvy3xSST/5BY3sT.H.', 'steve.r@gmail.com', 'Steve Rogers', '682d81ca287c7.webp', 'godown_admin', '2025-05-21 07:33:30', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `c.l.details`
--

CREATE TABLE `c.l.details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `phone_no` varchar(15) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `c.l.details`
--

INSERT INTO `c.l.details` (`id`, `user_id`, `full_name`, `address`, `city`, `phone_no`, `created_at`) VALUES
(1, 12, 'tony stank', '123,somewhere', 'Kalmunai', '0710946094', '2025-04-21 12:05:28'),
(6, 1, 'John Smith', '123 Main St', 'Colombo', '0771234567', '2025-04-01 04:30:00'),
(7, 2, 'Sarah Johnson', '456 Park Ave', 'Kandy', '0762345678', '2025-04-05 05:50:00'),
(8, 11, 'Mike Wilson', '789 Lake Rd', 'Galle', '0753456789', '2025-04-10 09:15:00'),
(9, 12, 'Emma Davis', '321 Hill St', 'Jaffna', '0744567890', '2025-04-15 04:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `carddetails`
--

CREATE TABLE `carddetails` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cardholderName` varchar(255) NOT NULL,
  `cardNumber` varchar(255) NOT NULL,
  `expiryDate` varchar(5) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carddetails`
--

INSERT INTO `carddetails` (`id`, `user_id`, `cardholderName`, `cardNumber`, `expiryDate`, `created_at`) VALUES
(1, 12, 'tony stank', '************6981', '06/31', '2025-04-23 17:03:33'),
(10, 12, 'Ginevra Khouri', '************2308', '10/27', '2025-04-30 14:19:18'),
(11, 12, 'Alicia Noguchi', '***********8615', '10/27', '2025-05-20 16:58:02'),
(12, 1, 'John Smith', '************1234', '12/25', '2025-04-01 04:30:00'),
(13, 2, 'Sarah Johnson', '************5678', '09/26', '2025-04-05 05:50:00'),
(14, 11, 'Mike Wilson', '************9012', '03/27', '2025-04-10 09:15:00'),
(15, 12, 'Emma Davis', '************3456', '06/26', '2025-04-15 04:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`, `created_at`) VALUES
(131, 12, 3, 1, '2025-05-02 13:35:45'),
(132, 12, 4, 2, '2025-05-02 15:17:21'),
(134, 12, 12, 2, '2025-05-20 16:59:04');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `status` enum('pending','read','replied') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `message`, `status`, `created_at`) VALUES
(1, 'Hajith', 'Onprogress@gmail.com', 'The page is really AWESOME', 'This page is created by Hajith Nafees from scratch, as my assignment in WDD. This took me more than the deadline still I completed it as perfect as I wanted.', 'replied', '2025-05-21 00:26:44'),
(2, 'Tony stark', 'tony.stark@example.com', 'Issue with product delivery', 'My order placed last week has not arrived yet. Can you please provide a tracking update?', 'pending', '2025-05-16 02:11:15'),
(3, 'John cena', 'cena.j@test.net', 'Website suggestions', 'The website is great, but it would be helpful to have a search filter for product categories.', 'read', '2025-05-17 02:11:15'),
(4, 'Charlie chaplin', 'charlie.C@mailservice.org', 'Question about warranty', 'What is the warranty period for the power drill?', 'replied', '2025-05-18 02:11:15'),
(5, 'Steve Rogers', 'Steve.R@amazon.com', 'Excellent customer service', 'I had an issue with a return, and your support team resolved it quickly and professionally. Thank you!', 'read', '2025-05-19 02:11:15'),
(6, 'Ethan Hunt', 'ethan.h@imf.gov', 'Regarding bulk order discounts', 'I am interested in placing a large order for hammers. Do you offer bulk discounts?', 'pending', '2025-05-20 02:11:15'),
(7, 'Peter Parker', 'P.Parker@spymail.co', 'Problem with payment gateway', 'I am unable to complete my purchase. The payment gateway seems to be having issues.', 'pending', '2025-05-20 04:11:15'),
(8, 'Clint smith', 'clint.s@federation.org', 'Product review - adjustable wrench', 'Just received the adjustable wrench. It works perfectly and feels very durable. Great value for money.', 'read', '2025-05-20 06:11:15'),
(9, 'Bruce Banner', 'B.banner@popstar.com', 'Feedback on new stocks section', 'I like the new stocks section, makes it easy to see recently added items.', 'replied', '2025-05-20 14:11:15'),
(10, 'Ivan Drago', 'ivan.d@soviet.ru', 'Request for specific tool', 'Do you stock heavy-duty chainsaws suitable for professional logging?', 'pending', '2025-05-20 18:11:15'),
(11, 'Salman Khan', 'Salman.k@web.net', 'Suggestion for shipping options', 'It would be great if you offered express shipping for urgent orders.', 'read', '2025-05-20 22:11:15');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_method` enum('card','cash') NOT NULL,
  `card_id` int(11) DEFAULT NULL,
  `delivery_details_id` int(11) NOT NULL,
  `tracking_number` varchar(20) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_id`, `quantity`, `created_at`, `payment_method`, `card_id`, `delivery_details_id`, `tracking_number`, `total_amount`) VALUES
(18, 12, 2, 1, '2025-05-18 17:23:06', 'card', 10, 1, '1P2BIFD737', 2250.00),
(19, 12, 10, 1, '2025-05-18 17:23:40', 'cash', NULL, 1, 'TIUEK6VPAC', 24700.00),
(20, 12, 17, 1, '2025-05-18 17:23:51', 'card', 1, 1, 'HRZV1QXUQY', 6400.00),
(21, 12, 13, 1, '2025-05-20 16:58:32', 'card', 11, 1, '07IV2BT0ZY', 1300.00),
(82, 1, 1, 2, '2025-05-01 04:30:00', 'card', 1, 1, 'ABCD1234EF', 2200.00),
(83, 2, 2, 1, '2025-05-02 05:50:00', 'cash', NULL, 6, 'GHIJ5678KL', 1850.00),
(84, 11, 3, 3, '2025-05-03 09:15:00', 'card', 12, 7, 'MNOP9012QR', 20790.00),
(85, 12, 4, 1, '2025-05-04 04:00:00', 'cash', NULL, 8, 'STUV3456WX', 16800.00),
(86, 1, 5, 2, '2025-05-05 04:45:00', 'card', 13, 9, 'YZAB7890CD', 3700.00),
(87, 2, 6, 1, '2025-05-06 06:00:00', 'cash', NULL, 1, 'EFGH1234IJ', 240.00),
(88, 11, 7, 2, '2025-05-07 09:30:00', 'card', 12, 6, 'KLMN5678OP', 2000.00),
(89, 12, 8, 1, '2025-05-08 04:15:00', 'cash', NULL, 6, 'QRST9012UV', 2200.00),
(90, 1, 9, 3, '2025-05-09 05:00:00', 'card', 15, 1, 'WXYZ3456AB', 8100.00),
(91, 2, 10, 1, '2025-05-10 06:15:00', 'cash', NULL, 7, 'CDEF7890GH', 24300.00),
(92, 11, 11, 2, '2025-05-11 09:45:00', 'card', 12, 8, 'IJKL1234MN', 8220.00),
(93, 12, 12, 1, '2025-05-12 03:30:00', 'cash', NULL, 8, 'OPQR5678ST', 7550.00),
(94, 1, 13, 3, '2025-05-13 05:15:00', 'card', 1, 6, 'UVWX9012YZ', 2700.00),
(95, 2, 14, 2, '2025-05-14 05:30:00', 'cash', NULL, 9, 'ABCD3456EF', 800.00),
(96, 11, 15, 1, '2025-05-15 10:00:00', 'card', 15, 9, 'GHIJ7890KL', 8500.00),
(97, 12, 16, 2, '2025-05-16 03:45:00', 'cash', NULL, 9, 'MNOP1234QR', 4400.00),
(98, 1, 17, 1, '2025-05-17 04:30:00', 'card', 1, 1, 'STUV5678WX', 6000.00),
(99, 2, 18, 2, '2025-05-18 05:45:00', 'cash', NULL, 8, 'YZAB9012CD', 5600.00),
(100, 11, 19, 3, '2025-05-19 10:15:00', 'card', 12, 7, 'EFGH3456IJ', 5400.00),
(101, 12, 20, 1, '2025-05-20 04:00:00', 'cash', NULL, 6, 'KLMN7890OP', 2750.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_tracking`
--

CREATE TABLE `order_tracking` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `tracking_number` varchar(20) NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_tracking`
--

INSERT INTO `order_tracking` (`id`, `order_id`, `tracking_number`, `status`, `created_at`, `updated_at`) VALUES
(1, 18, '1P2BIFD737', 'Order Placed', '2025-05-18 17:23:06', '2025-05-18 17:23:06'),
(2, 19, 'TIUEK6VPAC', 'Order Placed', '2025-05-18 17:23:40', '2025-05-18 17:23:40'),
(3, 20, 'HRZV1QXUQY', 'Order Placed', '2025-05-18 17:23:51', '2025-05-18 17:23:51'),
(4, 21, '07IV2BT0ZY', 'Order Placed', '2025-05-20 16:58:32', '2025-05-21 08:47:01'),
(25, 82, 'ABCD1234EF', 'Order Placed', '2025-05-01 04:30:00', '2025-05-21 09:05:01'),
(26, 83, 'GHIJ5678KL', 'Order Placed', '2025-05-02 05:50:00', '2025-05-02 05:50:00'),
(27, 84, 'MNOP9012QR', 'Order Placed', '2025-05-03 09:15:00', '2025-05-03 09:15:00'),
(28, 85, 'STUV3456WX', 'Delivered', '2025-05-04 04:00:00', '2025-05-21 09:09:42'),
(29, 86, 'YZAB7890CD', 'Order Placed', '2025-05-05 04:45:00', '2025-05-05 04:45:00'),
(30, 87, 'EFGH1234IJ', 'Order Placed', '2025-05-06 06:00:00', '2025-05-06 06:00:00'),
(31, 88, 'KLMN5678OP', 'Order Placed', '2025-05-07 09:30:00', '2025-05-07 09:30:00'),
(32, 89, 'QRST9012UV', 'Order Placed', '2025-05-08 04:15:00', '2025-05-08 04:15:00'),
(33, 90, 'WXYZ3456AB', 'Order Placed', '2025-05-09 05:00:00', '2025-05-09 05:00:00'),
(34, 91, 'CDEF7890GH', 'Order Placed', '2025-05-10 06:15:00', '2025-05-10 06:15:00'),
(35, 92, 'IJKL1234MN', 'Order Placed', '2025-05-11 09:45:00', '2025-05-11 09:45:00'),
(36, 93, 'OPQR5678ST', 'Order Placed', '2025-05-12 03:30:00', '2025-05-12 03:30:00'),
(37, 94, 'UVWX9012YZ', 'Order Placed', '2025-05-13 05:15:00', '2025-05-13 05:15:00'),
(38, 95, 'ABCD3456EF', 'Order Placed', '2025-05-14 05:30:00', '2025-05-14 05:30:00'),
(39, 96, 'GHIJ7890KL', 'Order Placed', '2025-05-15 10:00:00', '2025-05-15 10:00:00'),
(40, 97, 'MNOP1234QR', 'Order Placed', '2025-05-16 03:45:00', '2025-05-16 03:45:00'),
(41, 98, 'STUV5678WX', 'Order Placed', '2025-05-17 04:30:00', '2025-05-17 04:30:00'),
(42, 99, 'YZAB9012CD', 'Order Placed', '2025-05-18 05:45:00', '2025-05-18 05:45:00'),
(43, 100, 'EFGH3456IJ', 'Order Placed', '2025-05-19 10:15:00', '2025-05-19 10:15:00'),
(44, 101, 'KLMN7890OP', 'Order Placed', '2025-05-20 04:00:00', '2025-05-20 04:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `original_price` decimal(10,2) NOT NULL,
  `discounted_price` decimal(10,2) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `category` enum('offer','regular') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `stock_quantity` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `original_price`, `discounted_price`, `image_url`, `category`, `created_at`, `stock_quantity`) VALUES
(1, 'Hammer', 'Durable claw hammer for construction tasks.', 1600.00, 1100.00, 'https://th.bing.com/th/id/R.81c223274dcbc4f8ae12dbb638470753?rik=vVlOjUkCQJl0%2bw&pid=ImgRaw&r=0', 'offer', '2025-03-07 15:07:36', 8),
(2, 'Screwdriver Set', 'Multi-head screwdriver set for all needs.', 2040.00, 1850.00, 'https://images.thdstatic.com/productImages/23307023-290f-4e58-8870-776f0de0cb6f/svn/stanley-screwdriver-sets-stht60084-64_600.jpg', 'offer', '2025-03-07 15:07:36', 16),
(3, 'Adjustable Wrench', 'Versatile wrench for various bolt sizes.', 7650.00, 6930.00, 'https://th.bing.com/th/id/R.9e1c59a72066465a76e15f38ee128979?rik=cxxjcChywt94Gg&pid=ImgRaw&r=0', 'offer', '2025-03-08 14:00:24', 17),
(4, 'Cordless Drill', 'Rechargeable drill for DIY project.', 17200.00, 16800.00, 'https://th.bing.com/th/id/OIP.3MyvjEm26TRSjVU_1wKVLAHaGW?rs=1&pid=ImgDetMain', 'offer', '2025-03-08 14:01:39', 2),
(5, 'Tape Measure', '25-foot tape measure with lock mechanism.', 2200.00, 1850.00, 'https://th.bing.com/th/id/OIP.MOKs7gu1oKxREx5qTC3t4wHaHa?rs=1&pid=ImgDetMain', 'offer', '2025-03-08 14:02:12', 1),
(6, 'Utility Knife', 'Sharp retractable blade for cutting tasks.', 280.00, 240.00, 'https://th.bing.com/th/id/OIP.dE6XH4gHvp3-1psIwPuKnAHaHa?rs=1&pid=ImgDetMain', 'offer', '2025-03-08 14:02:26', 0),
(7, 'Pliers', 'Slip-joint pliers for gripping and bending.', 1200.00, 1000.00, 'https://th.bing.com/th/id/OIP.HcADGlWdo7tWojC69-7aPAHaHa?rs=1&pid=ImgDetMain', 'offer', '2025-03-08 14:02:42', 15),
(8, 'Level', '24-inch level for accurate measurements.', 2640.00, 2200.00, 'https://th.bing.com/th/id/OIP.cOfZYD2-pUS2TU0wYD8-AQHaHa?rs=1&pid=ImgDetMain', 'offer', '2025-03-08 14:03:03', 20),
(9, 'Socket Set', '40-piece socket set for automotive repairs.', 3200.00, 2700.00, 'https://i5.walmartimages.com/asr/a982272a-e59a-4ff5-a44f-b2f445779c96_2.670322bf5e316141dd60e9191c97e7a6.jpeg?odnWidth=1000&odnHeight=1000&odnBg=ffffff', 'offer', '2025-03-08 14:03:35', 25),
(10, 'Power Saw', 'Electric saw for cutting wood and metal.', 28400.00, 24300.00, 'https://th.bing.com/th/id/OIP.3bR9fpj3qKN8nNCJ8gGXRwHaHa?w=660&h=660&rs=1&pid=ImgDetMain', 'offer', '2025-03-08 14:04:06', 4),
(11, 'Chisel Set', '6-piece chisel set for woodworking.', 4110.00, NULL, 'https://th.bing.com/th/id/R.7d600ef4f505db9386a38a881d602cac?rik=N6MDIgqCKCpXlA&riu=http%3a%2f%2fecx.images-amazon.com%2fimages%2fI%2f418kjbu6oUL.jpg&ehk=iDVg33FNdiXClUebsQ2Z%2ffysL5lzlS%2f7tJLVeB0qRyA%3d&risl=&pid=ImgRaw&r=0', 'regular', '2025-03-08 14:04:36', 12),
(12, 'Tool Box', 'Portable toolbox with compartments.', 7550.00, NULL, 'https://th.bing.com/th/id/OIP.OUdtNBnUW3BugX7iPzmiXgHaHa?w=800&h=800&rs=1&pid=ImgDetMain', 'regular', '2025-03-08 14:04:52', 11),
(13, 'Safety Glasses', 'Protective eyewear for construction work.', 900.00, NULL, 'https://th.bing.com/th/id/OIP.MjiNP6Kb4-gT5v-5bOQsqQHaHa?rs=1&pid=ImgDetMain', 'regular', '2025-03-08 14:05:06', 20),
(14, 'Work Gloves', 'Heavy-duty gloves for hand protection.', 400.00, NULL, 'https://www.b-id.co.uk/media/facebook/4c5f7ac3-d6fb-11ee-bdd6-fa163e5e3817.jpg', 'regular', '2025-03-08 14:05:18', 21),
(15, 'Sledgehammer', 'Heavy-duty hammer for demolition tasks.', 8500.00, NULL, 'https://www.brights.co.za/cdn-cgi/image/width=600,quality=60,format=auto,onerror=redirect/wp-content/uploads/2020/11/15080_HAMMER-SLEDGE-UNBREAKABLE-6.3KG.jpg', 'regular', '2025-03-08 14:08:55', 14),
(16, 'Circular Saw', 'High-power saw for precise cutting.', 2200.00, NULL, 'https://th.bing.com/th/id/OIP.3tg9Dw9MYb1M3R1fA0BetQHaHa?rs=1&pid=ImgDetMain', 'regular', '2025-03-08 14:09:04', 3),
(17, 'Allen Wrench Set', 'Hex key set for assembling furniture.', 6000.00, NULL, 'https://th.bing.com/th/id/OIP.qdIoY_GNQ7O6Al6OpPfldgHaHa?w=480&h=480&rs=1&pid=ImgDetMain', 'regular', '2025-03-08 14:09:14', 12),
(18, 'Stud Finder', 'Wall scanner for locating studs and wires.', 2800.00, NULL, 'https://th.bing.com/th/id/OIP.Q2lRmByCKfP5rUaWFohtlQHaHa?rs=1&pid=ImgDetMain', 'regular', '2025-03-08 14:09:42', 20),
(19, 'Paint Roller', 'Roller with ergonomic handle for painting.', 1800.00, NULL, 'https://www.toolstop.com.my/wp-content/uploads/2021/03/09193.jpg', 'regular', '2025-03-08 14:09:52', 30),
(20, 'Drill Bit Set', '20-piece set for drilling various materials.', 2750.00, NULL, 'https://www.stanleytools.ie/EMEA/PRODUCT/IMAGES/HIRES/STA88550/STA88550_P2.jpg?resize=530x530', 'regular', '2025-03-08 14:10:01', 10);

-- --------------------------------------------------------

--
-- Table structure for table `product_suppliers`
--

CREATE TABLE `product_suppliers` (
  `product_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_suppliers`
--

INSERT INTO `product_suppliers` (`product_id`, `supplier_id`, `created_at`) VALUES
(1, 1, '2025-05-19 22:22:56'),
(2, 1, '2025-05-19 22:22:56'),
(3, 1, '2025-05-19 22:22:56'),
(4, 2, '2025-05-19 22:22:56'),
(5, 2, '2025-05-19 22:22:56'),
(6, 2, '2025-05-19 22:22:56'),
(7, 3, '2025-05-19 22:22:56'),
(8, 3, '2025-05-19 22:22:56'),
(9, 1, '2025-05-19 22:22:56'),
(10, 3, '2025-05-19 22:22:56'),
(11, 1, '2025-05-19 22:22:56'),
(12, 2, '2025-05-19 22:22:56'),
(13, 3, '2025-05-19 22:22:56'),
(14, 3, '2025-05-19 22:22:56'),
(15, 2, '2025-05-19 22:22:56'),
(16, 1, '2025-05-19 22:22:56'),
(16, 7, '2025-05-20 16:33:03'),
(17, 2, '2025-05-19 22:22:56'),
(18, 2, '2025-05-19 22:22:56'),
(19, 3, '2025-05-19 22:22:56'),
(20, 3, '2025-05-19 22:22:56');

-- --------------------------------------------------------

--
-- Table structure for table `stock_history`
--

CREATE TABLE `stock_history` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `previous_quantity` int(11) NOT NULL,
  `new_quantity` int(11) NOT NULL,
  `change_type` enum('restock','sale','adjustment') NOT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_history`
--

INSERT INTO `stock_history` (`id`, `product_id`, `previous_quantity`, `new_quantity`, `change_type`, `changed_at`) VALUES
(1, 1, 10, 8, 'sale', '2025-05-14 17:34:28'),
(2, 1, 8, 12, 'restock', '2025-05-15 17:34:28'),
(3, 1, 12, 9, 'sale', '2025-05-16 17:34:28'),
(4, 1, 9, 7, 'sale', '2025-05-17 17:34:28'),
(5, 1, 7, 10, 'restock', '2025-05-18 17:34:28'),
(6, 1, 10, 8, 'sale', '2025-05-19 17:34:28'),
(7, 2, 21, 18, 'sale', '2025-05-14 17:34:28'),
(8, 2, 18, 20, 'restock', '2025-05-15 17:34:28'),
(9, 2, 20, 17, 'sale', '2025-05-16 17:34:28'),
(10, 2, 17, 15, 'sale', '2025-05-17 17:34:28'),
(11, 2, 15, 18, 'restock', '2025-05-18 17:34:28'),
(12, 2, 18, 16, 'sale', '2025-05-19 17:34:28'),
(13, 3, 17, 15, 'sale', '2025-05-14 17:34:28'),
(14, 3, 15, 20, 'restock', '2025-05-15 17:34:28'),
(15, 3, 20, 18, 'sale', '2025-05-16 17:34:28'),
(16, 3, 18, 16, 'sale', '2025-05-17 17:34:28'),
(17, 3, 16, 19, 'restock', '2025-05-18 17:34:28'),
(18, 3, 19, 17, 'sale', '2025-05-19 17:34:28'),
(19, 4, 8, 6, 'sale', '2025-05-14 17:34:28'),
(20, 4, 6, 10, 'restock', '2025-05-15 17:34:28'),
(21, 4, 10, 8, 'sale', '2025-05-16 17:34:28'),
(22, 4, 8, 5, 'sale', '2025-05-17 17:34:28'),
(23, 4, 5, 8, 'restock', '2025-05-18 17:34:28'),
(24, 4, 8, 6, 'sale', '2025-05-19 17:34:28'),
(25, 5, 10, 8, 'sale', '2025-05-14 17:34:28'),
(26, 5, 8, 12, 'restock', '2025-05-15 17:34:28'),
(27, 5, 12, 10, 'sale', '2025-05-16 17:34:28'),
(28, 5, 10, 7, 'sale', '2025-05-17 17:34:28'),
(29, 5, 7, 10, 'restock', '2025-05-18 17:34:28'),
(30, 5, 10, 8, 'sale', '2025-05-19 17:34:28'),
(31, 4, 6, 2, 'sale', '2025-05-20 17:34:28'),
(32, 5, 8, 1, 'sale', '2025-05-20 17:34:28'),
(33, 6, 19, 0, 'sale', '2025-05-20 17:34:28'),
(34, 7, 0, 13, '', '2025-05-14 18:30:00'),
(35, 7, 0, 11, 'sale', '2025-05-16 18:30:00'),
(36, 7, 0, 15, 'restock', '2025-05-18 18:30:00'),
(37, 8, 0, 21, '', '2025-05-15 18:30:00'),
(38, 8, 0, 19, 'sale', '2025-05-17 18:30:00'),
(39, 8, 0, 20, 'adjustment', '2025-05-19 18:30:00'),
(40, 9, 0, 30, '', '2025-05-13 18:30:00'),
(41, 9, 0, 28, 'sale', '2025-05-15 18:30:00'),
(42, 9, 0, 25, 'sale', '2025-05-19 18:30:00'),
(43, 10, 0, 5, '', '2025-05-13 18:30:00'),
(44, 10, 0, 4, 'sale', '2025-05-17 18:30:00'),
(45, 11, 0, 14, '', '2025-05-14 18:30:00'),
(46, 11, 0, 12, 'sale', '2025-05-16 18:30:00'),
(47, 12, 0, 10, '', '2025-05-15 18:30:00'),
(48, 12, 0, 9, 'sale', '2025-05-18 18:30:00'),
(49, 13, 0, 23, '', '2025-05-13 18:30:00'),
(50, 13, 0, 20, 'sale', '2025-05-16 18:30:00'),
(51, 14, 0, 23, '', '2025-05-14 18:30:00'),
(52, 14, 0, 21, 'sale', '2025-05-17 18:30:00'),
(53, 15, 0, 15, '', '2025-05-15 18:30:00'),
(54, 15, 0, 14, 'sale', '2025-05-19 18:30:00'),
(55, 16, 0, 4, '', '2025-05-13 18:30:00'),
(56, 16, 0, 3, 'sale', '2025-05-18 18:30:00'),
(57, 17, 0, 13, '', '2025-05-14 18:30:00'),
(58, 17, 0, 12, 'sale', '2025-05-16 18:30:00'),
(59, 18, 0, 22, '', '2025-05-15 18:30:00'),
(60, 18, 0, 20, 'sale', '2025-05-17 18:30:00'),
(61, 19, 0, 33, '', '2025-05-13 18:30:00'),
(62, 19, 0, 30, 'sale', '2025-05-15 18:30:00'),
(63, 20, 0, 12, '', '2025-05-14 18:30:00'),
(64, 20, 0, 10, 'sale', '2025-05-16 18:30:00'),
(65, 7, 0, 13, '', '2025-05-14 18:30:00'),
(66, 7, 0, 11, 'sale', '2025-05-16 18:30:00'),
(67, 7, 0, 15, 'restock', '2025-05-18 18:30:00'),
(68, 8, 0, 21, '', '2025-05-15 18:30:00'),
(69, 8, 0, 19, 'sale', '2025-05-17 18:30:00'),
(70, 8, 0, 20, 'adjustment', '2025-05-19 18:30:00'),
(71, 9, 0, 30, '', '2025-05-13 18:30:00'),
(72, 9, 0, 28, 'sale', '2025-05-15 18:30:00'),
(73, 9, 0, 25, 'sale', '2025-05-19 18:30:00'),
(74, 10, 0, 5, '', '2025-05-13 18:30:00'),
(75, 10, 0, 4, 'sale', '2025-05-17 18:30:00'),
(76, 11, 0, 14, '', '2025-05-14 18:30:00'),
(77, 11, 0, 12, 'sale', '2025-05-16 18:30:00'),
(78, 12, 0, 10, '', '2025-05-15 18:30:00'),
(79, 12, 0, 9, 'sale', '2025-05-18 18:30:00'),
(80, 13, 0, 23, '', '2025-05-13 18:30:00'),
(81, 13, 0, 20, 'sale', '2025-05-16 18:30:00'),
(82, 14, 0, 23, '', '2025-05-14 18:30:00'),
(83, 14, 0, 21, 'sale', '2025-05-17 18:30:00'),
(84, 15, 0, 15, '', '2025-05-15 18:30:00'),
(85, 15, 0, 14, 'sale', '2025-05-19 18:30:00'),
(86, 16, 0, 4, '', '2025-05-13 18:30:00'),
(87, 16, 0, 3, 'sale', '2025-05-18 18:30:00'),
(88, 17, 0, 13, '', '2025-05-14 18:30:00'),
(89, 17, 0, 12, 'sale', '2025-05-16 18:30:00'),
(90, 18, 0, 22, '', '2025-05-15 18:30:00'),
(91, 18, 0, 20, 'sale', '2025-05-17 18:30:00'),
(92, 19, 0, 33, '', '2025-05-13 18:30:00'),
(93, 19, 0, 30, 'sale', '2025-05-15 18:30:00'),
(94, 20, 0, 12, '', '2025-05-14 18:30:00'),
(95, 20, 0, 10, 'sale', '2025-05-16 18:30:00'),
(96, 7, 0, 13, '', '2025-05-14 18:30:00'),
(97, 7, 13, 11, 'sale', '2025-05-16 18:30:00'),
(98, 7, 11, 15, 'restock', '2025-05-18 18:30:00'),
(99, 8, 0, 21, '', '2025-05-15 18:30:00'),
(100, 8, 21, 19, 'sale', '2025-05-17 18:30:00'),
(278, 1, 8, 8, 'adjustment', '2025-05-20 19:31:39'),
(279, 5, 1, 1, 'adjustment', '2025-05-20 19:31:45'),
(280, 2, 16, 16, 'adjustment', '2025-05-20 19:31:51'),
(281, 4, 2, 2, 'adjustment', '2025-05-20 19:32:08'),
(282, 9, 25, 25, 'adjustment', '2025-05-20 19:32:20'),
(283, 19, 30, 30, 'adjustment', '2025-05-20 19:32:25'),
(284, 20, 10, 10, 'adjustment', '2025-05-20 19:32:28'),
(285, 11, 12, 12, 'adjustment', '2025-05-20 19:32:31'),
(286, 17, 12, 12, 'adjustment', '2025-05-20 19:32:34'),
(287, 7, 15, 15, 'adjustment', '2025-05-20 19:32:38'),
(288, 13, 20, 20, 'adjustment', '2025-05-20 19:32:42'),
(289, 18, 20, 20, 'adjustment', '2025-05-20 19:32:45'),
(290, 14, 21, 21, 'adjustment', '2025-05-20 19:32:50'),
(291, 8, 20, 20, 'adjustment', '2025-05-20 19:32:57'),
(292, 6, 0, 0, 'adjustment', '2025-05-20 19:33:01'),
(293, 15, 14, 14, 'adjustment', '2025-05-20 19:33:04'),
(294, 12, 9, 9, 'adjustment', '2025-05-20 19:33:08'),
(302, 12, 9, 11, 'restock', '2025-05-21 00:01:11');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `contact_info` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `address`, `contact_info`, `email`, `joined_at`) VALUES
(1, 'Global Hardware Supplies', '123 Industrial Park Road, Colombo 14, Sri Lanka', '+94 11 2345 678', 'global.hardware@email.com', '2025-05-19 11:50:44'),
(2, 'SL Tools', '45 Main Street, Kandy, Sri Lanka', '+94 81 4567 890', 'sl.tools@email.com', '2025-05-19 11:50:44'),
(3, 'Building Materials Co.', '78 Construction Zone, Galle Road, Colombo 03, Sri Lanka', '+94 11 7890 123', 'building.materials@email.com', '2025-05-19 11:50:44'),
(7, 'Stanley Tools', '12,Main street, Kalmunai', '0782308896', 'StanleyStore3@gmail.com', '2025-05-19 22:01:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `created_at`, `last_login`) VALUES
(1, 'Hajith Nafees', '1027629@bcas.ac', '$2y$10$5s/38PG5dVEziB/eOchpW.wWnPavBSUW11yB.FSYB93mIjCkUcc1W', '2025-03-29 15:07:30', '2025-05-17 00:04:07'),
(2, 'Stark Junior', '1027628@bcas.ac', '$2y$10$Etnak5L8X7rohYCO1T8f5uB8XV0HqIFOKayvzwPq.j4KKXaqsf1yO', '2025-03-29 15:26:53', '2025-05-18 09:51:47'),
(11, 'Zeyn Ezdan', 'zeyn@gmail.com', '$2y$10$KdNErRRJgCtqHueXw.Rl0urzZqwNCDhctGS73YA5rAxVEdYoYLv7S', '2025-04-03 10:55:33', '2025-05-19 12:58:39'),
(12, 'Tony Stank', 'tonystank@gmail.com', '$2y$10$C9Cw4cL00jAjFxkB3igGauTrzFJP201f6g36aXBB2qRd.SrzyZPpa', '2025-04-03 10:56:01', '2025-05-21 08:46:09'),
(13, 'John Smith', 'john.smith@email.com', '$2y$10$C9Cw4cL00jAjFxkB3igGauTrzFJP201f6g36aXBB2qRd.SrzyZPpa', '2025-04-01 04:30:00', '2025-05-20 10:00:00'),
(14, 'Sarah Johnson', 'sarah.j@email.com', '$2y$10$C9Cw4cL00jAjFxkB3igGauTrzFJP201f6g36aXBB2qRd.SrzyZPpa', '2025-04-05 05:50:00', '2025-05-21 03:45:00'),
(15, 'Mike Wilson', 'mike.w@email.com', '$2y$10$C9Cw4cL00jAjFxkB3igGauTrzFJP201f6g36aXBB2qRd.SrzyZPpa', '2025-04-10 09:15:00', '2025-05-19 10:50:00'),
(16, 'Emma Davis', 'emma.d@email.com', '$2y$10$C9Cw4cL00jAjFxkB3igGauTrzFJP201f6g36aXBB2qRd.SrzyZPpa', '2025-04-15 04:00:00', '2025-05-20 06:15:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `c.l.details`
--
ALTER TABLE `c.l.details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carddetails`
--
ALTER TABLE `carddetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `card_id` (`card_id`),
  ADD KEY `delivery_details_id` (`delivery_details_id`);

--
-- Indexes for table `order_tracking`
--
ALTER TABLE `order_tracking`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tracking_number` (`tracking_number`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_suppliers`
--
ALTER TABLE `product_suppliers`
  ADD PRIMARY KEY (`product_id`,`supplier_id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `stock_history`
--
ALTER TABLE `stock_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `c.l.details`
--
ALTER TABLE `c.l.details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `carddetails`
--
ALTER TABLE `carddetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `order_tracking`
--
ALTER TABLE `order_tracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `stock_history`
--
ALTER TABLE `stock_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=303;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `carddetails`
--
ALTER TABLE `carddetails`
  ADD CONSTRAINT `carddetails_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`card_id`) REFERENCES `carddetails` (`id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`delivery_details_id`) REFERENCES `c.l.details` (`id`);

--
-- Constraints for table `order_tracking`
--
ALTER TABLE `order_tracking`
  ADD CONSTRAINT `order_tracking_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Constraints for table `product_suppliers`
--
ALTER TABLE `product_suppliers`
  ADD CONSTRAINT `product_suppliers_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_suppliers_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `stock_history`
--
ALTER TABLE `stock_history`
  ADD CONSTRAINT `stock_history_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
