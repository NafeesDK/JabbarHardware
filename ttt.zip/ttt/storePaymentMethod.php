<?php
session_start();
header('Content-Type: application/json');

if (isset($_POST['payment_method']) && isset($_SESSION['user_id'])) {
    $_SESSION['payment_method'] = $_POST['payment_method'];
    echo json_encode(['success' => true, 'message' => 'Payment method stored']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>