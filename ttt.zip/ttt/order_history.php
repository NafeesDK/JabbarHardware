<?php
session_start();
require_once 'conndb.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$order_query = "SELECT o.*, p.name AS product_name, p.image_url, d.address, d.city, o.payment_method, o.card_id, c.cardholderName 
                FROM orders o 
                JOIN products p ON o.product_id = p.id 
                JOIN `c.l.details` d ON o.delivery_details_id = d.id 
                LEFT JOIN carddetails c ON o.card_id = c.id 
                WHERE o.user_id = ?";
$order_stmt = $conn->prepare($order_query);
$order_stmt->bind_param("i", $user_id);
$order_stmt->execute();
$order_result = $order_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History - Jabbar Hardware Stores</title>
    <link rel="stylesheet" href="order_history.css">
</head>
<body>
    <div id="page1">
        <div class="container">
            <div class="header">
                <a href="ttt.php" class="back-arrow">&#8592;</a>
                <h1>Your Order History</h1>
            </div>
            <div class="order-grid">
                <?php while ($order = $order_result->fetch_assoc()): ?>
                    <div class="order-card">
                        <div class="imgBx">
                            <img src="<?php echo $order['image_url']; ?>" alt="<?php echo $order['product_name']; ?>" class="order-image">
                        </div>
                        <div class="order-details">
                            <h3 class="product-name"><?php echo $order['product_name']; ?></h3>
                            <p class="detail">Quantity: <?php echo $order['quantity']; ?></p>
                            <p class="detail">Price per item: LKR <?php echo number_format($order['total_amount'] / $order['quantity'], 2); ?></p>
                            <p class="detail">Total price + delivery fee: LKR <?php echo number_format($order['total_amount'], 2); ?></p>
                            <hr class="h-line">
                            <p class="detail">Order No: <?php echo $order['id']; ?></p>
                            <p class="detail">Ordered Date: <?php echo date("F j, Y", strtotime($order['created_at'])); ?></p>
                            <p class="detail">Delivery Details: <?php echo $order['address'] . ', ' . $order['city']; ?></p>
                            <p class="detail">Payment Method: <?php echo ucfirst($order['payment_method']); ?><?php if ($order['card_id']): ?> - <?php echo $order['cardholderName']; ?><?php endif; ?></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</body>
</html>