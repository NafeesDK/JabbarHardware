<?php
session_start();
require_once 'conndb.php'; 

$response = array('success' => false, 'message' => '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $user_id = $_SESSION['user_id']; 
    $full_name = $_POST['full_name'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $phone_no = $_POST['phone_no'];
    $created_at = date('Y-m-d H:i:s'); 

    $stmt = $conn->prepare("INSERT INTO `c.l.details` (user_id, full_name, address, city, phone_no, created_at) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssss", $user_id, $full_name, $address, $city, $phone_no, $created_at);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = 'Order details submitted successfully.';
    } else {
        $response['message'] = 'Failed to submit order details: ' . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}

header('Content-Type: application/json');
echo json_encode($response);
?>