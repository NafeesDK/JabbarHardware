<?php
session_start();
require_once 'conndb.php';

if (!isset($_POST['tracking_number']) || !isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit();
}

$tracking_number = $_POST['tracking_number'];
$user_id = $_SESSION['user_id'];

$tracking_query = "SELECT ot.*, o.*, p.name as product_name, p.image_url 
                  FROM order_tracking ot 
                  JOIN orders o ON ot.order_id = o.id 
                  JOIN products p ON o.product_id = p.id 
                  WHERE ot.tracking_number = ? AND o.user_id = ?";

$stmt = $conn->prepare($tracking_query);
$stmt->bind_param("si", $tracking_number, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $order_data = $result->fetch_assoc();
    echo json_encode(['success' => true, 'data' => $order_data]);
} else {
    echo json_encode(['success' => false, 'message' => 'Tracking number not found.']);
}

$stmt->close();
$conn->close();
?>