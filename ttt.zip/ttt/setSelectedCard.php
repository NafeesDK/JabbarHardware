<?php
session_start();
require_once 'conndb.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

if (!isset($_POST['card_id']) || empty($_POST['card_id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid card ID']);
    exit;
}

$cardId = intval($_POST['card_id']);
$userId = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT id FROM carddetails WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $cardId, $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['selected_card_id'] = $cardId;
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Card not found']);
}

$stmt->close();
?>