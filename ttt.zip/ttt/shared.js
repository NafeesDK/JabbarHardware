let currentQuantity = 1;
let currentProductId = null; 