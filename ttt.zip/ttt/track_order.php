<?php
session_start();
require_once 'conndb.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ttt.php");
    exit();
}

$user_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Order - Jabbar Hardware Stores</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            overflow-x: hidden !important;
            margin: 0;
            height: 90vh;
            overflow-y: scroll;
            scroll-snap-type: y mandatory;
            background-image: url('logoo.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #e0e0e0;
        }

        #page1 {
            background-color: rgba(0, 0, 0, 0.80);
            height: 100vh; 
        }

        .header {
            background-color: rgba(0, 0, 0, 0.85);
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .header h1 {
            color: #009688;
            margin: 0;
            font-size: 2rem;
        }

        .menu-icon {
            font-size: 1.9rem;
            cursor: pointer;
            color: #e0e0e0;
            background: transparent;
            border: none;
            padding: 0;
            margin: 0;
            transition: color 0.3s ease;
        }

        .menu-icon:hover {
            color: #009688;
        }

        .tracking-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 90%;
            max-width: 600px;
            padding: 2rem;
            background: rgba(0, 0, 0, 0.85);
            border-radius: 15px;
            border: 1px solid rgba(0, 150, 136, 0.3);
            box-shadow: 0 5px 30px rgba(0, 150, 136, 0.2);
            backdrop-filter: blur(3px);
        }

        .tracking-icons {
            display: flex;
            justify-content: space-between;
            margin: 2rem 0;
            padding: 0 2rem;
            position: relative;
        }

        .icon i {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            color: #00796b;
        }

        .dotted-line {
        }

        .dotted-line::before {
            content: '';
            position: absolute;
            left: 0;
            right: 0;
            top: 86px;
            margin: 0 95px;
            height: 4px;
            background: linear-gradient(to right, transparent 0%, #009688 50%, transparent 100%);
            background-size: 20px 4px;
            animation: moveDashes 1.5s linear infinite;
            transform: translateY(-50%);
            z-index: -10px;
        }

        @keyframes moveDashes {
            0% { background-position: 0; }
            100% { background-position: 20px; }
        }

        .tracking-input {
            width: 100%;
            padding: 12px 15px;
            margin: 1rem 0;
            border: 2px solid rgba(0, 150, 136, 0.3);
            border-radius: 25px;
            font-size: 1rem;
            background-color: rgba(20, 20, 20, 0.8);
            color: white;
            transition: all 0.3s ease;
        }

        .tracking-input:focus {
            outline: none;
            border-color: #009688;
            box-shadow: 0 0 0 3px rgba(0, 150, 136, 0.2);
        }

        .tracking-input::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        .track-button {
            position: relative;
            padding: 12px 20px;
            border: 2px solid #009688;
            cursor: pointer;
            background-color: transparent;
            color: white;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 25px;
            width: 100%;
            overflow: hidden;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .track-button .cover {
            background: #009688;
            height: 100%;
            width: 0%;
            border-radius: 25px;
            position: absolute;
            left: 0;
            bottom: 0;
            z-index: -1;
            transition: width 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        }

        .track-button:hover .cover {
            width: 100%;
        }

        .track-button:hover {
            color: white;
            box-shadow: 0 5px 15px rgba(0, 121, 107, 0.3);
            transform: translateY(-2px);
        }

        .error-message {
            color: #ff6b6b;
            margin-top: 1rem;
            text-align: center;
            display: none;
            background-color: rgba(244, 67, 54, 0.2);
            border: 1px solid #f44336;
            padding: 10px;
            border-radius: 25px;
        }
    </style>
</head>
<body>
    <div id="page1">
        <div class="header">
            <button class="menu-icon" onclick="window.history.back();">&#8592;</button>
            <h1>Track Order</h1>
        </div>

        <div class="tracking-container">
            <div class="dotted-line"></div>
            <div class="dotted-line"></div>
            <div class="tracking-icons">
                <div class="icon">
                    <i class="fas fa-store"></i>
                </div>
                <div class="icon">
                    <i class="fas fa-truck"></i>
                    
                </div>
                <div class="icon">
                    <i class="fas fa-home"></i>
                </div>
            </div>

            <input type="text" class="tracking-input" id="trackingNumber" placeholder="Enter tracking number (e.g., A2019137BC)">
            <button class="track-button" onclick="trackOrder()">
                <span>Track</span>
                <div class="cover"></div>
            </button>
            <div class="error-message" id="errorMessage"></div>
        </div>
    </div>
    <script>
        function trackOrder() {
            const trackingNumber = document.getElementById('trackingNumber').value.trim();
            const errorMessage = document.getElementById('errorMessage');

            if (!trackingNumber) {
                errorMessage.textContent = "Please enter a tracking number";
                errorMessage.style.display = "block";
                return;
            }

            fetch('track_order_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `tracking_number=${trackingNumber}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = `tracking_status.php?tracking=${trackingNumber}`;
                } else {
                    errorMessage.textContent = data.message;
                    errorMessage.style.display = "block";
                }
            })
            .catch(error => {
                errorMessage.textContent = "An error occurred. Please try again.";
                errorMessage.style.display = "block";
            });
        }
    </script>
</body>
</html>
