function updateCartCountFromDatabase() {
  fetch('getCartCount.php?t=' + new Date().getTime(), { 
    cache: 'no-store'
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      const cartCountElement = document.querySelector('.cart-count');
      if (cartCountElement) {
        cartCountElement.textContent = data.count;
        sessionStorage.setItem('cartCount', data.count);
      }
    }
  })
  .catch(error => console.error('Error:', error));
}

function showProductPopup(product) {
  currentProductId = product.id;
  currentQuantity = 1;
  
  document.getElementById('popupProductImage').src = product.image_url;
  document.getElementById('popupProductName').textContent = product.name;
  document.getElementById('popupProductDescription').textContent = product.description;
  
  const originalPriceElem = document.getElementById('popupOriginalPrice');
  const discountedPriceElem = document.getElementById('popupDiscountedPrice');

  originalPriceElem.textContent = "LKR. " + product.original_price;

  if (!product.discounted_price || product.discounted_price === "0.00" || product.discounted_price === "NULL") {
    originalPriceElem.classList.add('no-discount');
    discountedPriceElem.style.display = "none";
  } else {
    originalPriceElem.classList.remove('no-discount');
    discountedPriceElem.textContent = "LKR. " + product.discounted_price;
    discountedPriceElem.style.display = "inline";
  }
  
  document.getElementById('colorOptions').innerHTML = generateColorOptions(product.colors);
  document.getElementById('quantityValue').textContent = currentQuantity;
  document.getElementById('productPopup').style.display = 'flex';
}

function closeProductPopup() {
  document.getElementById('productPopup').style.display = 'none';
  currentQuantity = 1;
}

function changeQuantity(amount) {
  currentQuantity = Math.max(1, currentQuantity + amount);
  document.getElementById('quantityValue').textContent = currentQuantity;
}

function generateColorOptions(colors) {
  if (!colors || colors.length === 0) {
    return '<span>N/A</span>';
  }
  return colors.map(color => `<div class="color-option" style="background-color: ${color};"></div>`).join('');
}

function addToCart() {
  const productId = currentProductId;
  const quantity = currentQuantity;

  const isLoggedIn = document.body.getAttribute('data-logged-in') === 'true';

  if (!isLoggedIn) {
    showNotification("Please log in to add items to your cart.");
    return;
  }

  const formData = new FormData();
  formData.append('add_to_cart', '1');
  formData.append('product_id', currentProductId);
  formData.append('quantity', currentQuantity);

  fetch('AddToCart.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      showNotification(data.message);
      updateCartCountFromDatabase();
    } else {
      showNotification(data.message);
    }
  })
  .catch(error => {
    console.error("Error:", error);
    showNotification("An error occurred. Please try again.");
  });

  closeProductPopup();
}

function showNotification(message) {
  const existingNotification = document.querySelector('.notification');
  if (existingNotification) {
    existingNotification.remove();
  }

  const notification = document.createElement('div');
  notification.className = 'notification';
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => notification.classList.add('show'), 100);

  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => notification.remove(), 300);
  }, 5000);
}

document.addEventListener('DOMContentLoaded', function() {
  const savedCount = sessionStorage.getItem('cartCount') || '0';
  const cartCountElement = document.querySelector('.cart-count');
  if (cartCountElement) {
    cartCountElement.textContent = savedCount;
  }
  
  updateCartCountFromDatabase();
  
  const cartContainer = document.querySelector('.cart-container');
  if (cartContainer) {
    cartContainer.classList.add('fixed-cart');
  }
});